<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        header('location: ' . $uri . '/logOut');
        exit;
    }
}
$msg = '';

if(isset($_GET['id']) && is_numeric($_GET['id']))
{
    $inspector = findInspectorById(htmlCoding($_GET['id']));
    if(!$inspector)
    {
        header('location: ' . $uri . '/inspectorsList');
        exit;
    }
}
else
{
    header('location: ' . $uri . '/inspectorsList');
    exit;
}

if(isset($_POST['txtName']))
{
    updateOneFieldFromTable('users', 'fullName', htmlCoding($_POST['txtName']), htmlCoding($_GET['id']));
    updateOneFieldFromTable('users', 'nationalCode', htmlCoding($_POST['txtNationalCode']), htmlCoding($_GET['id']));
    updateOneFieldFromTable('users', 'mobile', htmlCoding($_POST['txtTel']), htmlCoding($_GET['id']));
    updateOneFieldFromTable('users', 'type', htmlCoding($_POST['cbInspectorType']), htmlCoding($_GET['id']));
    if(strlen($_POST['txtPassword']) > 5)
    {
        updateOneFieldFromTable('users', 'passWord', md5(sha1(htmlCoding($_POST['txtPassword']))), htmlCoding($_GET['id']));
    }
    $msg = 1;
}
$inspector = findInspectorById(htmlCoding($_GET['id']));
if(!$inspector)
{
    header('location: ' . $uri . '/inspectorsList');
    exit;
}

include 'header.php';

?>

<title>بخش مدیریت سامانه بازرسین | ویرایش بازرس</title>

<div class="contentMain" style="min-height: 900px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;">ویرایش بازرس </div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    <?php if($msg == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر با موفقیت ویرایش گردید.</div>
    <?php }elseif($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خطایی در ثبت بازرس رخ داده است.</div>
    <?php }elseif($msg == 3){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر قبلاً ثبت گردیده است.</div>
    <?php } ?>
    <div style="width: 920px; margin-right: 20px; margin-top: 20px;">
        <form action="" method="post" name="formNews" enctype="multipart/form-data">
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نام بازرس: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="نام بازرس" id="txtName" name="txtName" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;" value="<?php echo $inspector['fullName']; ?>">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">کدملی بازرس: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" maxlength="10" placeholder="کدملی بازرس" id="txtNationalCode" name="txtNationalCode" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;" value="<?php echo $inspector['nationalCode']; ?>">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">رمز عبور بازرس: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="درصورت وارد نمودن جایگزین قبلی می گردد" id="txtPassword" name="txtPassword" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">شماره تماس بازرس: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" maxlength="11" placeholder="شماره تماس بازرس" id="txtTel" name="txtTel" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;" value="<?php echo $inspector['mobile']; ?>">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نوع بازرس: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbInspectorType" id="cbInspectorType">
                <option value="0">انتخاب کنید</option>
                <option value="1" <?php if($inspector['type'] == 1){echo 'selected="selected"';} ?>>بازرس حضوری</option>
                <option value="2" <?php if($inspector['type'] == 2){echo 'selected="selected"';} ?>>بازرس تلفنی</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        </form>
        <button type="button" class="btn btn-success" style="float: left; font-family: 'Yekan'; margin-top: 60px;" onclick="addProduct();">ارسال اطلاعات</button>
    </div>

<script>
function addProduct()
{
    var txtName = $('#txtName').val();
    var txtNationalCode = $('#txtNationalCode').val();
    var txtTel = $('#txtTel').val();
    var cbInspectorType = $('#cbInspectorType').val();
    if(txtName.length > 5 && txtNationalCode.length == 10 && txtTel.length == 11 && cbInspectorType > 0)
    {
        document.formNews.submit();
    }
    else
    {
        alert('تمامی گزینه ها را به درستی تکمیل نمائید.')
    }
}
</script>
    
</div>
<?php include 'footer.php'; ?>

