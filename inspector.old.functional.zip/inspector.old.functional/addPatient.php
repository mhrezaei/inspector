<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        //header('location: ' . $uri . '/logOut');
        //exit;
    }
}
$msg = '';

$hospitals = DatabaseHandler::GetAll("SELECT * FROM `hospital` WHERE `status` = 1 ORDER BY `name` ASC ;");
if(!$hospitals)
{  
    header('location: ' . $uri);
    exit;
}

if(isset($_POST['txtName']))
{
    $date = time();
    //$date = htmlCoding($_POST['rdAddDate']);
    //$date = explode('/', $date);
    //$date = pmktime(0, 0, 0, $date[1], $date[2], $date[0]);
    if(isset($_POST['rdAddDate']))
    {
        if($_POST['rdAddDate'] == 'toDay')
        {
            $date = time();
        }
        elseif($_POST['rdAddDate'] == 'lastDay')
        {
            $date = strtotime("-1 days");
        }
        else
        {
            $date = time();
        }
    }
    else
    {
        $date = time();
    }
    
    $tr = makeRandomCode(80);
    $patient = addPatient(htmlCoding($_POST['txtName']), htmlCoding($_POST['txtAge']), htmlCoding($_POST['txtWeight']), htmlCoding($_POST['txtFirstGCS']), NULL, htmlCoding($_POST['cbHospitalName']), htmlCoding($_POST['cbSection']), htmlCoding($_POST['txtTypeOfSection']), $_SESSION['user']['id'], htmlCoding($_POST['txtCause']), htmlCoding($_POST['txtDetail']), $date, NULL, NULL, NULL, NULL, htmlCoding($_POST['cbPresentation']), htmlCoding($_POST['cbStatus']), htmlCoding(strtoupper($_POST['txtBreath'])), htmlCoding(strtoupper($_POST['txtBodyMovement'])), htmlCoding(strtoupper($_POST['txtCoughR'])), htmlCoding(strtoupper($_POST['txtFaceMovement'])), htmlCoding(strtoupper($_POST['txtGagR'])), htmlCoding(strtoupper($_POST['txtCorneaR'])), htmlCoding(strtoupper($_POST['txtPupilR'])), NULL, htmlCoding($_POST['cbTypeList']), $tr, NULL, NULL, NULL, NULL, NULL);
    if($patient)
    {
        $patient = findPatientByTracking($tr);
        if($patient)
        {
            updateOneFieldFromTable('patients', 'tracking', 1, $patient['id']);
            $tests = patientTestInsert($patient['id']);
            if(!$tests)
            {
                $tests = patientTestInsert($patient['id']);
            }
            header('location: ' . $uri . '/showOnePatient?id=' . $patient['id']);
            exit;
        }
        else
        {
            $msg = 3;
        }
    }
    else
    {
        $msg = 2;
    }
}

include 'header.php';

?>
<style type="text/css">
    img.pcalBtn{
        margin-top: 10px;
    }
</style>
<title>بخش مدیریت سامانه بازرسین | افزودن بیمار جدید</title>

<div class="contentMain" style="min-height: 1200px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;">افزودن بیمار جدید </div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    <?php if($msg == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر با موفقیت اضافه گردید.</div>
    <?php }elseif($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خطایی در ثبت بیمار رخ داده است.</div>
    <?php }elseif($msg == 3){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خطای درون برنامه ای رخ داده است، با مراحعه به لیست بیماران در صورت عدم ثبت این بیمار مجدداً اقدام به ثبت اطلاعات نمائید.</div>
    <?php } ?>
    <div style="width: 920px; margin-right: 20px; margin-top: 20px;">
        <form action="" method="post" name="formNews" enctype="multipart/form-data">
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نام و نام خوانوادگی: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="نام و نام خوانوادگی" id="txtName" name="txtName" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">سن بیمار: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="سن بیمار" id="txtAge" name="txtAge" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">وضعیت بدنی: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="txtWeight" id="txtWeight">
                <option value="چاق">چاق</option>
                <option value="متوسط" selected="selected">متوسط</option>
                <option value="لاغر">لاغر</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">GCS اولیه: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="GCS اولیه" id="txtFirstGCS" name="txtFirstGCS" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نام بیمارستان: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="cbHospitalName" id="cbHospitalName">
                <option value="0">انتخاب کنید</option>
                <?php
                    for($i = 0; $i < count($hospitals); $i++)
                    {
                        echo '<option value="' . $hospitals[$i]['id'] . '">' . $hospitals[$i]['name'] . '</option>';
                    }
                ?>
            </select>    
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">بخش: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="cbSection" id="cbSection">
                <option value="0">انتخاب کنید</option>
                <option value="1">CCU</option>
                <option value="2">ICU</option>
                <option value="3">اورژانس</option>
                <option value="4">بخش</option>
            </select>    
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">اسم بخش:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="نوع بخش" id="txtTypeOfSection" name="txtTypeOfSection" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">علت:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="علت" id="txtCause" name="txtCause" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">توضیحات:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <input type="text" class="form-control" placeholder="توضیحات" id="txtDetail" name="txtDetail" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 68px; height: 85px;">تاریخ ثبت:</div>
        <div style="float: left; width: 800px; height: 85px;">
            <div class="radio" style="margin-right: 25px; direction: rtl;">
              <label style="font-family: 'Yekan'; font-size: 15px; line-height: 26px;">
                <input type="radio" name="rdAddDate" id="rdAddDate1" value="toDay" checked="checked" style="margin-right: -20px;">
                امروز - <?php  echo pdate('Y/n/d'); ?>
              </label>
            </div>
            <div class="radio" style="margin-right: 25px; direction: rtl;">
              <label style="font-family: 'Yekan'; font-size: 15px; line-height: 26px;">
                <input type="radio" name="rdAddDate" id="rdAddDate2" value="lastDay" style="margin-right: -20px;">
                دیروز - <?php  echo pdate('Y/n/d', strtotime("-1 days")); ?>
              </label>
            </div>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">معرفی: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="cbPresentation" id="cbPresentation">
                <option value="0">انتخاب کنید</option>
                <option value="1">IP</option>
                <option value="2">TDDP</option>
                <option value="3">HR</option>
            </select>    
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">وضعیت بیمار: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="cbStatus" id="cbStatus">
                <option value="0">انتخاب کنید</option>
                <option value="1">بیمار جدید</option>
                <option value="2">درحال پیگیری</option>
                <!--<option value="3">مرگ مغزی نیست</option>-->
                <option value="4">اهدا شده</option>
                <option value="5">فوت شده</option>
                <option value="6">غیر قابل اهدا</option>
                <option value="7">بهبود یافته</option>
            </select>    
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Breathing:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtBreath" id="txtBreath">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Body Movement:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtBodyMovement" id="txtBodyMovement">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Cough R:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtCoughR" id="txtCoughR">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Face Movement:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtFaceMovement" id="txtFaceMovement">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Gag R:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtGagR" id="txtGagR">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Cornea R:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtCorneaR" id="txtCorneaR">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">Pupil R:</div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" name="txtPupilR" id="txtPupilR">
                <option value="P">P</option>
                <option value="N">N</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 120px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نوع لیست: <span style="color: red;">*</span></div>
        <div style="float: left; width: 800px; height: 50px;">
            <select class="form-control" style="width: 500px; margin-right: 6px; direction: rtl; font-family: 'Yekan'; font-size: 12px; height: 32px; text-align: right;" name="cbTypeList" id="cbTypeList">
                <option value="0">انتخاب کنید</option>
                <option value="1">GCS3 مرگ مغزی شده</option>
                <option value="2">GCS3 مرگ مغزی نشده</option>
                <option value="3">GCS 4,5</option>
                <option value="4">موارد نامناسب</option>
            </select>    
        </div>
        <div style="clear: both;"></div>
        
        </form>
        <button type="button" class="btn btn-success" style="float: left; font-family: 'Yekan'; margin-top: 30px;" onclick="addProduct();">ارسال اطلاعات</button>
    </div>

<script>
function addProduct()
{
    var txtName = $('#txtName').val();
    var txtAge = $('#txtAge').val();
    var txtWeight = $('#txtWeight').val();
    var txtFirstGCS = $('#txtFirstGCS').val();
    var cbHospitalName = $('#cbHospitalName').val();
    var cbSection = $('#cbSection').val();
    var cbPresentation = $('#cbPresentation').val();
    var cbStatus = $('#cbStatus').val();
    var cbTypeList = $('#cbTypeList').val();
    if(txtName.length > 3 && txtFirstGCS.length > 0 && cbHospitalName > 0 && cbSection > 0 && cbPresentation > 0 && cbStatus > 0 && cbTypeList > 0 && txtAge > 0 && txtWeight.length > 1)
    {
        $.ajax({
                type: "POST",
                url: "ajax.patient.php",
                cache: false,
                data: { 
                    addName: txtName,
                    addAge: txtAge,
                    addWeight: txtWeight,
                    addFirstGCS: txtFirstGCS,
                    addHospitalName: cbHospitalName,
                    addSection: cbSection
                }
            }).done(function(Data){
                if(Data == 'OK')
                    {
                    document.formNews.submit();
                }
                else
                    {
                    alert('این بیمار تکراری می باشد و در تاریخ  ' + Data + ' ثبت گردیده است.');
                }
            });
    }
    else
    {
        alert('گزینه های ستاره دار را به درستی تکمیل نمائید.');
    }
}
</script>
    
</div>
<?php include 'footer.php'; ?>

