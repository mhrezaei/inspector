-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2015 at 10:52 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inspector.old`
--
CREATE DATABASE IF NOT EXISTS `inspector.old` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `inspector.old`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_log`
--

CREATE TABLE IF NOT EXISTS `admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminIp` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `lastLogin` bigint(20) NOT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) CHARACTER SET utf16 COLLATE utf16_persian_ci DEFAULT NULL,
  `res5` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`),
  KEY `adminIp` (`adminIp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_log`
--

INSERT INTO `admin_log` (`id`, `adminIp`, `lastLogin`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(1, '::1', 1411226620, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `name_2` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=100 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `name`, `status`, `res1`, `res2`) VALUES
(7, 'هفت تیر', 1, NULL, NULL),
(8, 'فیاض بخش', 1, NULL, NULL),
(9, 'لقمان', 1, NULL, NULL),
(10, 'سپیر', 1, NULL, NULL),
(11, 'امام حسین', 1, NULL, NULL),
(12, 'شهدای تجریش', 1, NULL, NULL),
(13, 'تهرانپارس', 1, NULL, NULL),
(14, 'پارس', 1, NULL, NULL),
(15, 'میلاد', 1, NULL, NULL),
(16, 'چمران', 1, NULL, NULL),
(17, 'بقیه الله', 1, NULL, NULL),
(18, 'پیامبران', 1, NULL, NULL),
(19, 'بازرگانان', 1, NULL, NULL),
(20, 'بوعلی', 1, NULL, NULL),
(21, 'البرز', 1, NULL, NULL),
(22, 'مهراد', 1, NULL, NULL),
(23, 'خرداد ورامین15', 1, NULL, NULL),
(24, 'سجاد', 1, NULL, NULL),
(25, '501 ارتش', 1, NULL, NULL),
(26, 'مردم', 1, NULL, NULL),
(27, 'پاسارگاد', 1, NULL, NULL),
(28, 'پاستورنو', 1, NULL, NULL),
(29, 'فیروز آبادی', 1, NULL, NULL),
(30, 'شهدای یافت آباد', 1, NULL, NULL),
(31, '502 ارتش', 1, NULL, NULL),
(32, 'الغدیر', 1, NULL, NULL),
(33, 'خیریه سیدالشهدا', 1, NULL, NULL),
(34, 'پارسیان', 1, NULL, NULL),
(35, 'بهمن', 1, NULL, NULL),
(36, 'آبان', 1, NULL, NULL),
(37, 'رامتین', 1, NULL, NULL),
(38, 'لاله', 1, NULL, NULL),
(39, 'بعثت', 1, NULL, NULL),
(40, 'ولیعصرناجا', 1, NULL, NULL),
(41, 'ایران مهر', 1, NULL, NULL),
(42, 'شرکت نفت', 1, NULL, NULL),
(43, 'عرفان', 1, NULL, NULL),
(44, 'گلستان', 1, NULL, NULL),
(45, 'مهر', 1, NULL, NULL),
(46, 'تهران', 1, NULL, NULL),
(47, 'دادگستری', 1, NULL, NULL),
(48, 'فجر', 1, NULL, NULL),
(49, 'قمر بنی هاشم', 1, NULL, NULL),
(50, 'تهران کلینیک', 1, NULL, NULL),
(51, 'طوس', 1, NULL, NULL),
(52, 'صارم', 1, NULL, NULL),
(53, 'آپادانا', 1, NULL, NULL),
(54, 'آسیا', 1, NULL, NULL),
(55, 'دی', 1, NULL, NULL),
(56, 'یاس سپید', 1, NULL, NULL),
(57, 'کیان', 1, NULL, NULL),
(58, 'رسالت', 1, NULL, NULL),
(59, 'خانواده', 1, NULL, NULL),
(60, 'خاتم الانبیا', 1, NULL, NULL),
(61, 'آراد', 1, NULL, NULL),
(62, 'ابن سینا', 1, NULL, NULL),
(63, 'بانک ملی', 1, NULL, NULL),
(64, 'سوم شعبان', 1, NULL, NULL),
(65, 'مدرس', 1, NULL, NULL),
(66, 'جم', 1, NULL, NULL),
(67, 'مصطفی خمینی', 1, NULL, NULL),
(68, 'امام سجاد ناجا', 1, NULL, NULL),
(69, 'کسری', 1, NULL, NULL),
(70, 'آریا', 1, NULL, NULL),
(71, 'ساسان', 1, NULL, NULL),
(72, 'لبافی نژاد', 1, NULL, NULL),
(73, 'قلب جماران', 1, NULL, NULL),
(74, 'هاجر', 1, NULL, NULL),
(75, 'ایران شهر', 1, NULL, NULL),
(76, 'فرمانیه', 1, NULL, NULL),
(77, 'غیاثی', 1, NULL, NULL),
(78, 'مفتح ورامین', 1, NULL, NULL),
(79, 'نبکان', 1, NULL, NULL),
(80, 'طالقانی', 1, NULL, NULL),
(81, 'تامین اجتماعی شهریار', 1, NULL, NULL),
(82, 'باهنر', 1, NULL, NULL),
(83, 'مهدیه', 1, NULL, NULL),
(84, 'اشرفی اصفهانی', 1, NULL, NULL),
(85, 'طرفه', 1, NULL, NULL),
(86, 'جواهری', 1, NULL, NULL),
(87, 'امام سجاد شهریار', 1, NULL, NULL),
(88, 'ایرانیان', 1, NULL, NULL),
(89, 'صدر', 1, NULL, NULL),
(90, 'مهرگان', 1, NULL, NULL),
(91, 'لولاگر', 1, NULL, NULL),
(92, 'شهید فهمیده', 1, NULL, NULL),
(93, 'شریعت رضوی', 1, NULL, NULL),
(94, 'کودکان تهران', 1, NULL, NULL),
(95, 'مادران', 1, NULL, NULL),
(96, 'فاطمه الزهرا رباط کریم', 1, NULL, NULL),
(97, 'نور افشار', 1, NULL, NULL),
(98, 'آتیه', 1, NULL, NULL),
(99, 'مفید', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `age` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `weight` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `firstGCS` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `secondGCS` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `hospitalName` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `type_of_section` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `inspector` int(11) NOT NULL,
  `cause` text COLLATE utf8_persian_ci,
  `detail` text COLLATE utf8_persian_ci,
  `addDate` bigint(20) NOT NULL,
  `lastUpdate` bigint(20) DEFAULT NULL,
  `hospitalizationDate` bigint(20) DEFAULT NULL,
  `brainDeathDate` bigint(20) DEFAULT NULL,
  `coordinatorName` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `presentation` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `breath` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `body_Movement` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `cough_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `face_Movement` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `gag_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `cornea_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `pupil_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `sedation` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `typeList` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `tracking` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333)),
  KEY `addDate` (`addDate`),
  KEY `lastUpdate` (`lastUpdate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `age`, `weight`, `firstGCS`, `secondGCS`, `hospitalName`, `section`, `type_of_section`, `inspector`, `cause`, `detail`, `addDate`, `lastUpdate`, `hospitalizationDate`, `brainDeathDate`, `coordinatorName`, `presentation`, `status`, `breath`, `body_Movement`, `cough_R`, `face_Movement`, `gag_R`, `cornea_R`, `pupil_R`, `sedation`, `typeList`, `tracking`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(2, 'محمد هادی رضایی کمال آباد', '25', '135', '4', '3', 63, 1, 'اصلی', 4, 'تصادف با موتور سیکلت سنگین', 'جمجمه متلاشی شده و ندارد', 1410895800, 1411155000, NULL, NULL, NULL, 1, 6, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, '4', '1', '', '', '', '', ''),
(3, 'حسین عزیزی', '45', '80', '6', '', 62, 2, 'ICU 2', 4, 'مصرف قرص', 'شرایط فیزیکی سالم', 1410809400, 1410982200, NULL, NULL, NULL, 1, 1, 'P', 'N', 'N', 'P', 'P', 'N', 'P', NULL, '3', '1', '', '', '', '', ''),
(4, 'کلثوم جعفری', '65', 'چاق', '4', '', 53, 4, 'زنان', 4, 'زایش', '', 1409340600, 1411331400, NULL, NULL, NULL, 2, 4, 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, '0', '1', '', '', '', '', ''),
(5, 'جواد یعقوبی', '32', '95', '3', '', 32, 3, 'اورژانس اصلی', 4, 'ضربه آجر به سر', 'دماغ شکسته', 1410982200, 0, NULL, NULL, NULL, 3, 3, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, 'P', '1', '', '', '', '', ''),
(6, 'احمد جلالی', '72', '80', '5', '', 31, 1, 'CCU قلب', 4, 'سکته قلبی', '', 1411241400, 1411068600, NULL, NULL, NULL, 1, 5, 'N', 'N', 'N', 'N', 'P', 'P', 'P', NULL, 'N', '1', '', '', '', '', ''),
(7, 'جلیل مزدکی', '25', '74', '3', '', 34, 3, '', 4, 'داروی روان گردان', '', 1411068600, 0, NULL, NULL, NULL, 1, 6, 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', '1', '', '', '', '', ''),
(8, 'خرم عثمانی', '45', '80', '5', '', 66, 2, '', 4, 'مصرف دارو', '', 1410895800, 1408735800, NULL, NULL, NULL, 3, 7, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, 'P', '1', '', '', '', '', ''),
(9, 'کاترین اشتون', '55', '75', '4', '3', 53, 1, '', 3, 'خوردن اورانیوم', '', 1410463800, 1411068600, NULL, NULL, NULL, 1, 4, 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'P', '1', '', '', '', '', ''),
(10, 'احمد مختاری', '37', '80', '5', '', 25, 2, 'داخلی', 3, 'ضربه مغزی', 'عمل جراحی شده', 1411068600, 0, NULL, NULL, NULL, 3, 1, 'P', 'P', 'P', 'P', 'P', 'P', 'N', NULL, 'N', '1', '', '', '', '', ''),
(11, 'محمد', '', '', '1', '', 61, 2, '', 1, '', '', 1411155000, 0, NULL, NULL, NULL, 1, 1, '', '', '', '', '', '', '', NULL, '', '1', '', '', '', '', ''),
(12, 'مهران احمد آقایی مطلق', '35', '78', '6', '3', 61, 2, 'اصلی', 1, 'CVS', 'تصادف', 1411155000, 1411068600, NULL, NULL, NULL, 2, 4, 'N', 'N', 'P', 'P', 'P', 'P', 'N', NULL, 'N', '1', '1', '', '', '', ''),
(13, 'جعفر محمدی', '26', '65', '6', '3', 19, 2, '1', 1, 'نمی دونم', 'ندارد', 1410809400, 1411241400, NULL, NULL, NULL, 1, 4, 'N', 'N', 'N', 'P', 'P', 'N', 'N', NULL, '1', '1', '1', '', '', '', ''),
(14, 'اصغر ابراهیمی', '44', 'چاق', '5', '', 68, 2, '5', 1, 'CVD', 'ندارد', 1411331400, 1411155000, NULL, NULL, NULL, 1, 2, 'N', 'N', 'P', 'P', 'N', 'N', 'N', NULL, '2', '1', NULL, '', '', '', ''),
(15, 'زینب محمدی اصل', '27', 'چاق', '4', '3', 75, 2, 'B', 1, 'ترامادول خورده', 'تماس گرفتم ج نداد', 1411155000, 1411331400, NULL, NULL, NULL, 2, 2, 'P', 'P', 'N', 'N', 'P', 'P', 'N', NULL, '2', '1', '', '', '', '', ''),
(16, 'غلام مختاری', '21', 'متوسط', '4', '', 31, 1, '', 1, '', '', 1411677000, 0, NULL, NULL, NULL, 1, 1, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, '3', '1', '', '', '', '', ''),
(17, 'غلام مختاری', '21', 'متوسط', '4', '', 31, 1, '', 1, '', '', 1412713800, 0, NULL, NULL, NULL, 1, 1, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, '2', '2', '', '', '', '', ''),
(18, 'غلام مختاری', '21', 'متوسط', '4', '', 31, 2, '', 1, '', '', 1412195400, 0, NULL, NULL, NULL, 1, 1, 'P', 'P', 'P', 'P', 'P', 'P', 'P', NULL, '2', '1', '', '', '', '', ''),
(19, 'سکینه زمانی', '65', 'متوسط', '5', '6', 11, 2, '5', 1, 'L.O.C', 'مسمومیت با الکل', 1411639797, 1412022600, 1411417800, 1411763400, 'هادی صادق', 1, 2, 'N', 'P', 'N', 'P', 'P', 'N', 'P', 'NO', '1', '1', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_log`
--

CREATE TABLE IF NOT EXISTS `patient_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pId` int(11) NOT NULL,
  `uId` int(11) NOT NULL,
  `secondGCS` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `hospitalName` int(11) DEFAULT NULL,
  `section` int(11) DEFAULT NULL,
  `type_of_section` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `presentation` int(11) DEFAULT NULL,
  `breath` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `body_Movement` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `cough_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `face_Movement` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `gag_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `cornea_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `pupil_R` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `sedation` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `lastUpdate` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res7` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res8` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res9` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res10` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `patient_log`
--

INSERT INTO `patient_log` (`id`, `pId`, `uId`, `secondGCS`, `hospitalName`, `section`, `type_of_section`, `presentation`, `breath`, `body_Movement`, `cough_R`, `face_Movement`, `gag_R`, `cornea_R`, `pupil_R`, `sedation`, `lastUpdate`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`, `res8`, `res9`, `res10`) VALUES
(2, 19, 1, '3', 21, 2, '5', 1, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'YES', 1411677000, 1, '', '', '', '', '', '', '', '', '', ''),
(3, 19, 1, '3', 21, 2, '5', 1, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'YES', 1411677000, 1, '', '', '', '', '', '', '', '', '', ''),
(4, 19, 1, '7', 11, 1, '5', 2, 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'NO', 1411763400, 1, '', '', '', '', '', '', '', '', '', ''),
(5, 19, 3, '6', 11, 2, '5', 1, 'N', 'P', 'N', 'P', 'P', 'N', 'P', 'NO', 1412022600, 1, '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_test`
--

CREATE TABLE IF NOT EXISTS `patient_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `NA` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `K` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `BUN` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `WBC` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `ALT` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `AST` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `BP` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `T` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `OUT_PUT` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res1` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res7` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res8` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `patient_test`
--

INSERT INTO `patient_test` (`id`, `pid`, `status`, `NA`, `K`, `BUN`, `WBC`, `ALT`, `AST`, `BP`, `T`, `OUT_PUT`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`, `res8`) VALUES
(2, 15, 1, '1500', '2000', '35200', '3210', '21', '25120', '21520', '1522', '1512', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 16, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 17, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 18, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 19, 1, '120', '200', '300', '400', '500', '600', '700', '800', '900', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nationalCode` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `passWord` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `fullName` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` text COLLATE utf8_persian_ci,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nationalCode` (`nationalCode`,`fullName`),
  KEY `nationalCode_2` (`nationalCode`),
  KEY `fullName` (`fullName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nationalCode`, `passWord`, `fullName`, `mobile`, `type`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(1, 'admin', '693cfed9dd8adf7c63afbf53cf3a8043', 'مسئول سامانه', '09121234567', NULL, 1, NULL, NULL, NULL, NULL, NULL),
(3, '0012071110', '9346f8dc1374b90299c76b5500f91332', 'محمد هادی رضایی', '09361112030', 1, 1, NULL, NULL, NULL, NULL, NULL),
(4, '0084782439', '693cfed9dd8adf7c63afbf53cf3a8043', 'فریبا نوری اعتماد', '09351303767', 2, 1, NULL, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
