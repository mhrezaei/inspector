<?php

########################## SETTING ##########################
function setting($value)
{
    $result = DatabaseHandler::GetRow("SELECT * FROM `setting` WHERE `id` = 1");
    return $result = $result[$value];
    #title
    #url
    #gift
    
}
########################## SETTING ##########################

########################## validateEmail ##########################
function ValidationEmail($email)
{
    if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)*.([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/" , $email)) {
        return false;
    }
    else
    {
        return true;
    }
}
########################## validateEmail ##########################

########################## Change Location With Javascript ##########################
function changeLocationWithJavascript($url, $time = 0)
{
    $header = '<script type="text/javascript">
            function changeLocationWithTime(url)
            {
                window.location = url;
            }
            setTimeout(changeLocationWithTime("' . $url . '"), ' . $time . ')
        </script>';
        
    return $header;
}
########################## Change Location With Javascript ##########################

############################ check user is loged in ############################
function checkUserIsLogedIn()
{
    if(isset($_SESSION['user']['id']) && isset($_SESSION['user']['user']) && isset($_SESSION['user']['token']))
    {
        $query = DatabaseHandler::GetRow("SELECT * FROM `users` WHERE `id` = " . $_SESSION['user']['id'] . " AND `status` = 1 ;");
        if($query)
        {
            if($_SESSION['user']['user'] == $query['nationalCode'] && $_SESSION['user']['token'] == md5($query['passWord']))
            {
                return true;
            }
            else
            {
                unset($_SESSION['user']);
                return false;
            }
        }
        else
        {
            unset($_SESSION['user']);
            return false;
        }
    }
    else
    {
        return false;
    }
}
############################ check user is loged in ############################

############################ check user to log in ############################
function checkUserToLogIn($user, $pass)
{
    if(isset($_SESSION['user']))
    {
        unset($_SESSION['user']);
    }
    $query = DatabaseHandler::GetRow("SELECT * FROM `users` WHERE `nationalCode` = '" . $user . "' AND `passWord` = '" . md5(sha1($pass)) . "' AND `status` = 1 ;");
    if($query)
    {
        $_SESSION['user']['id'] = $query['id'];
        $_SESSION['user']['token'] = md5($query['passWord']);
        $_SESSION['user']['user'] = $query['nationalCode'];
        return $query;
    }
    else
    {
        return false;
    }
}
############################ check user to log in ############################

############################ user log out ############################
function userLogOut()
{
    unset($_SESSION['user']);
}
############################ user log out ############################

############################ check admin is loged in ############################
function checkAdminIsLogedIn()
{
    if($_SESSION['user']['user'] == 'admin' && $_SESSION['user']['id'] == 1)
    {
        $query = DatabaseHandler::GetRow("SELECT * FROM `users` WHERE `id` = " . $_SESSION['user']['id'] . " AND `status` = 1 ;");
        if($query)
        {
            if($_SESSION['user']['token'] == md5($query['passWord']))
            {
                return true;
            }
            else
            {
                unset($_SESSION['user']);
                return false;
            }
        }
        else
        {
            unset($_SESSION['user']);
            return false;
        }
    }
    else
    {
        return false;
    }
}
############################ check admin is loged in ############################

############################ check hospital name duplicated ############################
function checkHospitalNameDuplicated($name)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `hospital` WHERE `name` LIKE '" . $name . "' ;");
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ check hospital name duplicated ############################

############################ add hospital ############################
function addHospital($name, $status)
{
    $query = DatabaseHandler::Execute("INSERT INTO `hospital` (`id`, `name`, `status`, `res1`, `res2`) VALUES (NULL, '" . $name . "', '" . $status . "', NULL, NULL);");
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ add hospital ############################

############################ find hospital by id ############################
function findHospitalById($id)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `hospital` WHERE `id` = '" . $id . "' ;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find hospital by id ############################

############################ check inspector national code duplicator ############################
function checkInspectorNationalCodeDuplicator($nationalCode)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `users` WHERE `nationalCode` LIKE '" . $nationalCode . "' ;");
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ check inspector national code duplicator ############################

############################ find inspector by id ############################
function findInspectorById($id)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `users` WHERE `id` = '" . $id . "' ;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find inspector by id ############################

############################ add inspector ############################
function addInspector($nationalCode, $password, $name, $mobile, $type, $status)
{
    $query = DatabaseHandler::Execute("INSERT INTO `users` (`id`, `nationalCode`, `passWord`, `fullName`, `mobile`, `type`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES (NULL, '" . $nationalCode . "', '" . md5(sha1($password)) . "', '" . $name . "', '" . $mobile . "', '" . $type . "', '" . $status . "', NULL, NULL, NULL, NULL, NULL);");
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ add inspector ############################

############################ make random code ############################
function makeRandomCode($num)
{
    $rand = '';
    for($i = 0; $i < $num; $i++)
    {
        $rand .= rand(0,9);
    }
    return $rand;
}
############################ make random code1 ############################

############################ add patient ############################
function addPatient($name, $age = NULL, $weight = NULL, $firstGCS, $secondGCS = NULL, $hospitalName, $section, $type_of_section = NULL, $inspector, $cause = NULL, $detail = NULL, $addDate, $lastUpdate = NULL, $hospitalizationDate = NULL, $brainDeathDate = NULL, $coordinatorName = NULL, $presentation, $status, $breath = NULL, $body_Movement = NULL, $cough_R = NULL, $face_Movement = NULL, $gag_R = NULL, $cornea_R = NULL, $pupil_R = NULL, $sedation = NULL, $typeList = NULL, $tracking, $res1 = NULL, $res2 = NULL, $res3 = NULL, $res4 = NULL, $res5 = NULL)
{
    $query = DatabaseHandler::Execute("INSERT INTO `patients` (
                                                                `id` ,
                                                                `name` ,
                                                                `age` ,
                                                                `weight` ,
                                                                `firstGCS` ,
                                                                `secondGCS` ,
                                                                `hospitalName` ,
                                                                `section` ,
                                                                `type_of_section` ,
                                                                `inspector` ,
                                                                `cause` ,
                                                                `detail` ,
                                                                `addDate` ,
                                                                `lastUpdate` ,
                                                                `hospitalizationDate` ,
                                                                `brainDeathDate` ,
                                                                `coordinatorName` ,
                                                                `presentation` ,
                                                                `status` ,
                                                                `breath` ,
                                                                `body_Movement` ,
                                                                `cough_R` ,
                                                                `face_Movement` ,
                                                                `gag_R` ,
                                                                `cornea_R` ,
                                                                `pupil_R` ,
                                                                `sedation` ,
                                                                `typeList` ,
                                                                `tracking` ,
                                                                `res1` ,
                                                                `res2` ,
                                                                `res3` ,
                                                                `res4` ,
                                                                `res5`
                                                                )
                                                                VALUES (
                                                                NULL , '" . $name . "', '" . $age . "', '" . $weight . "', '" . $firstGCS . "', '" . $secondGCS . "', '" . $hospitalName . "', '" . $section . "', '" . $type_of_section . "', '" . $inspector . "', '" . $cause . "', '" . $detail . "', '" . $addDate . "', '" . $lastUpdate . "', '" . $hospitalizationDate . "', '" . $brainDeathDate . "', '" . $coordinatorName . "', '" . $presentation . "', '" . $status . "', '" . $breath . "', '" . $body_Movement . "', '" . $cough_R . "', '" . $face_Movement . "', '" . $gag_R . "', '" . $cornea_R . "', '" . $pupil_R . "', '" . $sedation . "', '" . $typeList . "', '" . $tracking . "', '" . $res1 . "', '" . $res2 . "', '" . $res3 . "', '" . $res4 . "', '" . $res5 . "'
                                                                );");
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ add patient ############################

############################ find patient by tracking ############################
function findPatientByTracking($tracking)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `patients` WHERE `tracking` LIKE '" . $tracking . "' ;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find patient by tracking ############################

############################ find patient by id ############################
function findPatientById($id)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `patients` WHERE `id` = '" . $id . "' ;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find patient by id ############################

############################ find patient tests by patients id ############################
function findPatientTestByPatientsId($pid)
{
    $query = DatabaseHandler::GetRow("SELECT * FROM `patient_test` WHERE `pid` = " . $pid . " AND `status` = 1 ;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find patient tests by patients id ############################

############################ check Patient Duplicated Insert ############################
function checkPatientDuplicatedInsert($name, $age, $weight, $firstGCS, $hospitalId, $section, $tracking = 1)
{
    $query = "SELECT *
            FROM `patients`
            WHERE `name` LIKE '$name'
            AND `age` = '$age'
            AND `weight` LIKE '$weight'
            AND `firstGCS` = '$firstGCS'
            AND `hospitalName` =$hospitalId
            AND `section` =$section
            AND `tracking` = '$tracking'
            ORDER BY `id` DESC
            LIMIT 0 , 30; ";
    $query = DatabaseHandler::GetRow($query);
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ check Patient Duplicated Insert ############################

############################ patient Test Insert ############################
function patientTestInsert($pid)
{
    $query = DatabaseHandler::Execute("INSERT INTO `patient_test` (`id`, `pid`, `status`, `NA`, `K`, `BUN`, `WBC`, `ALT`, `AST`, `BP`, `T`, `OUT_PUT`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`, `res8`) VALUES (NULL, '" . $pid . "', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ patient Test Insert ############################

############################ add Patients Log ############################
function addPatientsLog($pId, $uId, $secondGCS = NULL, $hospitalName = NULL, $section = NULL, $type_of_section = NULL, $presentation = NULL, $breath = NULL, $body_Movement = NULL, $cough_R = NULL, $face_Movement = NULL, $gag_R = NULL, $cornea_R = NULL, $pupil_R = NULL, $sedation = NULL, $lastUpdate = NULL, $status = NULL, $res1 = NULL, $res2 = NULL, $res3 = NULL, $res4 = NULL, $res5 = NULL, $res6 = NULL, $res7 = NULL, $res8 = NULL, $res9 = NULL, $res10 = NULL)
{
    $query = "INSERT INTO `patient_log` (`id`, `pId`, `uId`, `secondGCS`, `hospitalName`, `section`, `type_of_section`, `presentation`, `breath`, `body_Movement`, `cough_R`, `face_Movement`, `gag_R`, `cornea_R`, `pupil_R`, `sedation`, `lastUpdate`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`, `res8`, `res9`, `res10`) VALUES (NULL, '" . $pId . "', '" . $uId . "', '" . $secondGCS . "', '" . $hospitalName . "', '" . $section . "', '" . $type_of_section . "', '" . $presentation . "', '" . $breath . "', '" . $body_Movement . "', '" . $cough_R . "', '" . $face_Movement . "', '" . $gag_R . "', '" . $cornea_R . "', '" . $pupil_R . "', '" . $sedation . "', '" . $lastUpdate . "', '" . $status . "', '" . $res1 . "', '" . $res2 . "', '" . $res3 . "', '" . $res4 . "', '" . $res5 . "', '" . $res6 . "', '" . $res7 . "', '" . $res8 . "', '" . $res9 . "', '" . $res10 . "');";
    
    $query = DatabaseHandler::Execute($query);
    if($query)
    {
        return true;
    }
    else
    {
        return false;
    }
}
############################ add Patients Log ############################

############################ find All Patients Log ############################
function findAllPatientsLog($pId, $status)
{
    $query = "SELECT * FROM `patient_log` WHERE `pId` = '" . $pId . "' AND `status` = '" . $status . "' ORDER BY `id` DESC ;";
    $query = DatabaseHandler::GetAll($query);
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
############################ find All Patients Log ############################



?>