<?php

//==============================================
// daryafte list model ha baraye ghata'ate yadaki
function getDeviceModelsForSP()
{
    $query = DatabaseHandler::GetAll("SELECT `res1` FROM `spare_parts_list` GROUP BY `res1` ORDER BY `res1` ASC;");
    if($query)
    {
        return $query;
    }
    else
    {
        return false;
    }
}
//==============================================


?>