<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
require_once SITE_ROOT . '/functions/fn.questionSecurity.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        //header('location: ' . $uri);
        //exit;
    }
}                                                                                                                          
$admin_log = DatabaseHandler::GetRow("SELECT * FROM `admin_log` WHERE `id` =1 LIMIT 0 , 30");
include 'header.php';

?>

<title>بخش مدیریت سامانه بازرسین | صفحه اصلی</title>
<?php
    if(!checkAdminIsLogedIn())
    {
?>
<div id="menu" style="min-height: 50px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px; font-size: 15px; direction: rtl;">
    
    به بخش بازرسین سامانه مدل ايراني شناسايي اهدا كنندگان احتمالي (PPDDP) خوش آمدید.
    <br><br>
    بازرس گرامی لطفاً سوالات و مشکلات موجود را با استفاده از روش های زیر به مسئول سامانه گزارش دهید.
    <br> 
    ازطریق تلفن (در ساعات اداری): <span style="color: #0334c1;"> 02126105289 </span>
    <br>
    از طریق ایمیل: <span style="color: #0334c1; font-family: Tahoma;"> admin@ehda-portal.ir </span>
    <br><br>
    
    </div>
</div>
<?php }else{ ?>
<div id="menu" style="min-height: 50px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px; font-size: 15px;">
    
    به بخش مدیریت سامانه مدل ايراني شناسايي اهدا كنندگان احتمالي (PPDDP) خوش آمدید.
    <br><br>
    آخرین ورود موفق شما در تاریخ: <span style="color: #0334c1;"> <?php echo pdate('l، d F Y - ساعت h:i A', $admin_log['lastLogin']) ?> </span>
    <br><br> 
    آخرین IP ثبت شده پس از ورود به کنترل پنل مدیریت: <span style="color: #0334c1;"> <?php echo $admin_log['adminIp'] ?> </span>
    <br><br>
    
    </div>
</div>
<?php } ?>


<?php include 'footer.php'; ?>