<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        header('location: ' . $uri . '/logOut');
        exit;
    }
}
$msg = '';

if(isset($_POST['txtName']))
{
    if(!checkHospitalNameDuplicated(htmlCoding($_POST['txtName'])))
    {
        $insert = addHospital(htmlCoding($_POST['txtName']), 1);
        if($insert)
        {
            $msg = 1;
        }
        else
        {
            $msg = 2;
        }
    }
    else
    {
        $msg = 3;
    }
}

include 'header.php';

?>

<title>بخش مدیریت سامانه بازرسین | افزودن بیمارستان</title>

<div class="contentMain" style="min-height: 900px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;">افزودن بیمارستان </div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    <?php if($msg == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بیمارستان مورد نظر با موفقیت ثبت گردید.</div>
    <?php }elseif($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خطایی در ثبت بیمارستان رخ داده است.</div>
    <?php }elseif($msg == 3){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">نام بیمارستان قبلاً ثبت گردیده است.</div>
    <?php } ?>
    <div style="width: 920px; margin-right: 20px; margin-top: 20px;">
        <form action="" method="post" name="formNews" enctype="multipart/form-data">
        
        <div style="width: 100px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">نام بیمارستان: <span style="color: red;">*</span></div>
        <div style="float: left; width: 820px; height: 50px;">
            <input type="text" class="form-control" placeholder="نام بیمارستان" id="txtName" name="txtName" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        </form>
        <button type="button" class="btn btn-success" style="float: left; font-family: 'Yekan'; margin-top: 60px;" onclick="addProduct();">ارسال اطلاعات</button>
    </div>

<script>
function addProduct()
{
    var txt = $('#txtName').val();
    if(txt.length > 3)
    {
        document.formNews.submit();
    }
    else
    {
        alert('تمامی گزینه ها را به درستی تکمیل نمائید.')
    }
}
</script>
    
</div>
<?php include 'footer.php'; ?>

