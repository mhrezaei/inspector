<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
require_once SITE_ROOT . '/functions/fn.pagination.php';
if(checkUserIsLogedIn())
{
    if(isset($_POST['Name']))
    {
        $pi = findPatientById(htmlCoding($_POST['did']));
        if($pi)
        {
//            $date1 = explode('/', htmlCoding($_POST['Ppcal2']));
//            $date1 = pmktime(0, 0, 0, $date1[1], $date1[2], $date1[0]);
            
            $date2 = explode('/', htmlCoding($_POST['Ppcal2']));
            $date2 = pmktime(0, 0, 0, $date2[1], $date2[2], $date2[0]);
            
            if(strlen($_POST['Ppcal3']) > 6)
            {
                $date3 = explode('/', htmlCoding($_POST['Ppcal3']));
                $date3 = pmktime(0, 0, 0, $date3[1], $date3[2], $date3[0]);
                updateOneFieldFromTable('patients', 'hospitalizationDate', $date3, htmlCoding($_POST['did']));
                
            }
            
            if(strlen($_POST['Ppcal4']) > 6)
            {
                $date4 = explode('/', htmlCoding($_POST['Ppcal4']));
                $date4 = pmktime(0, 0, 0, $date4[1], $date4[2], $date4[0]);
                updateOneFieldFromTable('patients', 'brainDeathDate', $date4, htmlCoding($_POST['did']));
                
            }
            
            $pLog = addPatientsLog(htmlCoding($_POST['did']), $_SESSION['user']['id'], htmlCoding($_POST['SecondGCS']), htmlCoding($_POST['HospitalName']), htmlCoding($_POST['Section']), htmlCoding($_POST['TypeOfSection']), htmlCoding($_POST['Presentation']), htmlCoding(strtoupper($_POST['Breath'])), htmlCoding(strtoupper($_POST['BodyMovement'])), htmlCoding(strtoupper($_POST['CoughR'])), htmlCoding(strtoupper($_POST['FaceMovement'])), htmlCoding(strtoupper($_POST['GagR'])), htmlCoding(strtoupper($_POST['CorneaR'])), htmlCoding(strtoupper($_POST['PupilR'])), htmlCoding(strtoupper($_POST['Sedation'])), $date2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            
            if(!$pLog)
            {
                $pLog = addPatientsLog(htmlCoding($_POST['did']), $_SESSION['user']['id'], htmlCoding($_POST['SecondGCS']), htmlCoding($_POST['HospitalName']), htmlCoding($_POST['Section']), htmlCoding($_POST['TypeOfSection']), htmlCoding($_POST['Presentation']), htmlCoding(strtoupper($_POST['Breath'])), htmlCoding(strtoupper($_POST['BodyMovement'])), htmlCoding(strtoupper($_POST['CoughR'])), htmlCoding(strtoupper($_POST['FaceMovement'])), htmlCoding(strtoupper($_POST['GagR'])), htmlCoding(strtoupper($_POST['CorneaR'])), htmlCoding(strtoupper($_POST['PupilR'])), htmlCoding(strtoupper($_POST['Sedation'])), $date2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            }
            
            updateOneFieldFromTable('patients', 'name', htmlCoding($_POST['Name']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'age', htmlCoding($_POST['Age']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'weight', htmlCoding($_POST['Weight']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'firstGCS', htmlCoding($_POST['FirstGCS']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'secondGCS', htmlCoding($_POST['SecondGCS']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'hospitalName', htmlCoding($_POST['HospitalName']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'section', htmlCoding($_POST['Section']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'type_of_section', htmlCoding($_POST['TypeOfSection']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'cause', htmlCoding($_POST['Cause']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'detail', htmlCoding($_POST['Detail']), htmlCoding($_POST['did']));
            //updateOneFieldFromTable('patients', 'addDate', $date1, htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'lastUpdate', $date2, htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'presentation', htmlCoding($_POST['Presentation']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'status', htmlCoding($_POST['Status']), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'breath', htmlCoding(strtoupper($_POST['Breath'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'body_Movement', htmlCoding(strtoupper($_POST['BodyMovement'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'cough_R', htmlCoding(strtoupper($_POST['CoughR'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'face_Movement', htmlCoding(strtoupper($_POST['FaceMovement'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'gag_R', htmlCoding(strtoupper($_POST['GagR'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'cornea_R', htmlCoding(strtoupper($_POST['CorneaR'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'pupil_R', htmlCoding(strtoupper($_POST['PupilR'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'sedation', htmlCoding(strtoupper($_POST['Sedation'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'typeList', htmlCoding(strtoupper($_POST['TypeList'])), htmlCoding($_POST['did']));
            updateOneFieldFromTable('patients', 'coordinatorName', htmlCoding(strtoupper($_POST['CoordinatorName'])), htmlCoding($_POST['did']));
            
            $pTest = findPatientTestByPatientsId(htmlCoding($_POST['did']));
            if($pTest)
            {
                updateOneFieldFromTable('patient_test', 'OUT_PUT', htmlCoding($_POST['OUTPUT']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'T', htmlCoding($_POST['T']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'BP', htmlCoding($_POST['BP']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'AST', htmlCoding($_POST['AST']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'ALT', htmlCoding($_POST['ALT']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'WBC', htmlCoding($_POST['WBC']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'BUN', htmlCoding($_POST['BUN']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'K', htmlCoding($_POST['K']), $pTest['id']);
                updateOneFieldFromTable('patient_test', 'NA', htmlCoding($_POST['NA']), $pTest['id']);
            }
            
            echo 'OK';
        }
        else
        {
            echo 'NOK';
        }
    }
    
    if(isset($_POST['confirmDel']) && is_numeric($_POST['confirmDel']))
    {
        $patient = findPatientById(htmlCoding($_POST['confirmDel']));
        if($patient && $patient['tracking'] == 1)
        {
            updateOneFieldFromTable('patients', 'tracking', 2, htmlCoding($_POST['confirmDel']));
            echo 'OK';
        }
        else
        {
            echo 'NOK';
        }
    }
    
    if(isset($_POST['confirmUndo']) && is_numeric($_POST['confirmUndo']))
    {
        $patient = findPatientById(htmlCoding($_POST['confirmUndo']));
        if($patient && $patient['tracking'] == 2)
        {
            updateOneFieldFromTable('patients', 'tracking', 1, htmlCoding($_POST['confirmUndo']));
            echo 'OK';
        }
        else
        {
            echo 'NOK';
        }
    }
    
    if(isset($_POST['addName']))
    {
        $pt = checkPatientDuplicatedInsert(htmlCoding($_POST['addName']), htmlCoding($_POST['addAge']), htmlCoding($_POST['addWeight']), htmlCoding($_POST['addFirstGCS']), htmlCoding($_POST['addHospitalName']), htmlCoding($_POST['addSection']), 1);
        if($pt)
        {
            echo pdate('Y/n/d', $pt['addDate']);
        }
        else
        {
            echo 'OK';
        }
    }
    
    if(isset($_POST['confirmDelPLog']) && is_numeric($_POST['confirmDelPLog']))
    {
        updateOneFieldFromTable('patient_log', 'status', 2, htmlCoding($_POST['confirmDelPLog']));
        echo 'OK';
    }
}