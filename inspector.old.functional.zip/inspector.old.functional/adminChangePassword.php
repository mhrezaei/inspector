<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        header('location: ' . $uri . '/logOut');
        exit;
    }
}
$msg = '';

if(isset($_POST['txtOldPassWord']))
{
    $admin = findInspectorById(1);
    if($admin)
    {
        if(md5(sha1(htmlCoding($_POST['txtOldPassWord']))) == $admin['passWord'])
        {
            if($_POST['txtNewPassWord'] == $_POST['txtNewPassWordAgain'])
            {
                updateOneFieldFromTable('users', 'passWord', md5(sha1(htmlCoding($_POST['txtNewPassWordAgain']))), 1);
                $msg = 1;
            }
            else
            {
                $msg = 2;
            }
        }
        else
        {
            $msg = 3;
        }
    }
    else
    {
        header('location: ' . $url . '/logOut');
        exit;
    }
}

include 'header.php';

?>

<title>بخش مدیریت سامانه بازرسین | تغییر رمز عبور</title>

<div class="contentMain" style="min-height: 900px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;">تغییر رمز عبور </div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    <?php if($msg == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">رمز عبور با موفقیت تغییر یافت، جهت ادامه فعالیت باید دوباره وارد شوید.</div>
    <?php }elseif($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">رمز عبور جدید و تکرار رمز عبور جدید برابر نمی باشد.</div>
    <?php }elseif($msg == 3){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">رمز عبور قبلی صحیح نمی باشد.</div>
    <?php } ?>
    <div style="width: 920px; margin-right: 20px; margin-top: 20px;">
        <form action="" method="post" name="formNews" enctype="multipart/form-data">
        
        <div style="width: 100px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">رمز عبور قبلی: <span style="color: red;">*</span></div>
        <div style="float: left; width: 820px; height: 50px;">
            <input type="password" class="form-control" id="txtOldPassWord" name="txtOldPassWord" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 100px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">رمز عبور جدید: <span style="color: red;">*</span></div>
        <div style="float: left; width: 820px; height: 50px;">
            <input type="password" class="form-control" id="txtNewPassWord" name="txtNewPassWord" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        <div style="width: 100px; float: right; font-family: 'Nassim'; font-size: 16px; line-height: 28px; height: 50px;">تکرار رمز عبور: <span style="color: red;">*</span></div>
        <div style="float: left; width: 820px; height: 50px;">
            <input type="password" class="form-control" id="txtNewPassWordAgain" name="txtNewPassWordAgain" style="font-family: 'Yekan'; margin-right: 5px; width: 500px;">
        </div>
        <div style="clear: both;"></div>
        
        </form>
        <button type="button" class="btn btn-success" style="float: left; font-family: 'Yekan'; margin-top: 60px;" onclick="addProduct();">ارسال اطلاعات</button>
    </div>

<script>
function addProduct()
{
    var txtOldPassWord = $('#txtOldPassWord').val();
    var txtNewPassWord = $('#txtNewPassWord').val();
    var txtNewPassWordAgain = $('#txtNewPassWordAgain').val();
    if(txtOldPassWord.length > 5 && txtNewPassWord.length > 5 && txtNewPassWord == txtNewPassWordAgain)
    {
        document.formNews.submit();
    }
    else
    {
        alert('تمامی گزینه ها را به درستی تکمیل نمائید.')
    }
}
</script>
    
</div>
<?php include 'footer.php'; ?>

