<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';

userLogOut();
header('location: ' . $uri . '/login');
exit;


?>