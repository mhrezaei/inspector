<style type="text/css">
    img.pcalBtn{
        margin-top: 10px;
    }
</style>
<script type="text/javascript">
    function confirmDel(id)
    {
        var txtName = $("#txtName" + id).val();
        if(confirm('آیا مایل به حذف بیمار: ' + txtName + 'می باشید؟'))
            {
            $.ajax({
                type: "POST",
                url: "ajax.patient.php",
                cache: false,
                data: {confirmDel: id}
            }).done(function(Data){
                if(Data == 'OK')
                    {
                    $("#orginalDataRow" + id).hide(500, function(){
                        location.reload();
                    });
                }
                else
                    {
                    alert('خطایی رخ داده است لطفاً مجدداً تلاش نمائید.')
                }
            });
        }
    }
    function confirmDelPLog(id)
    {
        if(confirm('آیا مایل به حذف این رکورد می باشید؟'))
            {
            $.ajax({
                type: "POST",
                url: "ajax.patient.php",
                cache: false,
                data: {confirmDelPLog: id}
            }).done(function(Data){
                if(Data == 'OK')
                    {
                        location.reload();
                }
                else
                    {
                    alert('خطایی رخ داده است لطفاً مجدداً تلاش نمائید.');
                }
            });
        }
    }
    function confirmUndo(id)
    {
        var txtName = $("#txtName" + id).val();
        if(confirm('آیا مایل به بازگرداندن بیمار: ' + txtName + 'می باشید؟'))
            {
            $.ajax({
                type: "POST",
                url: "ajax.patient.php",
                cache: false,
                data: {confirmUndo: id}
            }).done(function(Data){
                if(Data == 'OK')
                    {
                    $("#orginalDataRow" + id).hide(500, function(){
                        location.reload();
                    });
                }
                else
                    {
                    alert('خطایی رخ داده است لطفاً مجدداً تلاش نمائید.')
                }
            });
        }
    }
    function editOneRow(id)
    {
        var org = $("#orginalDataRow" + id) ;
        var edt = $("#editableDataRow" + id);
        var edt2 = $("#editableDataRow2" + id);
        var log = $('#logDataRow' + id);
        log.hide(500, function(){
            org.hide(500, function(){
                edt.show(500);
                edt2.show(500);
            });
        });
    }
    function cancelEditOneRow(id)
    {
        var org = $("#orginalDataRow" + id) ;
        var edt = $("#editableDataRow" + id);
        var edt2 = $("#editableDataRow2" + id);
        edt2.hide(500);
        edt.hide(500, function(){
            org.show(500);
        });
    }
    function showLogDataRow(id)
    {
        var log = $('#logDataRow' + id);
        log.toggle();
    }
    function editOneRowData(id)
    {
        var txtName = $("#txtName" + id).val();
        var txtAge = $("#txtAge" + id).val();
        var txtWeight = $("#txtWeight" + id).val();
        var txtFirstGCS = $("#txtFirstGCS" + id).val();
        var txtSecondGCS = $("#txtSecondGCS" + id).val();
        var cbHospitalName = $("#cbHospitalName" + id).val();
        var cbSection = $("#cbSection" + id).val();
        var txtTypeOfSection = $("#txtTypeOfSection" + id).val();
        var txtCause = $("#txtCause" + id).val();
        var txtDetail = $("#txtDetail" + id).val();
        var pcal1 = $("#pcal1-" + id).val();
        var pcal2 = $("#pcal2-" + id).val();
        var pcal3 = $("#pcal3-" + id).val();
        var pcal4 = $("#pcal4-" + id).val();
        var txtCoordinatorName = $("#txtCoordinatorName" + id).val();
        var cbPresentation = $("#cbPresentation" + id).val();
        var cbStatus = $("#cbStatus" + id).val();
        var txtBreath = $("#txtBreath" + id).val();
        var txtBodyMovement = $("#txtBodyMovement" + id).val();
        var txtCoughR = $("#txtCoughR" + id).val();
        var txtFaceMovement = $("#txtFaceMovement" + id).val();
        var txtGagR = $("#txtGagR" + id).val();
        var txtCorneaR = $("#txtCorneaR" + id).val();
        var txtPupilR = $("#txtPupilR" + id).val();
        var cbSedation = $("#cbSedation" + id).val();
        var cbTypeList = $("#cbTypeList" + id).val();
        var txtNA = $("#txtNA" + id).val();
        var txtK = $("#txtK" + id).val();
        var txtBUN = $("#txtBUN" + id).val();
        var txtWBC = $("#txtWBC" + id).val();
        var txtALT = $("#txtALT" + id).val();
        var txtAST = $("#txtAST" + id).val();
        var txtBP = $("#txtBP" + id).val();
        var txtT = $("#txtT" + id).val();
        var txtOUTPUT = $("#txtOUTPUT" + id).val();

        if(txtName.length > 3 && txtFirstGCS.length > 0 && cbHospitalName > 0 && cbSection > 0 && cbPresentation > 0 && cbStatus > 0 && pcal2.length > 6)
            {
            $.ajax({
                type: "POST",
                url: "ajax.patient.php",
                cache: false,
                data: { Name: txtName,
                    Age: txtAge,
                    Weight: txtWeight,
                    SecondGCS: txtSecondGCS,
                    FirstGCS: txtFirstGCS,
                    HospitalName: cbHospitalName,
                    Section: cbSection,
                    TypeOfSection: txtTypeOfSection,
                    Cause: txtCause,
                    Detail: txtDetail,
                    Ppcal1: pcal1,
                    Ppcal2: pcal2,
                    Ppcal3: pcal3,
                    Ppcal4: pcal4,
                    CoordinatorName: txtCoordinatorName,
                    Presentation: cbPresentation,
                    Status: cbStatus,
                    Breath: txtBreath,
                    BodyMovement: txtBodyMovement,
                    CoughR: txtCoughR,
                    FaceMovement: txtFaceMovement,
                    GagR: txtGagR,
                    CorneaR: txtCorneaR,
                    PupilR: txtPupilR,
                    Sedation: cbSedation,
                    TypeList: cbTypeList,
                    NA: txtNA,
                    K: txtK,
                    BUN: txtBUN,
                    WBC: txtWBC,
                    ALT: txtALT,
                    AST: txtAST,
                    BP: txtBP,
                    T: txtT,
                    OUTPUT: txtOUTPUT,
                    did: id
                }
            }).done(function(Data){
                if(Data == 'OK')
                    {
                    location.reload();
                }
                else
                    {
                    alert('خطایی رخ داده است لطفاً مجدداً تلاش نمائید.')
                }
            });
        }
        else
            {
            alert('گزینه های اصلی را به درستی تکمیل نمائید');
        }
    }
</script>

<div class="contentMain" style="min-height: 900px; background: #ECF4FC; width: 1760px;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;"><?php echo $pageTitle; ?></div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    <?php if($haveST != 'showOnePatient'){ ?>
    <form action="<?php echo $searchUrl; ?>" method="get" class="form-inline" role="form">
        <div class="form-group" style="float: right;">
            <label for="cbSort" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">چیدمان حروف الفبا بر اساس: </label>
            <select class="form-control" style="width: 250px; margin-right: 36px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbSort" id="cbSort">
                <option value="9" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 9){echo 'selected="selected"';}?>>تاریخ بروز رسانی</option>
                <option value="1" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 1){echo 'selected="selected"';}?>>نام بیمار</option>
                <option value="2" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 2){echo 'selected="selected"';}?>>نام بیمارستان</option>
                <option value="3" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 3){echo 'selected="selected"';}?>>GCS اولیه</option>
                <option value="4" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 4){echo 'selected="selected"';}?>>GCS تغییر یافته</option>
                <option value="5" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 5){echo 'selected="selected"';}?>>بازرس</option>
                <option value="6" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 6){echo 'selected="selected"';}elseif(!isset($_GET['cbSort'])){echo 'selected="selected"';}?>>تاریخ ثبت</option>
                <option value="7" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 7){echo 'selected="selected"';}?>>معرفی</option>
                <option value="8" <?php if(isset($_GET['cbSort']) && $_GET['cbSort'] == 8){echo 'selected="selected"';}?>>وضعیت بیمار</option>
            </select>
        </div>

        <div class="form-group" style="float: right;">
            <label for="cbSortType" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">نوع چیدمان: </label>
            <select class="form-control" style="width: 226px; margin-right: 36px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbSortType" id="cbSortType">
                <option value="1" <?php if(isset($_GET['cbSortType']) && $_GET['cbSortType'] == 1){echo 'selected="selected"';}?>>نزولی</option>
                <option value="2" <?php if(isset($_GET['cbSortType']) && $_GET['cbSortType'] == 2){echo 'selected="selected"';}?>>صعودی</option>
            </select>
        </div>
        <div style="clear: both;"></div>
        <div class="form-group" style="float: right;">
            <label style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">فیلتر کردن اطلاعات </label>
            <label for="cbInspector" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">نام بازرس: </label>
            <select class="form-control" style="width: 250px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbInspector" id="cbInspector">
                <option value="0">هیچ کدام</option>
                <?php
                    $inList = DatabaseHandler::GetAll("SELECT * FROM `users` WHERE `id` != 1 AND `status` = 1 ");
                    if($inList)
                    {
                        for($i = 0; $i < count($inList); $i++)
                        {
                            if(isset($_GET['cbInspector']) && $_GET['cbInspector'] > 0)
                            {
                                if($inList[$i]['id'] == $_GET['cbInspector'])
                                {
                                    $selected = 'selected="selected"';
                                }
                                else
                                {
                                    $selected = '';
                                }
                            }
                            else
                            {
                                $selected = '';
                            }
                            echo '<option value="' . $inList[$i]['id'] . '"' . $selected . '>' . $inList[$i]['fullName'] . '</option>';
                        }
                    }
                ?>
            </select>
        </div>

        <div class="form-group" style="float: right;">
            <label for="cbHospitalF" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">نام بیمارستان: </label>
            <select class="form-control" style="width: 250px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbHospitalF" id="cbHospitalF">
                <option value="0">هیچ کدام</option>
                <?php
                    if($hospitals)
                    {
                        for($i = 0; $i < count($hospitals); $i++)
                        {
                            if(isset($_GET['cbHospitalF']) && $_GET['cbHospitalF'] > 0)
                            {
                                if($hospitals[$i]['id'] == $_GET['cbHospitalF'])
                                {
                                    $selected = 'selected="selected"';
                                }
                                else
                                {
                                    $selected = '';
                                }
                            }
                            else
                            {
                                $selected = '';
                            }
                            echo '<option value="' . $hospitals[$i]['id'] . '"' . $selected . '>' . $hospitals[$i]['name'] . '</option>';
                        }
                    }
                ?>
            </select>
        </div>

        <div style="clear: both;"></div>
        <div class="form-group" style="float: right;">
            <label for="txtSearch" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">جستجو: </label>
            <input type="text" class="form-control" placeholder="نام بیمار، علت یا توضیحات" id="txtSearch" name="txtSearch" style="font-family: 'Yekan'; margin-right: 122px; width: 435px;" value="<?php if(isset($_GET['txtSearch']) && strlen($_GET['txtSearch']) > 3){echo htmlCoding($_GET['txtSearch']);}?>">
        </div>

        <button type="submit" class="btn btn-primary btn-sm" style="font-family: 'Nassim'; margin-right: 2px; margin-top: 1px; position: relative; font-size: 13px;">جستجو کردن</button>
        <button type="button" class="btn btn-warning btn-sm" style="font-family: 'Nassim'; margin-right: 2px; margin-top: 1px; position: relative; font-size: 13px;" onclick="window.location = '<?php echo $uri . '/showAllPatients' ?>'">حذف فیلتر ها</button>
    </form>
    <div style="clear: both;"></div>
    <?php } ?>

    <!--<div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خبر مورد نظر با موفقیت ثبت گردید.</div>-->
    <?php if($ms == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بیمارستان مورد نظر با موفقیت حذف گردید.</div>
        <?php }elseif($ms == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بمارستان مورد نظر یافت نشد.</div>
        <?php } ?>
    <?php if($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto; margin-top: 20px;">بیماری یافت نشد.</div>
        <?php } ?>
    <div style="width: 1710px; margin-right: 20px; margin-top: 20px;">
        <?php if($msg == 1){ ?>
            <table class="table" style="direction: rtl;">
                <thead>
                    <tr style="direction: rtl;">
                        <th style="text-align: right; width: 50px;" class="tableExtra">#</th>
                        <th style="text-align: right; width: 150px;" class="tableExtra">نام بیمار</th>
                        <th style="text-align: right; width: 80px;" class="tableExtra">سن و وزن</th>
                        <th style="text-align: right; width: 100px;" class="tableExtra">GCS</th>
                        <th style="text-align: right; width: 100px;" class="tableExtra">نام بیمارستان</th>
                        <th style="text-align: right; width: 100px;" class="tableExtra">بخش</th>
                        <th style="text-align: center; width: 150px;" class="tableExtra">بازرس</th>
                        <th style="text-align: right; width: 150px;" class="tableExtra">علت</th>
                        <th style="text-align: right; width: 150px;" class="tableExtra">توضیحات</th>
                        <th style="text-align: center; width: 50px;" class="tableExtra">معرفی</th>
                        <th style="text-align: center; width: 290px;" class="tableExtra" colspan="2">رفلکس ها</th>
                        <th style="text-align: right; width: 100px;" class="tableExtra">وضعیت بیمار</th>
                        <th style="text-align: center; width: 160px;" class="tableExtra">تاریخ</th>
                        <th style="text-align: center; width: 80px;" class="tableExtra">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < count($patient); $i++){ ?>
                        <?php
                            if($patient[$i]['status'] == 1)
                            {
                                $bg = '#ffffff';
                                $color = '#000000';
                            }
                            elseif($patient[$i]['status'] == 2)
                            {
                                $bg = '#f0ff00';
                                $color = '#000000';
                            }
                            elseif($patient[$i]['status'] == 3)
                            {
                                $bg = '#0042ff';
                                $color = '#ffffff';
                            }
                            elseif($patient[$i]['status'] == 4)
                            {
                                $bg = '#02d439';
                                $color = '#ffffff';
                            }
                            elseif($patient[$i]['status'] == 5)
                            {
                                $bg = '#000000';
                                $color = '#ffffff';
                            }
                            elseif($patient[$i]['status'] == 6)
                            {
                                $bg = '#ff0000';
                                $color = '#ffffff';
                            }
                            elseif($patient[$i]['status'] == 7)
                            {
                                $bg = '#8a00ff';
                                $color = '#ffffff';
                            }
                        ?>
                        <tr style="direction: rtl; background: <?php echo $bg; ?>; color: <?php echo $color; ?>;" id="orginalDataRow<?php echo $patient[$i]['id']; ?>">
                            <td style="text-align: right; width: 50px;" class="tableExtra"><?php echo ++$start; ?></td>
                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php echo $patient[$i]['name']; ?></td>
                            <td class="tableExtra" style="text-align: right; width: 80px;">
                                سن: <?php echo $patient[$i]['age']; ?>
                                <br>
                                و.ب: <?php echo $patient[$i]['weight']; ?>
                            </td>
                            <td class="tableExtra" style="text-align: right; width: 100px;">
                                اولیه: <?php echo $patient[$i]['firstGCS']; ?>
                                <br>
                                تغییر یافته: <?php echo $patient[$i]['secondGCS']; ?>
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra"><?php $hs = findHospitalById($patient[$i]['hospitalName']); echo $hs['name']; ?></td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                <?php   if($patient[$i]['section'] == 1)
                                    {
                                        echo 'CCU';
                                    }
                                    elseif($patient[$i]['section'] == 2)
                                    {
                                        echo 'ICU';
                                    }
                                    elseif($patient[$i]['section'] == 3)
                                    {
                                        echo 'اورژانس';
                                    }
                                    elseif($patient[$i]['section'] == 4)
                                    {
                                        echo 'بخش';
                                    }
                                ?>
                                <?php echo ' ' . $patient[$i]['type_of_section']; ?>
                            </td>
                            <td style="text-align: center; width: 150px;" class="tableExtra"><?php $in = findInspectorById($patient[$i]['inspector']); echo $in['fullName']; ?></td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                <?php echo $patient[$i]['cause']; ?>
                            </td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                <?php echo $patient[$i]['detail']; ?>
                            </td>
                            <td style="text-align: center; width: 50px;" class="tableExtra">
                                <?php   if($patient[$i]['presentation'] == 1)
                                    {
                                        echo 'IP';
                                    }
                                    elseif($patient[$i]['presentation'] == 2)
                                    {
                                        echo 'TDDP';
                                    }
                                    elseif($patient[$i]['presentation'] == 3)
                                    {
                                        echo 'HR';
                                    }
                                ?>
                            </td>
                            <td style="text-align: left; width: 170px; direction: ltr;" class="tableExtra">
                                Breathing: <?php echo $patient[$i]['breath']; ?>
                                <br>
                                Body Movement: <?php echo $patient[$i]['body_Movement']; ?>
                                <br>
                                Cough R: <?php echo $patient[$i]['cough_R']; ?>
                                <br>
                                Face Movement: <?php echo $patient[$i]['face_Movement']; ?>
                            </td>
                            <td style="text-align: left; width: 120px; direction: ltr;" class="tableExtra">
                                Gag R: <?php echo $patient[$i]['gag_R']; ?>
                                <br>
                                Cornea R: <?php echo $patient[$i]['cornea_R']; ?>
                                <br>
                                Pupil R: <?php echo $patient[$i]['pupil_R']; ?>
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                <?php   if($patient[$i]['status'] == 1)
                                    {
                                        echo 'بیمار جدید';
                                    }
                                    elseif($patient[$i]['status'] == 2)
                                    {
                                        echo 'درحال پیگیری';
                                    }
                                    elseif($patient[$i]['status'] == 3)
                                    {
                                        echo 'مرگ مغزی نیست';
                                    }
                                    elseif($patient[$i]['status'] == 4)
                                    {
                                        echo 'اهدا شده';
                                    }
                                    elseif($patient[$i]['status'] == 5)
                                    {
                                        echo 'فوت شده';
                                    }
                                    elseif($patient[$i]['status'] == 6)
                                    {
                                        echo 'غیر قابل اهدا';
                                    }
                                    elseif($patient[$i]['status'] == 7)
                                    {
                                        echo 'بهبود یافته';
                                    }
                                       
                                    if($haveST == 'showAllPatients')
                                    {
                                        echo '<br>
                                            نوع لیست:
                                            <br>';
                                        if($patient[$i]['typeList'] == 1)
                                        {
                                            echo 'GCS3 مرگ مغزی شده';
                                        }
                                        elseif($patient[$i]['typeList'] == 2)
                                        {
                                            echo 'GCS3 مرگ مغزی نشده';
                                        }
                                        elseif($patient[$i]['typeList'] == 3)
                                        {
                                            echo 'GCS 4,5';
                                        }
                                        elseif($patient[$i]['typeList'] == 4)
                                        {
                                            echo 'موارد نامناسب';
                                        }
                                    }
                                ?>
                            </td>
                            <td style="text-align: center; width: 160px;" class="tableExtra">
                                ثبت: <?php echo pdate('Y/n/d', $patient[$i]['addDate']); ?>
                                <br>
                                بروزرسانی:
                                <?php   if($patient[$i]['lastUpdate'] > 10000)
                                    {
                                        echo pdate('Y/n/d', $patient[$i]['lastUpdate']);
                                    }
                                    else
                                    {
                                        echo 'هرگز';
                                    }
                                ?>
                                <?php if($haveST == 'showAllGCS3PatientsY'){ ?>
                                    مرگ مغزی:
                                    <?php   if($patient[$i]['brainDeathDate'] > 10000)
                                        {
                                            echo pdate('Y/n/d', $patient[$i]['brainDeathDate']);
                                        }
                                        else
                                        {
                                            echo 'هرگز';
                                        }
                                    ?>
                                <?php } ?>
                            </td>
                            <td style="text-align: center; width: 80px;" class="tableExtra">
                                <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-pencil" title="ویرایش" style="color: green; cursor: pointer; position: relative; padding: 5px;" onclick="editOneRow(<?php echo $patient[$i]['id']; ?>);"></button>
                                <?php if($haveST == 'showAllPatientsDeleted'){ ?>
                                    <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-share-alt" title="بازگرداندن" style="color: green; cursor: pointer; position: relative; padding: 5px;" onclick="confirmUndo(<?php echo $patient[$i]['id']; ?>);"></button>
                                <?php }else{ ?>
                                    <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-remove" title="حذف" style="color: red; cursor: pointer; position: relative; padding: 5px" onclick="confirmDel(<?php echo $patient[$i]['id']; ?>);"></button>
                                <?php } ?>
                                <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-list" title="لیست تغییرات بیمار" style="color: white; cursor: pointer; position: relative; margin-top: 2px; width: 50px;" onclick="showLogDataRow(<?php echo $patient[$i]['id']; ?>);"></button>
                            </td>
                        </tr>


                        <tr style="direction: rtl; background: <?php echo $bg; ?>; color: <?php echo $color; ?>; display: none;" id="editableDataRow<?php echo $patient[$i]['id']; ?>">
                            <td style="text-align: right; width: 50px;" class="tableExtra"><?php echo $start; ?></td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                نام بیمار:
                                <input type="text" class="form-control" placeholder="نام و نام خوانوادگی" id="txtName<?php echo $patient[$i]['id']; ?>" name="txtName" style="font-family: 'Yekan'; margin-right: 5px; width: 140px;" value="<?php echo $patient[$i]['name']; ?> ">
                                <br>
                                نام کوردیناتور:
                                <input type="text" class="form-control" placeholder="نام و نام خوانوادگی" id="txtCoordinatorName<?php echo $patient[$i]['id']; ?>" name="txtCoordinatorName" style="font-family: 'Yekan'; margin-right: 5px; width: 140px;" value="<?php echo $patient[$i]['coordinatorName']; ?> ">
                            </td>
                            <td style="text-align: right; width: 80px;" class="tableExtra">
                                سن:
                                <input type="text" class="form-control" placeholder="سن" id="txtAge<?php echo $patient[$i]['id']; ?>" name="txtAge" style="font-family: 'Yekan'; margin-right: 5px; width: 50px;" value="<?php echo $patient[$i]['age']; ?>">
                                <br>
                                وضعیت بدنی:
                                <select class="form-control" style="width: 70px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="txtWeight" id="txtWeight<?php echo $patient[$i]['id']; ?>">
                                    <option value="چاق"<?php if($patient[$i]['weight'] == 'چاق'){echo 'selected="selected"';} ?>>چاق</option>
                                    <option value="متوسط"<?php if($patient[$i]['weight'] == 'متوسط'){echo 'selected="selected"';} ?>>متوسط</option>
                                    <option value="لاغر"<?php if($patient[$i]['weight'] == 'لاغر'){echo 'selected="selected"';} ?>>لاغر</option>
                                </select>
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                اولیه:
                                <input type="text" class="form-control" placeholder="GCS اولیه" id="txtFirstGCS<?php echo $patient[$i]['id']; ?>" name="txtFirstGCS" style="font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $patient[$i]['firstGCS']; ?>">
                                <br>
                                تغییریافته:
                                <input type="text" class="form-control" placeholder="GCS تغییر یافته" id="txtSecondGCS<?php echo $patient[$i]['id']; ?>" name="txtSecondGCS" style="font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $patient[$i]['secondGCS']; ?>">
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                بیمارستان:
                                <select class="form-control" style="width: 100px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbHospitalName" id="cbHospitalName<?php echo $patient[$i]['id']; ?>">
                                    <option value="0">انتخاب کنید</option>
                                    <?php
                                        echo $patient[$i]['hospitalName'];
                                        for($a = 0; $a < count($hospitals); $a++)
                                        {
                                            if($patient[$i]['hospitalName'] == $hospitals[$a]['id'])
                                            {
                                                $selected = 'selected="selected"';
                                            }
                                            else
                                            {
                                                $selected = '';
                                            }
                                            echo '<option value="' . $hospitals[$a]['id'] . '"' . $selected . '>' . $hospitals[$a]['name'] . '</option>';
                                        }
                                    ?>
                                </select>
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                بخش:
                                <select class="form-control" style="width: 90px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbSection" id="cbSection<?php echo $patient[$i]['id']; ?>">
                                    <option value="0">انتخاب کنید</option>
                                    <option value="1" <?php if($patient[$i]['section'] == 1){echo 'selected="selected"';} ?>>CCU</option>
                                    <option value="2"<?php if($patient[$i]['section'] == 2){echo 'selected="selected"';} ?>>ICU</option>
                                    <option value="3"<?php if($patient[$i]['section'] == 3){echo 'selected="selected"';} ?>>اورژانس</option>
                                    <option value="4"<?php if($patient[$i]['section'] == 4){echo 'selected="selected"';} ?>>بخش</option>
                                </select>
                                <br>
                                نوع بخش:
                                <input type="text" class="form-control" placeholder="نوع بخش" id="txtTypeOfSection<?php echo $patient[$i]['id']; ?>" name="txtTypeOfSection" style="font-family: 'Yekan'; margin-right: 5px; width: 90px;" value="<?php echo $patient[$i]['type_of_section']; ?>">
                            </td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                بازرس:
                                <br>
                                <?php $in = findInspectorById($patient[$i]['inspector']); echo $in['fullName']; ?>
                            </td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                علت:
                                <input type="text" class="form-control" placeholder="علت" id="txtCause<?php echo $patient[$i]['id']; ?>" name="txtCause" style="font-family: 'Yekan'; margin-right: 5px; width: 150px;" value="<?php echo $patient[$i]['cause']; ?>">
                            </td>
                            <td style="text-align: right; width: 150px;" class="tableExtra">
                                توضیحات:
                                <input type="text" class="form-control" placeholder="توضیحات" id="txtDetail<?php echo $patient[$i]['id']; ?>" name="txtDetail" style="font-family: 'Yekan'; margin-right: 5px; width: 150px;" value="<?php echo $patient[$i]['detail']; ?>">    
                            </td>
                            <td style="text-align: right; width: 50px;" class="tableExtra">
                                معرفی:
                                <select class="form-control" style="width: 70px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbPresentation" id="cbPresentation<?php echo $patient[$i]['id']; ?>">
                                    <option value="0">انتخاب کنید</option>
                                    <option value="1"<?php if($patient[$i]['presentation'] == 1){echo 'selected="selected"';} ?>>IP</option>
                                    <option value="2"<?php if($patient[$i]['presentation'] == 2){echo 'selected="selected"';} ?>>TDDP</option>
                                    <option value="3"<?php if($patient[$i]['presentation'] == 3){echo 'selected="selected"';} ?>>HR</option>
                                </select> 
                            </td>
                            <td style="text-align: left; width: 170px; direction: ltr;" class="tableExtra">
                                Breathing:<br>
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtBreath<?php echo $patient[$i]['id']; ?>" name="txtBreath">
                                    <option value="P" <?php if($patient[$i]['breath'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['breath'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                                <br>
                                Body Movement:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtBodyMovement<?php echo $patient[$i]['id']; ?>" name="txtBodyMovement">
                                    <option value="P" <?php if($patient[$i]['body_Movement'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['body_Movement'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                            </td>
                            <td style="text-align: left; width: 120px; direction: ltr;" class="tableExtra">
                                Gag R:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtGagR<?php echo $patient[$i]['id']; ?>" name="txtGagR">
                                    <option value="P" <?php if($patient[$i]['gag_R'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['gag_R'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                                <br>
                                Cornea R:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtCorneaR<?php echo $patient[$i]['id']; ?>" name="txtCorneaR">
                                    <option value="P" <?php if($patient[$i]['cornea_R'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['cornea_R'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                            </td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                وضعیت:
                                <select class="form-control" style="width: 90px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbStatus" id="cbStatus<?php echo $patient[$i]['id']; ?>">
                                    <option value="0">انتخاب کنید</option>
                                    <option value="1"<?php if($patient[$i]['status'] == 1){echo 'selected="selected"';} ?>>بیمار جدید</option>
                                    <option value="2"<?php if($patient[$i]['status'] == 2){echo 'selected="selected"';} ?>>درحال پیگیری</option>
                                    <option value="3"<?php if($patient[$i]['status'] == 3){echo 'selected="selected"';} ?>>مرگ مغزی نیست</option>
                                    <option value="4"<?php if($patient[$i]['status'] == 4){echo 'selected="selected"';} ?>>اهدا شده</option>
                                    <option value="5"<?php if($patient[$i]['status'] == 5){echo 'selected="selected"';} ?>>فوت شده</option>
                                    <option value="6"<?php if($patient[$i]['status'] == 6){echo 'selected="selected"';} ?>>غیر قابل اهدا</option>
                                    <option value="7"<?php if($patient[$i]['status'] == 7){echo 'selected="selected"';} ?>>بهبود یافته</option>
                                </select>
                                <br>
                                نوع لیست:
                                <select class="form-control" style="width: 90px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: right;" name="cbTypeList" id="cbTypeList<?php echo $patient[$i]['id']; ?>">
                                    <option value="0">انتخاب کنید</option>
                                    <option value="1"<?php if($patient[$i]['typeList'] == 1){echo 'selected="selected"';} ?>>GCS3 مرگ مغزی شده</option>
                                    <option value="2"<?php if($patient[$i]['typeList'] == 2){echo 'selected="selected"';} ?>>GCS3 مرگ مغزی نشده</option>
                                    <option value="3"<?php if($patient[$i]['typeList'] == 3){echo 'selected="selected"';} ?>>GCS 4,5</option>
                                    <option value="4"<?php if($patient[$i]['typeList'] == 4){echo 'selected="selected"';} ?>>موارد نامناسب</option>
                                </select>
                            </td>
                            <td style="text-align: right; width: 190px;" class="tableExtra">
                                ثبت:
                                <br>
                                <?php
                                    if(checkAdminIsLogedIn())
                                    {
                                ?>
                                <input type="text" class="form-control" id="pcal1-<?php echo $patient[$i]['id']; ?>" name="txtAddDate" style="font-family: 'Yekan'; margin-right: 2px; width: 80px; float: right; padding-right: 7px; padding-left: 7px; font-size: 13px;" value="<?php  echo pdate('Y/n/d', $patient[$i]['addDate']); ?>">
                                <script type="text/javascript">
                                    var objCal1<?php echo $patient[$i]['id']; ?> = new AMIB.persianCalendar( 'objCal1<?php echo $patient[$i]['id']; ?>', 'pcal1-<?php echo $patient[$i]['id']; ?>' );
                                </script>
                                <?php
                                    }
                                    else
                                    {
                                ?>
                                <input type="text" class="form-control" id="pcal1-<?php echo $patient[$i]['id']; ?>" disabled="disabled" name="txtAddDate" style="font-family: 'Yekan'; margin-right: 5px; width: 80px; float: right; padding-right: 7px; padding-left: 7px; font-size: 13px;" value="<?php  echo pdate('Y/n/d', $patient[$i]['addDate']); ?>">
                                <?php
                                    }
                                ?>
                                <br><br>
                                بروزرسانی:
                                <br>
                                <input type="text" class="form-control" id="pcal2-<?php echo $patient[$i]['id']; ?>" name="txtAddDate" style="font-family: 'Yekan'; margin-right: 2px; width: 80px; float: right; padding-right: 7px; padding-left: 7px; font-size: 13px;" value="<?php if($patient[$i]['lastUpdate'] > 1000) {echo pdate('Y/n/d', $patient[$i]['lastUpdate']);}else{echo pdate('Y/n/d');} ?>">
                                <script type="text/javascript">
                                    var objCal2<?php echo $patient[$i]['id']; ?> = new AMIB.persianCalendar( 'objCal2<?php echo $patient[$i]['id']; ?>', 'pcal2-<?php echo $patient[$i]['id']; ?>' );
                                </script>
                            </td>
                            <td style="text-align: center; width: 70px;" class="tableExtra">
                                <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-ok" title="تایید" style="color: green; cursor: pointer; position: relative;" onclick="editOneRowData(<?php echo $patient[$i]['id']; ?>);"></button>
                                <button type="button" class="btn btn-warning btn-sm glyphicon glyphicon-remove" title="انصراف" style="color: red; cursor: pointer; position: relative; margin-top: 5px;" onclick="cancelEditOneRow(<?php echo $patient[$i]['id']; ?>);"></button>
                            </td>
                        </tr>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <tr style="direction: rtl; background: <?php echo $bg; ?>; color: <?php echo $color; ?>; display: none" id="editableDataRow2<?php echo $patient[$i]['id']; ?>">
                            <td style="text-align: right; width: 50px; border: 0px; height: 100px;" class="tableExtra">
                                <div class="rotate" style="margin-top: 50px;">آزمایشات</div>
                            </td>
                            <td style="text-align: right; width: 1030px; border: 0px; height: 100px; border-top: 1px dashed;" class="tableExtra" colspan="9">
                                <?php 
                                    $pTest = findPatientTestByPatientsId($patient[$i]['id']);
                                    if($pTest)
                                    {
                                ?>
                                <div class="miniDivTable">
                                    NA:
                                    <input type="text" class="form-control" id="txtNA<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['NA']; ?>">
                                    K:
                                    <input type="text" class="form-control" id="txtK<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['K']; ?>">
                                </div>
                                
                                <div class="miniDivTable">
                                    BUN:
                                    <input type="text" class="form-control" id="txtBUN<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['BUN']; ?>">
                                    WBC:
                                    <input type="text" class="form-control" id="txtWBC<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['WBC']; ?>">
                                </div>
                                
                                <div class="miniDivTable">
                                    ALT:
                                    <input type="text" class="form-control" id="txtALT<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['ALT']; ?>">
                                    AST:
                                    <input type="text" class="form-control" id="txtAST<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['AST']; ?>">
                                </div>
                                
                                <div class="miniDivTable">
                                    BP:
                                    <input type="text" class="form-control" id="txtBP<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['BP']; ?>">
                                    T:
                                    <input type="text" class="form-control" id="txtT<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['T']; ?>">
                                </div>
                                
                                <div class="miniDivTable">
                                    OUT PUT:
                                    <input type="text" class="form-control" id="txtOUTPUT<?php echo $patient[$i]['id']; ?>" style="text-align: left; font-family: 'Yekan'; margin-right: 5px; width: 100px;" value="<?php echo $pTest['OUT_PUT']; ?>">
                                    Sedation:
                                    <select class="form-control" style="width: 100px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="cbSedation<?php echo $patient[$i]['id']; ?>" name="cbSedation">
                                        <option value="YES" <?php if($patient[$i]['sedation'] == 'YES'){echo 'selected="selected"';} ?> >YES</option>
                                        <option value="NO" <?php if($patient[$i]['sedation'] == 'NO'){echo 'selected="selected"';} ?> >NO</option>
                                    </select>
                                </div>
                                <?php   }   ?>
                            </td>
                            <td style="text-align: left; width: 170px; border: 0px; direction: ltr;" class="tableExtra">
                                Cough R:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtCoughR<?php echo $patient[$i]['id']; ?>" name="txtCoughR">
                                    <option value="P" <?php if($patient[$i]['cough_R'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['cough_R'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                                <br>
                                Face Movement:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtFaceMovement<?php echo $patient[$i]['id']; ?>" name="txtFaceMovement">
                                    <option value="P" <?php if($patient[$i]['face_Movement'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['face_Movement'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                            </td>
                            <td style="text-align: left; width: 120px; border: 0px; direction: ltr;" class="tableExtra">
                                Pupil R:
                                <select class="form-control" style="width: 80px; margin-right: 6px; direction: rtl; font-family: Tahoma; font-size: 12px; height: 32px; text-align: left;" id="txtPupilR<?php echo $patient[$i]['id']; ?>" name="txtPupilR">
                                    <option value="P" <?php if($patient[$i]['pupil_R'] == 'P'){echo 'selected="selected"';} ?> >P</option>
                                    <option value="N" <?php if($patient[$i]['pupil_R'] == 'N'){echo 'selected="selected"';} ?> >N</option>
                                </select>
                            </td>
                            <td style="text-align: right; width: 100px; border: 0px; height: 100px;" class="tableExtra"></td>
                            <td style="text-align: right; width: 190px; border: 0px; height: 100px;" class="tableExtra">
                                بستری:
                                <br>
                                <input type="text" class="form-control" id="pcal3-<?php echo $patient[$i]['id']; ?>" name="txthospitalizationDate" style="font-family: 'Yekan'; margin-right: 2px; width: 80px; float: right; padding-right: 7px; padding-left: 7px; font-size: 13px;" value="<?php if($patient[$i]['hospitalizationDate'] > 1000) {echo pdate('Y/n/d', $patient[$i]['hospitalizationDate']);} ?>">
                                <script type="text/javascript">
                                    var objCal3<?php echo $patient[$i]['id']; ?> = new AMIB.persianCalendar( 'objCal3<?php echo $patient[$i]['id']; ?>', 'pcal3-<?php echo $patient[$i]['id']; ?>' );
                                </script>
                                <br><br>
                                مرگ مغزی:
                                <br>
                                <input type="text" class="form-control" id="pcal4-<?php echo $patient[$i]['id']; ?>" name="txtBrainDeathDate" style="font-family: 'Yekan'; margin-right: 2px; width: 80px; float: right; padding-right: 7px; padding-left: 7px; font-size: 13px;" value="<?php if($patient[$i]['brainDeathDate'] > 1000) {echo pdate('Y/n/d', $patient[$i]['brainDeathDate']);} ?>">
                                <script type="text/javascript">
                                    var objCal4<?php echo $patient[$i]['id']; ?> = new AMIB.persianCalendar( 'objCal4<?php echo $patient[$i]['id']; ?>', 'pcal4-<?php echo $patient[$i]['id']; ?>' );
                                </script>    
                            </td>
                            <td style="text-align: right; width: 70px; border: 0px; height: 100px;" class="tableExtra"></td>
                        </tr>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <tr style="direction: rtl; display: none" id="logDataRow<?php echo $patient[$i]['id']; ?>">
                            <td style="text-align: right; width: 1710px; border: 0px; padding: 0px; text-align: center;" class="tableExtra" colspan="15">
                                <table class="table table-striped table-hover" style="direction: rtl; width: 1710px; text-align: center;">
                                    <thead>
                                        <tr style="direction: rtl;">
                                            <th style="text-align: right; width: 50px;" class="tableExtra">#</th>
                                            <th style="text-align: right; width: 150px;" class="tableExtra">GCS تغییر یافته</th>
                                            <th style="text-align: right; width: 150px;" class="tableExtra">نام بیمارستان</th>
                                            <th style="text-align: right; width: 100px;" class="tableExtra">بخش</th>
                                            <th style="text-align: right; width: 150px;" class="tableExtra">بازرس</th>
                                            <th style="text-align: right; width: 100px;" class="tableExtra">معرفی</th>
                                            <th style="text-align: right; width: 80px;" class="tableExtra">Breath</th>
                                            <th style="text-align: right; width: 150px;" class="tableExtra">Body Movement</th>
                                            <th style="text-align: right; width: 80px;" class="tableExtra">Cough R</th>
                                            <th style="text-align: right; width: 150px;" class="tableExtra">Face Movement</th>
                                            <th style="text-align: right; width: 80px;" class="tableExtra">Gag R</th>
                                            <th style="text-align: right; width: 80px;" class="tableExtra">Cornea R</th>
                                            <th style="text-align: right; width: 100px;" class="tableExtra">Pupil R</th>
                                            <th style="text-align: right; width: 90px;" class="tableExtra">Sedation</th>
                                            <th style="text-align: center; width: 100px;" class="tableExtra">بروزرسانی</th>
                                            <th style="text-align: center; width: 100px;" class="tableExtra">عملیات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                    <?php
                                        $pLog = findAllPatientsLog($patient[$i]['id'], 1);
                                        if($pLog)
                                        {
                                            for($p = 0, $pp = 1; $p < count($pLog); $p++)
                                            {
                                                
                                    ?>
                                    
                                        <tr style="direction: rtl;">
                                            <td style="text-align: right; width: 50px;" class="tableExtra"><?php echo $pp++; ?></td>
                                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php echo $pLog[$p]['secondGCS']; ?></td>
                                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php $hs = findHospitalById($pLog[$p]['hospitalName']); echo $hs['name']; ?></td>
                                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                                <?php   if($pLog[$p]['section'] == 1)
                                                        {
                                                            echo 'CCU';
                                                        }
                                                        elseif($pLog[$p]['section'] == 2)
                                                        {
                                                            echo 'ICU';
                                                        }
                                                        elseif($pLog[$p]['section'] == 3)
                                                        {
                                                            echo 'اورژانس';
                                                        }
                                                        elseif($pLog[$p]['section'] == 4)
                                                        {
                                                            echo 'بخش';
                                                        }
                                                    ?>
                                                    <?php echo ' ' . $pLog[$p]['type_of_section']; ?>
                                            </td>
                                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php $in = findInspectorById($pLog[$p]['uId']); echo $in['fullName']; ?></td>
                                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                                <?php   if($pLog[$p]['presentation'] == 1)
                                                        {
                                                            echo 'IP';
                                                        }
                                                        elseif($pLog[$p]['presentation'] == 2)
                                                        {
                                                            echo 'TDDP';
                                                        }
                                                        elseif($pLog[$p]['presentation'] == 3)
                                                        {
                                                            echo 'HR';
                                                        }
                                                    ?>
                                            </td>
                                            <td style="text-align: right; width: 80px;" class="tableExtra"><?php echo $pLog[$p]['breath']; ?></td>
                                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php echo $pLog[$p]['body_Movement']; ?></td>
                                            <td style="text-align: right; width: 80px;" class="tableExtra"><?php echo $pLog[$p]['cough_R']; ?></td>
                                            <td style="text-align: right; width: 150px;" class="tableExtra"><?php echo $pLog[$p]['face_Movement']; ?></td>
                                            <td style="text-align: right; width: 80px;" class="tableExtra"><?php echo $pLog[$p]['gag_R']; ?></td>
                                            <td style="text-align: right; width: 80px;" class="tableExtra"><?php echo $pLog[$p]['cornea_R']; ?></td>
                                            <td style="text-align: right; width: 100px;" class="tableExtra"><?php echo $pLog[$p]['pupil_R']; ?></td>
                                            <td style="text-align: right; width: 90px;" class="tableExtra"><?php echo $pLog[$p]['sedation']; ?></td>
                                            <td style="text-align: center; width: 100px;" class="tableExtra">
                                                <?php   if($pLog[$p]['lastUpdate'] > 10000)
                                                        {
                                                            echo pdate('Y/n/d', $pLog[$p]['lastUpdate']);
                                                        }
                                                        else
                                                        {
                                                            echo 'هرگز';
                                                        }
                                                    ?>
                                            </td>
                                            <td style="text-align: center; width: 100px;" class="tableExtra">
                                                <?php
                                                    if(checkAdminIsLogedIn())
                                                    {
                                                ?>
                                                        <img src="images/del2.png" alt="حذف" title="حذف" style="cursor: pointer;" onclick="confirmDelPLog(<?php echo $pLog[$p]['id']; ?>);">
                                                <?php
                                                    }
                                                    else
                                                    {
                                                        echo '-';
                                                    }
                                                ?>
                                            </td>
                                        </tr> 
                                        
                                    <?php
                                           }
                                        }
                                        else
                                        {
                                            
                                    ?>   
                                        <tr style="direction: rtl;">
                                            <td style="text-align: center; width: 100%;" class="tableExtra" colspan="16">موردی تا کنون ثبت نگردیده است.</td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <?php } ?>
                </tbody>
            </table>
            <?php } ?>
            
            <?php if($haveST == 'ShowOnePatient'){ ?>
            <button type="button" class="btn btn-success" style="float: left; font-family: 'Yekan'; margin-top: 30px;" onclick="window.location='<?php echo $uri; ?>/addPatient';">ثبت بیمار جدید</button>
            <?php } ?>

        <div style="clear: both;"></div>
        <div style="margin: 0 auto; width: 920px; text-align: center;">
            <?php
                $count = DatabaseHandler::GetAll($query);
                $gdUrl = $uri . '/showAllPatients?' . $myLink . '&page=';
                echo pagination(count($count), $page, $number, 4, $gdUrl);
            ?>
        </div>
    </div>



</div>