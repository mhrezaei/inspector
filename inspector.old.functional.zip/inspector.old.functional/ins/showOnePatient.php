<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
require_once SITE_ROOT . '/functions/fn.pagination.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        //header('location: ' . $uri . '/logOut');
        //exit;
    }
}
$msg = '';
$ms = '';

//=================================================
//page number
$number = 30;   
if(isset($_GET['page']) && $_GET['page'] > 0)
{
    $start = ($_GET['page'] * $number) - $number;
    $page = htmlCoding($_GET['page']) + 0;
    $se = '&page=' . $_GET['page'];
    $myLink = $_SERVER['QUERY_STRING'];
    $myLink = str_replace($se, '', $myLink);
}
else
{
    $start = 0;
    $page = 1;
    $myLink = $_SERVER['QUERY_STRING'];
}
$limit = ' LIMIT ' . $start . ' , ' . $number . ' ';
//=================================================

if(isset($_GET['delID']) && is_numeric($_GET['delID']))
{
    $patient = findPatientById(htmlCoding($_GET['delID']));
    if(!$patient || $patient['tracking'] != 1)
    {
        header('location: ' . $uri);
        exit;
    }
    else
    {
        updateOneFieldFromTable('patients', 'tracking', '2', htmlCoding($_GET['delID']));
    }
}

if(isset($_GET['id']) && is_numeric($_GET['id']))
{
    $query = "SELECT * FROM `patients` WHERE `id` = '" . htmlCoding($_GET['id']) . "' AND `tracking` = 1 ;";
    $patient = DatabaseHandler::GetAll($query);
    if(!$patient)
    {
        header('location: ' . $uri);
        exit;
    }
    $msg = 1;
}
else
{
    header('location: ' . $uri);
    exit;
}

$hospitals = DatabaseHandler::GetAll("SELECT * FROM `hospital` WHERE `status` = 1 ORDER BY `name` ASC ;");
if(!$hospitals)
{  
    header('location: ' . $uri);
    exit;
}

include 'header.php';

$pageTitle = 'مشاهده وضعیت بیمار';
$haveST = basename(__FILE__, '.php');
$searchUrl = $uri . '/' . basename(__FILE__, '.php');

?>
<title>بخش مدیریت سامانه بازرسین | <?php echo $pageTitle; ?></title>

<?php require_once 'patientsTable.php'; ?>

<?php include 'footer.php'; ?>

