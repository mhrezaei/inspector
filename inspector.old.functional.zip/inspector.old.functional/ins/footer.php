<?php
    if(basename($_SERVER['PHP_SELF'], '.php') == 'index')
    {
?>
<div style="margin: 20px auto 0px; width: 960px; text-align: center; padding: 10px; color: black; background: none repeat scroll 0% 0% rgb(236, 244, 252);" class="alert alert-info">.:: Programming & Hosted By <a href="http://www.yasnateam.com" target="_blank">YasnaTeam Company</a> - Designed By <a href="mailto:fariba.etemad@gmail.com">Fariba NouriEtemad</a> ::.</div>

<?php
    }
?>

<!--<div style="font-family: 'Yekan'; margin: 20px auto 0px; width: 960px; text-align: center; padding: 10px; color: black; background: none repeat scroll 0% 0% rgb(236, 244, 252);" class="alert alert-info">.:: کلیه حقوق مادی و معنوی این سامانه برای واحد فراهم آوری اعضای پیوندی دانشگاه علوم پزشکی شهید بهشتی محفوظ می باشد ::.</div>-->

<div style="font-family: 'Yekan'; margin: 20px auto 0px; width: 960px; text-align: center; padding: 10px; color: black; background: none repeat scroll 0% 0% rgb(236, 244, 252);" class="alert alert-info">.:: کلیه حقوق مادی و معنوی این سامانه محفوظ می باشد. ::.</div>

</body>
</html>