<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
require_once SITE_ROOT . '/functions/fn.pagination.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        header('location: ' . $uri . '/logOut');
        exit;
    }
}
$msg = '';
$ms = '';

//=================================================
//page number
$number = 30;   
if(isset($_GET['page']) && $_GET['page'] > 0)
{
    $start = ($_GET['page'] * $number) - $number;
    $page = htmlCoding($_GET['page']) + 0;
}
else
{
    $start = 0;
    $page = 1;
}
$limit = ' LIMIT ' . $start . ' , ' . $number . ' ';
//=================================================

if(isset($_GET['suspend']) && is_numeric($_GET['suspend']))
{
    $hos = findInspectorById(htmlCoding($_GET['suspend']));
    if($hos && $hos['status'] == 1 && $hos['id'] != 1)
    {
        updateOneFieldFromTable('users', 'status', '2', htmlCoding($_GET['suspend']));
        $ms = 1;
    }
    else
    {
        $ms = 2;
    }
}
if(isset($_GET['unsuspend']) && is_numeric($_GET['unsuspend']))
{
    $hos = findInspectorById(htmlCoding($_GET['unsuspend']));
    if($hos && $hos['status'] == 2 && $hos['id'] != 1)
    {
        updateOneFieldFromTable('users', 'status', '1', htmlCoding($_GET['unsuspend']));
        $ms = 3;
    }
    else
    {
        $ms = 4;
    }
}
if(isset($_GET['txtName']))
{
    $query = "SELECT * FROM `users` WHERE `nationalCode` LIKE '%" . htmlCoding($_GET['txtName']) . "%' OR `fullName` LIKE '%" . htmlCoding($_GET['txtName']) . "%' OR `mobile` LIKE '%" . htmlCoding($_GET['txtName']) . "%' ORDER BY `fullName` ASC ";
}
else
{
    $query = "SELECT * FROM `users` ORDER BY `fullName` ASC ";
}

$gdl = DatabaseHandler::GetAll($query . $limit);
if($gdl)
{
    $msg = 1;
}
else
{
    $msg = 2;
}


include 'header.php';

?>

<title>بخش مدیریت سامانه بازرسین | لیست بازرسین</title>
<script type="text/javascript">
function confirmDel(id)
{
    if(confirm('آیا مایل به غیر فعال نمودن این بازرس می باشد؟'))
    {
        window.location = "<?php echo $uri; ?>/inspectorsList?suspend=" + id;
    }
}
function confirmActive(id)
{
    if(confirm('آیا مایل به فعال نمودن این بازرس می باشد؟'))
    {
        window.location = "<?php echo $uri; ?>/inspectorsList?unsuspend=" + id;
    }
}
</script>

<div class="contentMain" style="min-height: 900px; background: #ECF4FC;">
    <div style="font-family: 'Yekan'; margin-right: 10px; margin-top: 15px; font-size: 13px;">لیست بازرسین</div>
    <div style="width: 100%; height: 2px; background: #E07626; margin-top: 5px;"></div>
    <br>
    
    <form action="inspectorsList" method="get" class="form-inline" role="form">
        <div class="form-group" style="float: right;">
        <label for="txtDS" style="float: right; margin-right: 25px; font-family: 'Nassim'; padding-top: 5px; line-height: 30px;">یافتن بازرس: </label>
        <input type="text" class="form-control" placeholder="نام بازرس، کدملی یا شماره تماس" id="txtName" name="txtName" style="font-family: 'Yekan'; margin-right: 5px; width: 330px;" value="<?php if(isset($_GET['txtName'])){echo htmlCoding($_GET['txtName']);} ?>">
        </div>
        
        <button type="submit" class="btn btn-primary btn-sm" style="font-family: 'Nassim'; margin-right: 2px; margin-top: 1px; position: absolute; font-size: 13px;">پیدا کن!</button>
        <button type="button" class="btn btn-warning btn-sm" style="font-family: 'Nassim'; margin-right: 60px; margin-top: 1px; position: absolute; font-size: 13px;" onclick="window.location = '<?php echo $uri . '/inspectorsList' ?>'">پاک کن!</button>
    </form>
    <div style="clear: both;"></div>
    
        <!--<div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">خبر مورد نظر با موفقیت ثبت گردید.</div>-->
    <?php if($ms == 1){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر با موفقیت غیرفعال گردید.</div>
    <?php }elseif($ms == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر یافت نشد.</div>
    <?php }elseif($ms == 3){ ?>
        <div class="alert alert-success" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر با موفقیت فعال گردید.</div>
    <?php }elseif($ms == 4){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto;">بازرس مورد نظر یافت نشد.</div>
    <?php } ?>
    <?php if($msg == 2){ ?>
        <div class="alert alert-danger" style="font-family: 'Yekan'; width: 60%; margin: 0 auto; margin-top: 20px;">بازرسی یافت نشد.</div>
    <?php } ?>
    <div style="width: 920px; margin-right: 20px; margin-top: 20px;">
        <?php if($msg == 1){ ?>
            <table class="table table-hover" style="direction: rtl;">
                <thead>
                  <tr style="direction: rtl;">
                    <th style="text-align: right; width: 50px;" class="tableExtra">#</th>
                    <th style="text-align: right; width: 300px;" class="tableExtra">نام بازرس</th>
                    <th style="text-align: center; width: 185px; text-align: right;" class="tableExtra">کدملی</th>
                    <th style="text-align: center; width: 185px; text-align: right;" class="tableExtra">شماره تماس</th>
                    <th style="text-align: center; width: 100px; text-align: right;" class="tableExtra">نوع بازرسی</th>
                    <th style="text-align: center; width: 100px;" class="tableExtra">عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $e = 1; for($i = 0; $i < count($gdl); $i++){ ?>
                      <?php if($gdl[$i]['nationalCode'] != 'admin'){ ?>
                        <tr>
                            <td style="text-align: right; width: 50px;" class="tableExtra"><?php echo ++$start; ?></td>
                            <td style="text-align: right; width: 300px;" class="tableExtra"><?php echo $gdl[$i]['fullName']; ?></td>
                            <td style="text-align: right; width: 185px;" class="tableExtra"><?php echo $gdl[$i]['nationalCode']; ?></td>
                            <td style="text-align: right; width: 185px;" class="tableExtra"><?php echo $gdl[$i]['mobile']; ?></td>
                            <td style="text-align: right; width: 100px;" class="tableExtra">
                                <?php   if($gdl[$i]['type'] == 1)
                                        {
                                            echo 'حضوری';
                                        }        
                                        else
                                        {
                                            echo 'تلفنی';
                                        }
                                ?>
                            </td>
                            <td style="text-align: center; width: 100px;" class="tableExtra">
                                <img src="images/edit.png" alt="ویرایش" title="ویرایش" style="cursor: pointer;" onclick="window.location = 'editOneInspector?id=<?php echo $gdl[$i]['id']; ?>';">
                                <?php if($gdl[$i]['status'] == 1){ ?>
                                    <img src="images/del2.png" alt="حذف" title="حذف" style="cursor: pointer;" onclick="confirmDel(<?php echo $gdl[$i]['id']; ?>);">
                                <?php }else{ ?>
                                    <span class="glyphicon glyphicon-ok" style="cursor: pointer; color: green; font-size: 15px;" title="فعال سازی" onclick="confirmActive(<?php echo $gdl[$i]['id']; ?>);"></span>
                                <?php } ?>
                            </td>
                          </tr>
                        <?php } ?>
                  <?php } ?>
                </tbody>
              </table>
        <?php } ?>
        
        <div style="clear: both;"></div>
        <div style="margin: 0 auto; width: 920px; text-align: center;">
            <?php
                    $count = DatabaseHandler::GetAll($query);
                    $gdUrl = $uri . '/inspectorList?page=';
                    echo pagination(count($count), $page, $number, 4, $gdUrl);
?>
        </div>
    </div>
    
    
</div>


<?php include 'footer.php'; ?>

