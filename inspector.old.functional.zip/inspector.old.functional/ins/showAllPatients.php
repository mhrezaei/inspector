<?php

require_once 'functions/config.php';
require_once SITE_ROOT . '/functions/myFunction.php';
require_once SITE_ROOT . '/functions/func.php';
require_once SITE_ROOT . '/functions/fn.pagination.php';
if(!checkUserIsLogedIn())
{
    header('location: ' . $uri . '/login');
    exit;
}        
else
{
    if(!checkAdminIsLogedIn())
    {
        //header('location: ' . $uri . '/logOut');
        //exit;
    }
}
$msg = '';
$ms = '';

//=================================================
//page number
$number = 30;   
if(isset($_GET['page']) && $_GET['page'] > 0)
{
    $start = ($_GET['page'] * $number) - $number;
    $page = htmlCoding($_GET['page']) + 0;
    $se = '&page=' . $_GET['page'];
    $myLink = $_SERVER['QUERY_STRING'];
    $myLink = str_replace($se, '', $myLink);
}
else
{
    $start = 0;
    $page = 1;
    $myLink = $_SERVER['QUERY_STRING'];
}
$limit = ' LIMIT ' . $start . ' , ' . $number . ' ';
//=================================================
$where = '';
$where[] = ' `tracking` = 1 ';
$or = '';
$whereFinal = '';
$isWhere = '';
$whereOr = '';
if(isset($_GET['cbSort']))
{
    if($_GET['cbSort'] == 1)
    {
        $order = ' ORDER BY `name` ';
    }
    elseif($_GET['cbSort'] == 2)
    {
        $order = ' ORDER BY `hospitalName` ';
    }
    elseif($_GET['cbSort'] == 3)
    {
        $order = ' ORDER BY `firstGCS` ';
    }
    elseif($_GET['cbSort'] == 4)
    {
        $order = ' ORDER BY `secondGCS` ';
    }
    elseif($_GET['cbSort'] == 5)
    {
        $order = ' ORDER BY `inspector` ';
    }
    elseif($_GET['cbSort'] == 6)
    {
        $order = ' ORDER BY `addDate` ';
    }
    elseif($_GET['cbSort'] == 7)
    {
        $order = ' ORDER BY `presentation` ';
    }
    elseif($_GET['cbSort'] == 8)
    {
        $order = ' ORDER BY `status` ';
    }
    elseif($_GET['cbSort'] == 9)
    {
        $order = ' ORDER BY `lastUpdate` ';
    }
    else
    {
        $order = ' ORDER BY `addDate` ';
    }
}
else
{
    $order = ' ORDER BY `addDate` ';
}

if(isset($_GET['cbSortType']))
{
    if($_GET['cbSortType'] == 1)
    {
        $sort = ' DESC ';
    }
    else
    {
        $sort = ' ASC ';
    }
}
else
{
    $sort = 'DESC';
}

if(isset($_GET['txtSearch']) && strlen($_GET['txtSearch']) > 3)
{
    $or = ' `name` LIKE ' . "'%" . htmlCoding($_GET['txtSearch']) . "%'" . ' OR `cause` LIKE ' . "'%" . htmlCoding($_GET['txtSearch']) . "%'" . ' OR `detail` LIKE ' . "'%" . htmlCoding($_GET['txtSearch']) . "%' ";
}

if(isset($_GET['cbInspector']))
{
    if($_GET['cbInspector'] > 0 && is_numeric($_GET['cbInspector']))
    {
        $where[] = ' `inspector` = ' . "'" . htmlCoding($_GET['cbInspector']) . "' ";
    }
}

if(isset($_GET['cbHospitalF']))
{
    if($_GET['cbHospitalF'] > 0 && is_numeric($_GET['cbHospitalF']))
    {
        $where[] = ' `hospitalName` = ' . "'" . htmlCoding($_GET['cbHospitalF']) . "' ";
    }
}

if(is_array($where))
{
    for($i = 0; $i < count($where); $i++)
    {
        $whereFinal .= $where[$i];
        if($i + 1 < count($where))
        {
            $whereFinal .= ' AND ';
        }
    }
}

if(strlen($whereFinal) > 3 || strlen($or) > 3)
{
    $isWhere = ' WHERE ';
}

if(strlen($whereFinal) > 3 && strlen($or) > 3)
{
    $whereOr = ' AND ';
}

$query = "SELECT * FROM `patients`" . $isWhere . $whereFinal . $whereOr . $or . $order . $sort;

$patient = DatabaseHandler::GetAll($query . $limit);
if($patient)
{
    $msg = 1;
}
else
{
    $msg = 2;
}

$hospitals = DatabaseHandler::GetAll("SELECT * FROM `hospital` WHERE `status` = 1 ORDER BY `name` ASC ;");
if(!$hospitals)
{  
    header('location: ' . $uri);
    exit;
}

include 'header.php';

$pageTitle = 'لیست همه بیماران';
$haveST = basename(__FILE__, '.php');
$searchUrl = $uri . '/' . basename(__FILE__, '.php');

?>
<title>بخش مدیریت سامانه بازرسین | <?php echo $pageTitle; ?></title>

<?php require_once 'patientsTable.php'; ?>


<?php include 'footer.php'; ?>

