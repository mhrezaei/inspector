<?php

$cm = '';

?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">   
<link rel="stylesheet" type="text/css" href="css/my.css">    
<link rel="stylesheet" type="text/css" href="css/js-persian-cal.css">    
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/js-persian-cal.js" type="text/javascript"></script>

</head>
<body>

<?php
    if(!checkAdminIsLogedIn())
    {
        $inspectorHeader = findInspectorById($_SESSION['user']['id']);
?>
<nav id="menu-wrap">    
    <ul id="menu">
        <li><a href="#">بازرس محترم <?php echo $inspectorHeader['fullName']; ?> خوش آمدید...</a></li>

        <li><a href="<?php echo $uri; ?>">صفحه اصلی</a></li>
        
        <li><a href="<?php echo $uri; ?>/addPatient">افزودن بیمار جدید</a></li>
        
        <li>
            <a href="#">لیست بیماران</a>
            <ul>
                <li>
                    <a href="<?php echo $uri; ?>/showAllPatients">لیست همه بیماران</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS3PatientsY">لیست بیماران GCS3 مرگ مغزی شده</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS3PatientsN">لیست بیماران GCS3 مرگ مغزی نشده</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS45Patients">لیست بیماران GCS4,5</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllPatientsUnfit">لیست بیماران موارد نامناسب</a>
                </li>
            </ul>
        </li>
        
        <li><a href="<?php echo $uri; ?>/inspectorChangePassword">تغییر رمز عبور</a></li>
        
        <li><a href="<?php echo $uri; ?>/logOut">خروج</a></li>
    </ul>
</nav>
<?php
    }
    else
    {
?>
<nav id="menu-wrap">    
    <ul id="menu">
        <li><a href="<?php echo $uri; ?>/">صفحه اصلی مدیریت</a></li>

        <li>
            <a href="#">بیمارستان ها</a>
            <ul>
                <li>
                    <a href="<?php echo $uri; ?>/addHospital">افزودن بیمارستان جدید</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/hospitalList">لیست بیمارستان ها</a>
                </li>
            </ul>
        </li>
        
        <li>
            <a href="#">بازرسین</a>
            <ul>
                <li>
                    <a href="<?php echo $uri; ?>/addInspector">افزودن بازرس جدید</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/inspectorsList">لیست بازرسان</a>
                </li>
            </ul>
        </li>
        
        <li>
            <a href="#">بیماران</a>
            <ul>
                <li>
                    <a href="<?php echo $uri; ?>/addPatient">افزودن بیمار جدید</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllPatients">لیست همه بیماران</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS3PatientsY">لیست بیماران GCS3 مرگ مغزی شده</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS3PatientsN">لیست بیماران GCS3 مرگ مغزی نشده</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllGCS45Patients">لیست بیماران GCS4,5</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllPatientsUnfit">لیست بیماران موارد نامناسب</a>
                </li>
                <li>
                    <a href="<?php echo $uri; ?>/showAllPatientsDeleted">لیست بیماران حذف شده</a>
                </li>
            </ul>
        </li>
        
        <li>
            <a href="<?php echo $uri; ?>/adminChangePassword">تغییر رمز عبور</a>
        </li>
        
        <li>
            <a href="<?php echo $uri; ?>/logOut">خروج</a>
        </li>
    </ul>
</nav>
<?php } ?>
