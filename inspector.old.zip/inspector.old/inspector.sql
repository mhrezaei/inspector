-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2015 at 10:52 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inspector`
--
CREATE DATABASE IF NOT EXISTS `inspector` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `inspector`;

-- --------------------------------------------------------

--
-- Table structure for table `mhr_ci_sessions`
--

CREATE TABLE IF NOT EXISTS `mhr_ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8_persian_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mhr_ci_sessions`
--

INSERT INTO `mhr_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('a8ff00389ad52b7ac08819186454094f', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:36.0) Gecko/20100101 Firefox/36.0', 1426449456, 'a:6:{s:9:"user_data";s:0:"";s:2:"qs";s:40:"a146d13ba4a5e1f06fe5003b44ca4a07d6669b68";s:3:"uid";s:21:"mr.mhrezaei@gmail.com";s:8:"authCode";s:32:"174548955f95eeaac638ffe52831d256";s:3:"uip";s:32:"be40cd0cd01209b4a21423f85fe24611";s:4:"role";s:5:"ADMIN";}'),
('51374b18276f8650c96d284d3b9287ea', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0', 1431635104, 'a:6:{s:9:"user_data";s:0:"";s:2:"qs";s:40:"2abd9867cad9eeee50033bf1d4310baa0c3c2aed";s:3:"uid";s:21:"mr.mhrezaei@gmail.com";s:8:"authCode";s:32:"174548955f95eeaac638ffe52831d256";s:3:"uip";s:32:"be40cd0cd01209b4a21423f85fe24611";s:4:"role";s:5:"ADMIN";}'),
('838f310fb2234ed06975a8f873db140c', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0', 1431688323, 'a:6:{s:9:"user_data";s:0:"";s:2:"qs";s:40:"05797c664d6627b52617123ce900831f7be825b4";s:3:"uid";s:21:"mr.mhrezaei@gmail.com";s:8:"authCode";s:32:"174548955f95eeaac638ffe52831d256";s:3:"uip";s:32:"be40cd0cd01209b4a21423f85fe24611";s:4:"role";s:5:"ADMIN";}');

-- --------------------------------------------------------

--
-- Table structure for table `mhr_condition`
--

CREATE TABLE IF NOT EXISTS `mhr_condition` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `t` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `bp` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `pr` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `rr` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `fio2` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `o2sat` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `sedation` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `out` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='The patient''s condition' AUTO_INCREMENT=24 ;

--
-- Dumping data for table `mhr_condition`
--

INSERT INTO `mhr_condition` (`id`, `pId`, `status`, `t`, `bp`, `pr`, `rr`, `fio2`, `o2sat`, `sedation`, `out`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(1, 11, 1, '100', '250', '150', '300', '200', '350', 'No', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 11, 1, '100', '250', '150', '300', '200', '350', 'No', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 11, 1, '100', '250', '150', '300', '200', '350', 'No', NULL, NULL, NULL, NULL, NULL, NULL),
(4, 11, 1, '100', '250', '150', '300', '200', '350', 'No', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 8, 1, '10', '25', '15', '30', '20', '35', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 8, 1, '10', '25', '15', '30', '20', '35', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(7, 8, 1, '10', '25', '15', '30', '20', '35', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(8, 8, 1, '10', '25', '15', '30', '20', '35', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 6, 1, '100', '250', '150', '300', '200', '400', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(10, 6, 1, '100', '250', '150', '300', '200', '400', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 17, 1, '100', '400', '200', '500', '300', '600', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 17, 1, '100', '400', '200', '500', '300', '600', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 17, 1, '100', '400', '200', '500', '300', '600', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(14, 16, 1, '1', '1', '1', '1', '1', '1', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(15, 16, 1, '1', '1', '1', '1', '1', '1', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(16, 17, 1, '100', '400', '200', '500', '300', '650', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(17, 17, 1, '100', '400', '200', '500', '300', '700', 'Yes', NULL, NULL, NULL, NULL, NULL, NULL),
(18, 17, 1, '100', '400', '200', '500', '300', '700', 'No', NULL, NULL, NULL, NULL, NULL, NULL),
(19, 17, 1, '100', '400', '200', '500', '300', '700', 'No', '2.5', NULL, NULL, NULL, NULL, NULL),
(20, 21, 1, '1', '5', '2', '6', '3', '7', 'No', '4', NULL, NULL, NULL, NULL, NULL),
(21, 23, 1, '1', '5', '2', '6', '3', '7', 'No', '4', NULL, NULL, NULL, NULL, NULL),
(22, 25, 1, '1', '5', '2', '6', '3', '7', 'Yes', '4', NULL, NULL, NULL, NULL, NULL),
(23, 26, 1, '100', '500', '200', '600', '300', '700', 'Yes', '400', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_doc`
--

CREATE TABLE IF NOT EXISTS `mhr_doc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(2000) COLLATE utf8_persian_ci NOT NULL,
  `parentID` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `text` (`text`(333))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Disorders of consciousness' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mhr_doc`
--

INSERT INTO `mhr_doc` (`id`, `text`, `parentID`, `status`, `res1`, `res2`, `res3`) VALUES
(2, 'ضربه به سر', 0, 1, NULL, NULL, NULL),
(3, 'پارگی عروق مغزی', 0, 1, NULL, NULL, NULL),
(4, 'مسمومیت دارویی', 0, 1, NULL, NULL, NULL),
(5, 'تومور مغزی', 0, 1, NULL, NULL, NULL),
(7, 'بسته شدن عروق مغزی', 0, 1, NULL, NULL, NULL),
(8, 'سایر', 0, 1, NULL, NULL, NULL),
(9, 'تصادف', 0, 1, NULL, NULL, NULL),
(10, 'سقوط از ارتفاع', 0, 1, NULL, NULL, NULL),
(11, 'خفگی', 0, 1, NULL, NULL, NULL),
(12, 'به دنبال تشنج', 0, 1, NULL, NULL, NULL),
(13, 'Post CPR', 0, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_downloads`
--

CREATE TABLE IF NOT EXISTS `mhr_downloads` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(512) COLLATE utf8_persian_ci NOT NULL,
  `mimeType` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='download files data';

--
-- Dumping data for table `mhr_downloads`
--

INSERT INTO `mhr_downloads` (`id`, `title`, `mimeType`, `res1`, `res2`, `res3`) VALUES
(1, 'داخلی 1-ثبت اطلاعات متقاضی بیماریاری', 'pdf', NULL, NULL, NULL),
(2, 'داخلی 2- تفاهم نامه بیماریار رده کمک بهیار', 'pdf', NULL, NULL, NULL),
(3, 'داخلی 3- تفاهم نامه بیماریار رده خدمه', 'pdf', NULL, NULL, NULL),
(4, '5-1اطلاعات اهداکنندگان بالفعل مرگ مغزی', 'pdf', NULL, NULL, NULL),
(5, '5-2آزمایشات مرگ مغزی', 'pdf', NULL, NULL, NULL),
(6, '5-3فرم حضور نماینده پزشک قانونی', 'pdf', NULL, NULL, NULL),
(7, '5-4فرم پرداخت هزینه‌ی آمبولانس', 'pdf', NULL, NULL, NULL),
(8, '5-5فرم اطلاعات و پیگیری مشکلات آمبولانس', 'pdf', NULL, NULL, NULL),
(9, '5-6فرم هماهنگي ساعت اتاق عمل', 'pdf', NULL, NULL, NULL),
(10, '5-7فرم شرکت در مراسم ترحیم', 'pdf', NULL, NULL, NULL),
(11, '5-8مشخصات اهدا کنندگان', 'pdf', NULL, NULL, NULL),
(12, '5-9فرم مشخصات گیرندگان اعضا', 'pdf', NULL, NULL, NULL),
(13, '5-10چک لیست تكميل پرونده', 'pdf', NULL, NULL, NULL),
(14, '5-11لیست نواقص پرونده ', 'pdf', NULL, NULL, NULL),
(15, '5-12پیگیری نامه های واحد', 'pdf', NULL, NULL, NULL),
(16, '5-13فرم ثبت نام کارت اهدای عضو', 'pdf', NULL, NULL, NULL),
(17, '5-14فرم درخواست همکاری', 'pdf', NULL, NULL, NULL),
(18, '5-15فرم درخواست همکاری', 'pdf', NULL, NULL, NULL),
(19, 'داخلی1', 'pdf', NULL, NULL, NULL),
(20, 'داخلی2-ورود و خروج کالای انبار', 'pdf', NULL, NULL, NULL),
(21, '2-4فرم گزارش تخلفات', 'pdf', NULL, NULL, NULL),
(22, '2-5فرم ضمیمه گزارش تخلفات', 'pdf', NULL, NULL, NULL),
(23, 'داخلی 1-متقاضیان بازرسی', 'pdf', NULL, NULL, NULL),
(24, 'داخلی 2-برآورد مالی', 'xlsx', NULL, NULL, NULL),
(25, 'داخلی 3-نمونه برنامه ماهانه بازرسی', 'pdf', NULL, NULL, NULL),
(26, 'داخلی 4-نحوه تقسیم بندی و بازرسی بیمارستانها', 'pdf', NULL, NULL, NULL),
(27, '3-1فرم متقاضی پرستاری', 'pdf', NULL, NULL, NULL),
(28, '3-2ارزیابی پرستار توسط بیهوشی', 'pdf', NULL, NULL, NULL),
(29, '3-3ارزیابی پرستار توسط کوردیناتور', 'pdf', NULL, NULL, NULL),
(30, 'داخلی 1-ثبت اطلاعات متقاضی پرستاری', 'pdf', NULL, NULL, NULL),
(31, 'داخلی 2-تفاهم نامه پرستاری', 'pdf', NULL, NULL, NULL),
(32, 'داخلی3- برگ گزارش پرستاری', 'pdf', NULL, NULL, NULL),
(33, '1-1فرم استخدام کوردیناتور', 'pdf', NULL, NULL, NULL),
(34, '1-2ابررسی اولیه بیماران', 'pdf', NULL, NULL, NULL),
(35, '1-3ویزیت کوردیناتور', 'pdf', NULL, NULL, NULL),
(36, '1-4دستورات دارویی', 'pdf', NULL, NULL, NULL),
(37, '1-5درخواست آزمایش ویرولوژی', 'pdf', NULL, NULL, NULL),
(38, '1-6گزارش به پزشک خارج از بیمارستان مبدا', 'pdf', NULL, NULL, NULL),
(39, '1-7ارزشیابی ریسکهای بیولوژیکی', 'pdf', NULL, NULL, NULL),
(40, '1-8رضایت انتقال', 'pdf', NULL, NULL, NULL),
(41, '1-9مراحل اداری اهدا', 'pdf', NULL, NULL, NULL),
(42, '1-10فرم معرفی جسد به پزشکی قانونی', 'pdf', NULL, NULL, NULL),
(43, '1-11چک لیست شرح وظایف کوردیناتور مبدا', 'pdf', NULL, NULL, NULL),
(44, '1-12آزمایش تطابق بافتی', 'pdf', NULL, NULL, NULL),
(45, '1-13رضایت اهدای عضو پزشکی قانونی', 'pdf', NULL, NULL, NULL),
(46, '1-14فرم گزارش هاروست', 'pdf', NULL, NULL, NULL),
(47, '1-15اطاق عمل', 'pdf', NULL, NULL, NULL),
(48, '1-16فرم شرح عمل', 'pdf', NULL, NULL, NULL),
(49, '1-17ارزیابی اعضای اهدایی', 'pdf', NULL, NULL, NULL),
(50, '1-18فرم خلاصه پرونده', 'pdf', NULL, NULL, NULL),
(51, '1-19فرم تحقیقاتی', 'pdf', NULL, NULL, NULL),
(52, '1-20چک لیست کوردیناتور آ سی یو هاروست', 'pdf', NULL, NULL, NULL),
(53, '1-21چک لیست کوردیناتور دوم', 'pdf', NULL, NULL, NULL),
(54, '1-22چک لیست کوردیناتور اتاق عمل', 'pdf', NULL, NULL, NULL),
(55, '1-23لیبل ارگان', 'pdf', NULL, NULL, NULL),
(56, '1-24تدفین اهدا کننده', 'pdf', NULL, NULL, NULL),
(57, '1-27فرم تائید مرگ مغزی', 'pdf', NULL, NULL, NULL),
(58, '1-25مراحل اهدای عضو', 'jpg', NULL, NULL, NULL),
(59, '1-26کارت gcs3', 'jpg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_hospitals`
--

CREATE TABLE IF NOT EXISTS `mhr_hospitals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(2000) COLLATE utf8_persian_ci NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `opuId` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(10000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='List of hospitals' AUTO_INCREMENT=23 ;

--
-- Dumping data for table `mhr_hospitals`
--

INSERT INTO `mhr_hospitals` (`id`, `name`, `state`, `city`, `opuId`, `username`, `password`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`) VALUES
(1, 'کودکان مفید', 8, 135, 3, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'امام علی(ع)', 8, 135, 3, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'بانک ملی', 13, 202, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'شهدای آبادان', 13, 204, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'شهدای خیابان', 27, 395, 7, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'ساحلی', 27, 397, 7, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '501 ارتش', 8, 136, 11, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(8, '502 ارتش', 8, 135, 11, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'شهدای اردبیل', 3, 69, 10, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'شهریار', 3, 73, 10, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'شهدای خرمشهر', 13, 214, 8, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'حضرت محمد', 7, 127, 8, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'شهید تبریزیان', 1, 37, 6, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'صیاد شیرازی', 1, 37, 6, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'بقیه الله', 8, 135, 2, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'نجمیه', 8, 135, 2, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'شهدای ساری', 27, 403, 5, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'شهید امجدی', 27, 399, 5, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'شهید دست غیب', 19, 298, 4, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'شهید مطهری', 19, 298, 4, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'رضوی', 11, 191, 9, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'قدس', 11, 191, 9, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_inspectors`
--

CREATE TABLE IF NOT EXISTS `mhr_inspectors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `nationalCode` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `authCode` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `type` int(11) NOT NULL COMMENT 'IP = 1, TDD = 2, IP&TDD = 3',
  `status` int(11) NOT NULL,
  `opuId` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` int(11) DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res7` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333)),
  KEY `authCode` (`authCode`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='list of inspector' AUTO_INCREMENT=17 ;

--
-- Dumping data for table `mhr_inspectors`
--

INSERT INTO `mhr_inspectors` (`id`, `name`, `nationalCode`, `password`, `authCode`, `mobile`, `type`, `status`, `opuId`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`) VALUES
(1, 'محمد هادی رضایی', '0012071110', 'f2561b1b1314c77bd6a04bc4b1beaad4', '899c6b4bc2daf3c2aed55f822038f4c1', '09361112030', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'محسن رضایی', '0054140821', 'c78b6663d47cfbdb4d65ea51c104044e', '839428cf3bf59b877e0a480b9644cf07', '09123011085', 1, 1, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'فریبا نوری', '0084782439', 'c78b6663d47cfbdb4d65ea51c104044e', 'a196c767373eb07fce3a7fc5b1ad1de2', '09351303767', 2, 1, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'علی احمدی', '0055122272', 'c78b6663d47cfbdb4d65ea51c104044e', '5c0f922deb31a799a9a104390733347d', '09129638255', 3, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'عباس غلامی', '6379733760', 'c78b6663d47cfbdb4d65ea51c104044e', 'c9c68441a74a3527b5b9040c49f380ae', '09101111111', 3, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'آوا محمدی', '0151841039', 'c78b6663d47cfbdb4d65ea51c104044e', '758a50816605a4e65eb9c717176b9a30', '11111111111', 2, 1, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'امید قبادی', '2050168926', 'c78b6663d47cfbdb4d65ea51c104044e', '339e3d8eb000fc693995f6dae74447ce', '09121234567', 3, 1, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'علیرضا رمضانی', '0519820320', 'c78b6663d47cfbdb4d65ea51c104044e', '96f48fdfeecbf0905baac67db3abe93a', '09125545125', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'مهدیه حضرتی', '0080403964', 'd5793f0c25620c8030af3d236bb41571', 'ef3c1403fcfe1ffb51577d0088547452', '09197607731', 2, 1, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'یاسر موسوی', '6199719107', 'cfece859621f92fbe9279e3dadd503d9', 'fd83a47ebfa4a37d81011ba3fbdb9152', '09122848314', 2, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(0, 'ADMIN', '0', '0', '0', '0', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(-1, 'OPU', '0', '0', '0', '0', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'کیان مقدم', '0012071110', 'd93a5def7511da3d0f2d171d9c344e91', '6d71ae54b07d7503d79b93d7dc429316', '09121234567', 3, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'علی مرادی اصل', '9876543210', '6cd9a3267f189e1d37d077c25bf7aabc', '6cc9ce21e27f9607164ee57d26e39f79', '12346656454', 2, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'احمدرضا عابدزاده', '9876543210', 'c580bfd88a260c835ad3eda2be3de690', '346aa12c18f7cc9bab9bfd1328862f81', '54848496465', 2, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'خ0هظسایبخکهشاسیب', '0012071110', '2364b66d21bbe16e5daad77ee5502426', 'a2ffc8d129d73861f63748aa461bac95', '49696994949', 3, 12, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_news`
--

CREATE TABLE IF NOT EXISTS `mhr_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_persian_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8_persian_ci NOT NULL,
  `text` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mhr_news`
--

INSERT INTO `mhr_news` (`id`, `title`, `slug`, `text`) VALUES
(1, 'تیتر1', 'سالگ 1', 'متن خبر 1'),
(2, 'تیتر 2', 'سالگ 2', 'متن خبر 2'),
(3, 'سلام عزیزم', '', 'سلام گلم چطوری؟ این اولین خبر منه'),
(4, 'hi dear', 'hi-dear', 'hi this is my first news'),
(5, 'one new news', 'one-new-news', 'one new newsone new newsone new newsone new newsone new news');

-- --------------------------------------------------------

--
-- Table structure for table `mhr_opu`
--

CREATE TABLE IF NOT EXISTS `mhr_opu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(2000) COLLATE utf8_persian_ci NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `headOffice` varchar(2000) COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `telephone` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `authCode` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333)),
  KEY `authCode` (`authCode`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Organ procurement centers' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mhr_opu`
--

INSERT INTO `mhr_opu` (`id`, `name`, `state`, `city`, `headOffice`, `mobile`, `telephone`, `username`, `password`, `authCode`, `status`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(1, 'دانشگاه علوم پزشکی آبادان', 13, 202, 'آقای علی کریمی', '09171111111', '07111111111', 'abadan', '61d401d87241eb2f65d7d46f6d64c2db', '', 1, NULL, NULL, NULL, NULL, NULL),
(2, 'دانشگاه علوم پزشکی تهران', 8, 135, 'آقای دکتر ابراهیمی', '09129876543', '02122505171', 'tehran', '1231231230', '', 1, NULL, NULL, NULL, NULL, NULL),
(3, 'دانشگاه علوم پزشکی شهید بهشتی', 8, 135, 'خانم دکتر نجفی زاده', '09129876549', '02126105289', 'beheshti', '614a51cf1ec944a0eede9eed7e10795d', 'e4dde8ec38f36cb60c6c27f7a9a91a9b', 1, NULL, NULL, NULL, NULL, NULL),
(4, 'دانشگاه علوم پزشکی قم', 19, 298, 'خانم دکتر سلیمانی', '09124564568', '02539639631', 'qom', '7417414', '', 1, NULL, NULL, NULL, NULL, NULL),
(5, 'دانشگاه علوم پزشکی ساری', 27, 403, 'آقای دکتر ساری مندی', '09111234567', '01234567891\r\n', 'sari', 'd5793f0c25620c8030af3d236bb41571', '', 1, NULL, NULL, NULL, NULL, NULL),
(6, 'دانشگاه علوم پزشکی تبریز', 1, 37, 'آقای دکتر تبریزچیان', '09141245656', '09876543211', 'tabriz', 'd93a5def7511da3d0f2d171d9c344e91', '', 1, NULL, NULL, NULL, NULL, NULL),
(7, 'دانشگاه علوم پزشکی آمل', 27, 395, 'خانم دکتر آملی', '09111111111', '02588520987', 'amol', 'd5793f0c25620c8030af3d236bb41571', '', 1, NULL, NULL, NULL, NULL, NULL),
(8, 'دانشگاه علوم پزشکی اهواز', 13, 207, 'آقای دکتر اهوازی', '09171111111', '09639639639', 'ahvaz', '591829171ee4b5008c7c98c31f98a0d4', '', 1, NULL, NULL, NULL, NULL, NULL),
(9, 'دانشگاه علوم پزشکی مشهد', 11, 191, 'آقای دکتر محمد هادی رضایی کمال آباد', '09361112030', '07417417411', 'mashhad', '1c03526ba1d141bbcd435bea9f6116e3', '', 1, NULL, NULL, NULL, NULL, NULL),
(10, 'دانشگاه علوم پزشکی اردبیل', 3, 69, 'آقای دکتر اردبیلیان', '09147894561', '04119999999', 'ardebil', 'd93a5def7511da3d0f2d171d9c344e91', '', 1, NULL, NULL, NULL, NULL, NULL),
(11, 'دانشگاه علوم پزشکی ارتش', 8, 135, 'آقای دکتر محمد سرهنگی', '09121111111', '02122222222', 'artesh', '64d6affc258ce7d1491843cbb480a0ee', '', 1, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_organs`
--

CREATE TABLE IF NOT EXISTS `mhr_organs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `heart` int(11) DEFAULT NULL,
  `liver` int(11) DEFAULT NULL,
  `kidneyRight` int(11) DEFAULT NULL,
  `kidneyLeft` int(11) DEFAULT NULL,
  `lungRight` int(11) DEFAULT NULL,
  `lungLeft` int(11) DEFAULT NULL,
  `pancreas` int(11) DEFAULT NULL,
  `tissue` int(11) DEFAULT NULL,
  `bowel` int(11) DEFAULT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='patient organs' AUTO_INCREMENT=18 ;

--
-- Dumping data for table `mhr_organs`
--

INSERT INTO `mhr_organs` (`id`, `pId`, `status`, `heart`, `liver`, `kidneyRight`, `kidneyLeft`, `lungRight`, `lungLeft`, `pancreas`, `tissue`, `bowel`, `res1`, `res2`, `res3`, `res4`, `res5`) VALUES
(1, 11, 1, 1, 1, 0, 0, 1, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 11, 1, 1, 1, 0, 0, 1, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 11, 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 6, 1, 1, 0, 0, 0, 0, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 6, 1, 1, 0, 0, 0, 0, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 17, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_pages`
--

CREATE TABLE IF NOT EXISTS `mhr_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(2000) COLLATE utf8_persian_ci NOT NULL,
  `content` longtext COLLATE utf8_persian_ci NOT NULL,
  `lastUpdateTime` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='dynamic pages' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mhr_pages`
--

INSERT INTO `mhr_pages` (`id`, `title`, `content`, `lastUpdateTime`, `status`, `res1`, `res2`, `res3`) VALUES
(1, 'درباره سامانه', '&lt;p dir=&quot;rtl&quot;&gt;&lt;span style=&quot;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:tahoma,geneva,sans-serif&quot;&gt;توضیحات پیرامون درباره &lt;span style=&quot;color:#B22222&quot;&gt;سامانه&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', 1421911326, 1, NULL, NULL, NULL),
(2, 'راهنمای استفاده از سامانه', '&lt;p dir=&quot;rtl&quot;&gt;&lt;span style=&quot;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:tahoma,geneva,sans-serif&quot;&gt;راهنمای استفاده از &lt;span style=&quot;color:#B22222&quot;&gt;سیستم&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', 1421911439, 1, NULL, NULL, NULL),
(3, 'قوانین استفاده از سامانه', '&lt;p dir=&quot;rtl&quot;&gt;&lt;span style=&quot;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:tahoma,geneva,sans-serif&quot;&gt;قوانین جاری برای استفاده از &lt;span style=&quot;color:#B22222&quot;&gt;سامانه&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', 1421911714, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_patients`
--

CREATE TABLE IF NOT EXISTS `mhr_patients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fileNumber` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `fullName` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `age` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `bodyType` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `nationalCode` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `firstGCS` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `isUnknown` int(11) DEFAULT NULL,
  `doc` int(11) NOT NULL COMMENT 'Disorders of consciousness',
  `docDetail` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL COMMENT 'Disorders of consciousness detail',
  `tol` int(11) NOT NULL COMMENT 'type of list',
  `patientStatus` int(11) NOT NULL COMMENT 'List type and condition',
  `patientStatusDetail` text COLLATE utf8_persian_ci,
  `patientDetail` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `presentation` int(11) NOT NULL COMMENT 'IP = 1, TDD = 2, HR = 3',
  `appRegisterTime` bigint(20) NOT NULL,
  `inspectorRegisterTime` bigint(20) NOT NULL,
  `hospitalizationTime` bigint(20) DEFAULT NULL,
  `gcs3ByDrTime` bigint(20) DEFAULT NULL COMMENT 'Join the gcs 3 by doctor',
  `brainDeathTime` bigint(20) DEFAULT NULL COMMENT ' On the identification of brain death',
  `patientTransferTime` bigint(20) DEFAULT NULL,
  `cardiacDeathTime` bigint(20) DEFAULT NULL COMMENT 'History of cardiac death',
  `organDonationTime` bigint(20) DEFAULT NULL,
  `coordinatorName` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT 'active = 1, inTransfer = 2, deleted = 12',
  `isArchive` int(11) DEFAULT NULL COMMENT 'YSE = 1, NO = 0',
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(10000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fileNumber` (`fileNumber`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Patient details' AUTO_INCREMENT=30 ;

--
-- Dumping data for table `mhr_patients`
--

INSERT INTO `mhr_patients` (`id`, `fileNumber`, `fullName`, `age`, `bodyType`, `nationalCode`, `firstGCS`, `isUnknown`, `doc`, `docDetail`, `tol`, `patientStatus`, `patientStatusDetail`, `patientDetail`, `presentation`, `appRegisterTime`, `inspectorRegisterTime`, `hospitalizationTime`, `gcs3ByDrTime`, `brainDeathTime`, `patientTransferTime`, `cardiacDeathTime`, `organDonationTime`, `coordinatorName`, `status`, `isArchive`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`) VALUES
(1, '12345', 'محمد هادی رضایی', '24', 'متوسط', '0012071110', '3', 0, 8, 'از خستگی زیاد', 2, 1, '', 'همین', 3, 1418503491, 1418503491, NULL, NULL, NULL, 1419712200, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(4, '987654', 'علی احمدی', '25', 'متوسط', '1234567890', '3', 0, 3, '', 1, 7, '', 'CPR', 2, 1418555758, 1418469358, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(5, '5454545', 'رضا غلامی', '25', 'چاق', '8528527410', '3', 0, 5, '', 4, 17, '', '', 3, 1418556362, 1418556362, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(6, '123456', 'علی محمد زاده', '30', 'چاق', '1234567890', '4', 0, 8, 'برخورد آجر به سر', 1, 6, '', 'سلام', 3, 1418563066, 1418476666, 1419193800, 1419280200, 1419366600, NULL, NULL, 1419539400, 'فریبا نوری ', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '44444', 'علی محمد زاده', '4', 'متوسط', '0012071110', '3', 0, 10, '', 3, 3, '', 'همین', 2, 1418563671, 1418563671, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(8, '123456789', 'محمد حسن عباسی زاده', '45', 'متوسط', '1234567890', '4', 0, 9, '', 1, 9, '', 'تصادف با موتورسیکلت', 1, 1419331209, 1419331209, 1419193800, 1419280200, 1419366600, NULL, 1419539400, NULL, '', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(9, '963852741', 'غلام احمدی', '50', 'متوسط', '9876543210', '5', 0, 7, '', 2, 2, '', '', 2, 1419336607, 1419250207, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(10, '44444', 'اعظم محمدی', '35', 'متوسط', '1234567890', '5', 0, 11, '', 3, 2, '', '', 3, 1419522467, 1419522467, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(11, '45087695120', 'بتول احمد آقایی', '26', 'متوسط', '0056484511', '3', 0, 3, '', 1, 6, '', 'برخورد چاقو به سر', 1, 1419618828, 1419618828, 1419193800, 1419280200, 1419366600, NULL, NULL, 1419539400, 'محمد هادی رضایی', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(12, '987654520ک', 'بیژن مرتضوی', '29', 'چاق', '0050414178', '5', 0, 10, '', 3, 4, '', '', 2, 1419698261, 1419698261, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'الف254698', 'عباسعلی قربانی', '31', 'متوسط', '1234567890', '4', 0, 8, 'خودکشی', 3, 1, '', 'ندارد', 3, 1419714887, 1419714887, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'پ951357', 'عطا محمدپور', '41', 'متوسط', '1248596854', '4', 0, 13, '', 3, 1, '', 'ندارد', 3, 1419975520, 1419975520, NULL, NULL, NULL, 1420317000, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(15, '456321', 'غضنفر قلی نژاد', '22', 'متوسط', '1234567890', '3', 0, 13, '', 2, 3, '', '', 1, 1420299253, 1420299253, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '5646548', 'کبری صفری', '58', 'متوسط', '1236547890', '4', 0, 9, '', 1, 13, '', '', 1, 1420299728, 1420299728, 1419193800, 1419280200, 1419366600, NULL, 1419539400, NULL, '', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(17, '5454545', 'محمد عزیزی', '32', 'متوسط', '1234567890', '5', 0, 8, 'ضربه با چاقو', 1, 6, '', 'ندارد', 3, 1420379553, 1420379553, 1419193800, 1419280200, 1419366600, NULL, NULL, 1419539400, 'علی اصغر', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(18, '54654654', 'کیوان آبعلی', '41', 'متوسط', '9876543210', '3', 0, 7, '', 2, 2, '', '', 2, 1420394398, 1420307998, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(19, '9545541', 'آناهیتا همتی', '23', 'متوسط', '0054656454', '4', 0, 3, '', 4, 22, 'دوست نداره اهدا بشه', '', 1, 1421916297, 1421916297, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(20, '111111', 'ناشناس', '-', 'متوسط', '-', '3', 1, 9, '', 2, 1, '', '', 2, 1422450416, 1422450416, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(21, '544564', 'شاه دخت اکبری', '45', 'متوسط', '1236547890', '3', 0, 12, '', 1, 1, '', '', 1, 1422453701, 1422341100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(22, '5154584', 'غلام ایوبی', '36', 'متوسط', '1236547890', '4', 0, 7, '', 2, 2, '', '', 1, 1422454476, 1422423540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(23, '4848', 'اسلام محمدی', '25', 'متوسط', '', '4', 0, 7, '', 1, 1, '', '', 1, 1422456405, 1422434580, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(24, '8451515', 'اصغر فرهادی', '51', 'متوسط', '', '4', 0, 5, '', 3, 1, '', '', 2, 1422460250, 1422427200, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(25, '215152151', 'منوچهر متکی', '45', 'متوسط', '1236547890', '3', 0, 2, '', 1, 1, '', '', 2, 1422460576, 1422445080, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(26, '321321', 'علی محمد خانی', '41', 'متوسط', '', '3', 0, 13, '', 1, 1, '', '', 1, 1422461116, 1422449280, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(27, '56421', 'اعضم عبداللهی', '21', 'متوسط', '', '3', 0, 3, '', 1, 1, '', '', 2, 1422697690, 1422690000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(28, '123456', 'امیر علی قنبری', '31', 'متوسط', '', '3', 0, 13, '', 1, 7, '', '', 2, 1422697843, 1422700920, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(29, '123456', 'امیر علی قنبری', '31', 'متوسط', '', '3', 0, 13, '', 1, 7, '', '', 2, 1422697973, 1422700920, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_patients_log`
--

CREATE TABLE IF NOT EXISTS `mhr_patients_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `breathing` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `breathingDetail` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `bodyMovement` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `bodyMovementDetail` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `faceMovement` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `faceMovementDetail` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `gag` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `cough` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `cornea` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `pupil` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `dollEye` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `secondGCS` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `sedation` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `opu` int(11) DEFAULT NULL,
  `inspector` int(11) DEFAULT NULL COMMENT '0 = gov, -1 = opu, * = inspector',
  `hospital` int(11) DEFAULT NULL,
  `section` int(11) DEFAULT NULL COMMENT 'ccu = 1, icu = 2, emergency = 3, section = 4',
  `typeOfSection` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `lastUpdateTime` bigint(20) NOT NULL,
  `isTransfer` int(11) DEFAULT NULL COMMENT 'true = 1, false = 0',
  `res1` int(11) DEFAULT NULL COMMENT 'opuID when opu insert this row',
  `res2` int(11) DEFAULT NULL,
  `res3` int(11) DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res7` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Patient details log' AUTO_INCREMENT=95 ;

--
-- Dumping data for table `mhr_patients_log`
--

INSERT INTO `mhr_patients_log` (`id`, `pId`, `status`, `breathing`, `breathingDetail`, `bodyMovement`, `bodyMovementDetail`, `faceMovement`, `faceMovementDetail`, `gag`, `cough`, `cornea`, `pupil`, `dollEye`, `secondGCS`, `sedation`, `state`, `city`, `opu`, `inspector`, `hospital`, `section`, `typeOfSection`, `lastUpdateTime`, `isTransfer`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`, `res7`) VALUES
(1, 1, 1, 'N', '0', 'O', 'قل قلک1', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 1, 1, 'N', '0', 'P', 'قل قلک2', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 1, 1, 'N', '0', 'P', 'قل قلک3', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 1, 1, 'N', '0', 'P', 'قل قلک4', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(7, 1, 1, 'N', '0', 'P', 'قل قلک5', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 1, 1, 'N', '0', 'P', 'قل قلک6', 'N', '-', 'N', 'P', 'N', 'P', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503492, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 1, 1, 'N', '0', 'N', 'قل قلک7', 'N', '-', 'N', 'P', 'N', 'P', 'N', NULL, 'NO', 8, 135, 3, 0, 2, 1, 'B', 1418503592, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 4, 1, 'P', '30', 'N', '', 'U', '', 'N', 'N', 'P', 'U', NULL, NULL, 'YES', 27, 397, 7, 0, 6, 2, 'A', 1418555758, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 5, 1, 'N', '0', 'N', '', 'N', '', 'N', 'N', 'N', 'N', NULL, NULL, 'NO', 8, 135, 3, 0, 2, 2, '', 1418556362, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 6, 1, 'N', '', 'P', '', 'N', '', 'N', 'N', 'P', 'P', NULL, NULL, 'NO', 8, 135, 2, 0, 15, 2, '', 1418563066, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 7, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', NULL, NULL, 'NO', 1, 37, 6, 0, 14, 2, 'B', 1418563671, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 8, 1, 'P', '25', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', NULL, 'Yes', 8, 135, 2, 0, 16, 2, '', 1419331209, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 9, 1, 'P', '10', 'N', 'قل قلک', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 27, 397, 7, 0, 6, 1, 'B', 1419336607, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 10, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 3, 69, 10, 0, 9, 2, '', 1419522467, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 1, 1, 'N', '0', 'N', 'قل قلک7', 'N', '-', 'N', 'P', 'N', 'P', 'N', NULL, 'NO', 11, 191, 9, 0, 22, 2, NULL, 1419589346, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(43, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 8, 135, 3, 1, 1, 4, 'جراحی', 1419980792, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 8, 135, 3, 0, 1, 4, 'جراحی', 1419976560, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 10, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 3, 69, 10, 0, 9, 2, '', 1419618213, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 10, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 3, 69, 10, 0, 9, 2, '', 1419618417, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 10, 1, 'N', '', 'N', '', 'N', '', 'P', 'P', 'U', 'U', 'N', '4', 'No', 3, 69, 10, 0, 9, 2, '', 1419618531, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 10, 1, 'N', '', 'N', '', 'N', '', 'P', 'P', 'U', 'U', 'N', '4', 'Yes', 3, 69, 10, 0, 9, 2, '', 1419618597, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 7, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', '0', '', 'No', 1, 37, 6, 0, 14, 2, 'B', 1419618680, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 11, 1, 'N', '', 'N', '', 'N', '', 'N', 'P', 'N', 'N', 'N', NULL, 'Yes', 8, 135, 3, 0, 1, 1, 'B', 1419618828, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 11, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '', 'No', 8, 135, 3, 0, 1, 1, 'B', 1419618909, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 11, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '3', 'No', 8, 135, 3, 0, 1, 1, 'B', 1419623476, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 11, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '3', 'No', 8, 135, 3, 0, 1, 1, 'B', 1419624126, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 11, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '3', 'No', 8, 135, 3, 0, 1, 1, 'B', 1419624655, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 8, 1, 'P', '25', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'Yes', 8, 135, 2, 0, 16, 2, '', 1419626646, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 8, 1, 'P', '25', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'Yes', 8, 135, 2, 0, 16, 2, '', 1419626646, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 8, 1, 'P', '25', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'Yes', 8, 135, 2, 0, 16, 2, '', 1419626646, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 8, 1, 'P', '25', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'Yes', 8, 135, 2, 0, 16, 2, '', 1419680173, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 6, 1, 'N', '', 'P', '', 'N', '', 'N', 'N', 'P', 'P', '0', '', 'Yes', 8, 135, 2, 0, 15, 2, '', 1419687317, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 6, 1, 'N', '', 'P', '', 'N', '', 'N', 'N', 'P', 'P', 'N', '', 'Yes', 8, 135, 2, 0, 15, 2, '', 1419687428, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 12, 1, 'P', '10', 'N', '', 'N', '-', 'N', 'N', 'P', 'N', 'P', NULL, 'Yes', 27, 403, 5, 0, 17, 3, '', 1419698261, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 12, 1, 'P', '10', 'N', '', 'N', '-', 'N', 'N', 'P', 'N', 'P', '', 'Yes', 27, 403, 5, 0, 17, 3, '', 1419698306, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(37, 12, 1, 'P', '35', 'P', '', 'P', '-', 'P', 'P', 'P', 'P', 'P', '', 'No', 27, 403, 5, 0, 17, 3, '', 1419698354, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(38, 5, 1, 'N', '0', 'N', '', 'N', '', 'N', 'N', 'N', 'N', '0', '', 'No', 8, 135, 3, 0, 2, 2, '', 1419711005, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(39, 13, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 19, 298, 4, 0, 19, 1, '', 1419714887, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(41, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', NULL, 'Yes', 8, 135, 3, 1, 1, 4, 'جراحی', 1419975520, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(44, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 8, 135, 3, 1, 1, 4, 'جراحی', 1419980792, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(45, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 8, 135, 3, 0, 1, 4, 'جراحی', 1420184122, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(46, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 8, 135, 3, 0, 1, 4, 'جراحی', 1420184828, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(47, 15, 1, 'P', '12', 'N', '', 'N', '', 'P', 'N', 'P', 'N', 'N', NULL, 'Yes', 8, 135, 3, 1, 2, 3, '', 1420299253, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(48, 16, 1, 'N', '', 'N', '', 'N', '', 'U', 'N', 'P', 'N', 'P', NULL, 'Yes', 8, 135, 3, -1, 2, 2, 'B', 1420299728, 0, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(49, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1420379553, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(50, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1420379849, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(51, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1420380875, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(52, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1420380875, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(53, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1420380979, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(54, 16, 1, 'N', '', 'N', '', 'N', '', 'U', 'N', 'P', 'N', 'P', '', 'Yes', 8, 135, 3, 0, 2, 2, 'B', 1420382539, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(55, 16, 1, 'N', '', 'N', '', 'N', '', 'U', 'N', 'P', 'N', 'P', '', 'Yes', 8, 135, 3, 0, 2, 2, 'B', 1420382539, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(56, 15, 1, 'P', '12', 'N', '', 'N', '', 'P', 'N', 'P', 'N', 'N', '', 'Yes', 8, 135, 3, 0, 2, 3, '', 1420382655, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(57, 15, 1, 'P', '12', 'N', '', 'N', '', 'P', 'N', 'P', 'N', 'N', '', 'Yes', 8, 135, 3, 0, 2, 3, '', 1420382655, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(58, 15, 1, 'P', '12', 'N', '', 'N', '', 'P', 'N', 'P', 'N', 'N', '', 'Yes', 8, 135, 3, 0, 1, 3, '', 1420383273, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(59, 15, 1, 'P', '12', 'N', '', 'N', '', 'P', 'N', 'P', 'N', 'N', '', 'Yes', 8, 135, 3, 0, 1, 3, '', 1420383273, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(60, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 11, 191, 9, 0, 22, 2, NULL, 1420383450, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(61, 14, 1, 'P', '25', 'N', '', 'N', '', 'N', 'P', 'N', 'P', 'P', '', 'Yes', 11, 191, 9, 0, 22, 2, NULL, 1420383450, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(62, 18, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', NULL, 'No', 8, 135, 3, -1, 2, 2, 'B', 1420394398, 0, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(63, 18, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'No', 8, 135, 3, 0, 2, 2, 'B', 1420979510, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(64, 18, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'No', 8, 135, 3, 0, 2, 2, 'B', 1420979526, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(65, 18, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'P', '', 'No', 8, 135, 3, 0, 2, 2, 'B', 1420979759, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(66, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1421008718, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(67, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1421008773, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(68, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1421010123, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(69, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1421010142, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(70, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'Yes', 13, 204, 1, 0, 4, 1, 'B', 1421010160, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(71, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 13, 204, 1, 0, 4, 1, 'B', 1421010180, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(72, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 13, 204, 1, 0, 4, 1, 'B', 1421051348, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(73, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 13, 204, 1, 0, 4, 1, 'B', 1421069571, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(74, 19, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 27, 397, 7, 0, 6, 1, '', 1421916297, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(75, 17, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 13, 204, 1, 0, 4, 1, 'B', 1422090728, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(76, 20, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 1, 37, 6, 0, 13, 3, '', 1422450416, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(77, 21, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 27, 395, 7, 0, 5, 2, '', 1422453701, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(78, 21, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '', 'No', 27, 395, 7, 0, 5, 2, '', 1422453803, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(79, 22, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 8, 135, 3, 1, 1, 1, '', 1422454476, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(80, 22, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 8, 135, 3, 0, 1, 1, '', 1422454495, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(81, 22, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 8, 135, 3, -1, 1, 1, '', 1422454752, 0, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(82, 22, 1, 'P', '', 'U', '', 'N', '', 'U', 'U', 'U', 'U', 'U', '', 'No', 8, 135, 3, 1, 1, 1, '', 1422454872, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(83, 22, 1, 'P', '', 'U', '', 'N', '', 'U', 'U', 'U', 'U', 'P', '', 'No', 8, 135, 3, 0, 1, 1, '', 1422455061, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(84, 22, 1, 'N', '', 'U', '', 'N', '', 'U', 'U', 'P', 'P', 'P', '', 'No', 8, 135, 3, -1, 1, 1, '', 1422455417, 0, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(85, 22, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '', 'No', 8, 135, 3, 1, 1, 1, '', 1422455489, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(86, 23, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 13, 202, 1, 0, 3, 1, '', 1422456405, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(87, 23, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '', 'No', 13, 202, 1, 0, 3, 1, '', 1422456719, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(88, 24, 1, 'U', '', 'U', '', 'U', '', 'U', 'U', 'U', 'U', 'U', NULL, 'No', 8, 135, 11, 0, 8, 2, '', 1422460250, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(89, 25, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'Yes', 1, 37, 6, 0, 13, 3, '', 1422460576, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(90, 26, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'Yes', 8, 135, 3, 1, 2, 1, 'جراحی', 1422461116, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(91, 26, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', '', 'Yes', 8, 135, 3, 0, 2, 1, 'جراحی', 1422461170, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(92, 27, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 27, 395, 7, 0, 5, 2, '', 1422697690, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(93, 28, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 27, 395, 7, 0, 5, 3, 'B', 1422697843, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(94, 29, 1, 'N', '', 'N', '', 'N', '', 'N', 'N', 'N', 'N', 'N', NULL, 'No', 27, 395, 7, 0, 5, 3, 'B', 1422697973, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_setting`
--

CREATE TABLE IF NOT EXISTS `mhr_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullName` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `authCode` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `lastOnline` bigint(20) DEFAULT NULL,
  `lastIP` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `siteTitle` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mhr_setting`
--

INSERT INTO `mhr_setting` (`id`, `fullName`, `mobile`, `email`, `password`, `authCode`, `lastOnline`, `lastIP`, `siteTitle`) VALUES
(1, 'سرکار خانم دکتر نجفی زاده', '09123206582', 'admin@ehda.ir', 'da13ab58f3759b6bbdad8880cd5d15bb ', '8880cd5d15bb', NULL, NULL, 'سامانه کشوری ثبت اطلاعات فراهم آوری اعضا و نسوج پیوندی'),
(2, 'محمد هادی رضایی', '09361112030', 'mr.mhrezaei@gmail.com', '48382ac767744e3dd771a0c991bf4484', '544717b1474dddfbfe1877cb2fde59a4', NULL, NULL, '-');

-- --------------------------------------------------------

--
-- Table structure for table `mhr_states`
--

CREATE TABLE IF NOT EXISTS `mhr_states` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `parentID` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='states and city of iran' AUTO_INCREMENT=476 ;

--
-- Dumping data for table `mhr_states`
--

INSERT INTO `mhr_states` (`id`, `name`, `parentID`, `status`, `res1`, `res2`) VALUES
(1, 'آذربایجان شرقی', 0, 1, NULL, NULL),
(2, 'آذربایجان غربی', 0, 1, NULL, NULL),
(3, 'اردبیل', 0, 1, NULL, NULL),
(4, 'اصفهان', 0, 1, NULL, NULL),
(5, 'البرز', 0, 1, NULL, NULL),
(6, 'ایلام', 0, 1, NULL, NULL),
(7, 'بوشهر', 0, 1, NULL, NULL),
(8, 'تهران', 0, 1, NULL, NULL),
(9, 'چهار محال و بختیاری', 0, 1, NULL, NULL),
(10, 'خراسان جنوبی', 0, 1, NULL, NULL),
(11, 'خراسان رضوی', 0, 1, NULL, NULL),
(12, 'خراسان شمالی', 0, 1, NULL, NULL),
(13, 'خوزستان', 0, 1, NULL, NULL),
(14, 'زنجان', 0, 1, NULL, NULL),
(15, 'سمنان', 0, 1, NULL, NULL),
(16, 'سیستان و بلوچستان', 0, 1, NULL, NULL),
(17, 'فارس', 0, 1, NULL, NULL),
(18, 'قزوین', 0, 1, NULL, NULL),
(19, 'قم', 0, 1, NULL, NULL),
(20, 'کردستان', 0, 1, NULL, NULL),
(21, 'کرمان', 0, 1, NULL, NULL),
(22, 'کرمانشاه', 0, 1, NULL, NULL),
(23, 'کهگیلویه و بویراحمد', 0, 1, NULL, NULL),
(24, 'گلستان', 0, 1, NULL, NULL),
(25, 'گیلان', 0, 1, NULL, NULL),
(26, 'لرستان', 0, 1, NULL, NULL),
(27, 'مازندران', 0, 1, NULL, NULL),
(28, 'مرکزی', 0, 1, NULL, NULL),
(29, 'هرمزگان', 0, 1, NULL, NULL),
(30, 'همدان', 0, 1, NULL, NULL),
(31, 'یزد', 0, 1, NULL, NULL),
(32, 'آذرشهر', 1, 1, NULL, NULL),
(33, 'اسکو', 1, 1, NULL, NULL),
(34, 'اهر', 1, 1, NULL, NULL),
(35, 'بستان آباد', 1, 1, NULL, NULL),
(36, 'بناب', 1, 1, NULL, NULL),
(37, 'تبریز', 1, 1, NULL, NULL),
(38, 'جلفا', 1, 1, NULL, NULL),
(39, 'چاراویماق', 1, 1, NULL, NULL),
(40, 'خدا آفرین', 1, 1, NULL, NULL),
(41, 'سراب', 1, 1, NULL, NULL),
(42, 'شبستر', 1, 1, NULL, NULL),
(43, 'عجب شیر', 1, 1, NULL, NULL),
(44, 'کلیبر', 1, 1, NULL, NULL),
(45, 'مراغه', 1, 1, NULL, NULL),
(46, 'مرند', 1, 1, NULL, NULL),
(47, 'ملکان', 1, 1, NULL, NULL),
(48, 'میانه', 1, 1, NULL, NULL),
(49, 'ورزقان', 1, 1, NULL, NULL),
(50, 'هریس', 1, 1, NULL, NULL),
(51, 'هشترود', 1, 1, NULL, NULL),
(52, 'ارومیه', 2, 1, NULL, NULL),
(53, 'اشنویه', 2, 1, NULL, NULL),
(54, 'بوکان', 2, 1, NULL, NULL),
(55, 'پلدشت', 2, 1, NULL, NULL),
(56, 'پیرانشهر', 2, 1, NULL, NULL),
(57, 'تکاب', 2, 1, NULL, NULL),
(58, 'چالدران', 2, 1, NULL, NULL),
(59, 'چایپاره', 2, 1, NULL, NULL),
(60, 'خوی', 2, 1, NULL, NULL),
(61, 'سر دشت', 2, 1, NULL, NULL),
(62, 'سلماس', 2, 1, NULL, NULL),
(63, 'شاهین دژ', 2, 1, NULL, NULL),
(64, 'شوط', 2, 1, NULL, NULL),
(65, 'ماکو', 2, 1, NULL, NULL),
(66, 'مهاباد', 2, 1, NULL, NULL),
(67, 'میاندوآب', 2, 1, NULL, NULL),
(68, 'نقده', 2, 1, NULL, NULL),
(69, 'اردبیل', 3, 1, NULL, NULL),
(70, 'بیله سوار', 3, 1, NULL, NULL),
(71, 'پارس آباد', 3, 1, NULL, NULL),
(72, 'خلخال', 3, 1, NULL, NULL),
(73, 'سرعین', 3, 1, NULL, NULL),
(74, 'کوثر', 3, 1, NULL, NULL),
(75, 'گرمی', 3, 1, NULL, NULL),
(76, 'مشگین شهر', 3, 1, NULL, NULL),
(77, 'نمین', 3, 1, NULL, NULL),
(78, 'نیر', 3, 1, NULL, NULL),
(79, 'آران و بیدگل', 4, 1, NULL, NULL),
(80, 'اردستان', 4, 1, NULL, NULL),
(81, 'اصفهان', 4, 1, NULL, NULL),
(82, 'برخوار', 4, 1, NULL, NULL),
(83, 'بوئین میاندشت', 4, 1, NULL, NULL),
(84, 'تیران و کرون', 4, 1, NULL, NULL),
(85, 'چادگان', 4, 1, NULL, NULL),
(86, 'خمینی شهر', 4, 1, NULL, NULL),
(87, 'خوانسار', 4, 1, NULL, NULL),
(88, 'خور و بیابانک', 4, 1, NULL, NULL),
(89, 'دهاقان', 4, 1, NULL, NULL),
(90, 'سمیرم', 4, 1, NULL, NULL),
(91, 'شاهین شهر و میمه', 4, 1, NULL, NULL),
(92, 'شهرضا', 4, 1, NULL, NULL),
(93, 'فریدن', 4, 1, NULL, NULL),
(94, 'فریدونشهر', 4, 1, NULL, NULL),
(95, 'فلاورجان', 4, 1, NULL, NULL),
(96, 'کاشان', 4, 1, NULL, NULL),
(97, 'گلپایگان', 4, 1, NULL, NULL),
(98, 'لنجان', 4, 1, NULL, NULL),
(99, 'مبارکه', 4, 1, NULL, NULL),
(100, 'نائین', 4, 1, NULL, NULL),
(101, 'نجف آباد', 4, 1, NULL, NULL),
(102, 'نطنز', 4, 1, NULL, NULL),
(110, 'آبدانان', 6, 1, NULL, NULL),
(104, 'اشتهارد', 5, 1, NULL, NULL),
(105, 'ساوجبلاغ', 5, 1, NULL, NULL),
(106, 'طالقان', 5, 1, NULL, NULL),
(107, 'فردیس', 5, 1, NULL, NULL),
(108, 'کرج', 5, 1, NULL, NULL),
(109, 'نظر آباد', 5, 1, NULL, NULL),
(111, 'ایلام', 6, 1, NULL, NULL),
(112, 'ایوان', 6, 1, NULL, NULL),
(113, 'بدره', 6, 1, NULL, NULL),
(114, 'چرداول', 6, 1, NULL, NULL),
(115, 'دره شهر', 6, 1, NULL, NULL),
(116, 'دهلران', 6, 1, NULL, NULL),
(117, 'سیروان', 6, 1, NULL, NULL),
(118, 'ملکشاهی', 6, 1, NULL, NULL),
(119, 'مهران', 6, 1, NULL, NULL),
(120, 'بوشهر', 7, 1, NULL, NULL),
(121, 'تنگستان', 7, 1, NULL, NULL),
(122, 'جم', 7, 1, NULL, NULL),
(123, 'دشتستان', 7, 1, NULL, NULL),
(124, 'دشتی', 7, 1, NULL, NULL),
(125, 'دیر', 7, 1, NULL, NULL),
(126, 'دیلم', 7, 1, NULL, NULL),
(127, 'عسلویه', 7, 1, NULL, NULL),
(128, 'کنگان', 7, 1, NULL, NULL),
(129, 'گناوه', 7, 1, NULL, NULL),
(130, 'اسلامشهر', 8, 1, NULL, NULL),
(131, 'بهارستان', 8, 1, NULL, NULL),
(132, 'پاکدشت', 8, 1, NULL, NULL),
(133, 'پردیس', 8, 1, NULL, NULL),
(134, 'پیشوا', 8, 1, NULL, NULL),
(135, 'تهران', 8, 1, NULL, NULL),
(136, 'دماوند', 8, 1, NULL, NULL),
(137, 'رباط کریم', 8, 1, NULL, NULL),
(138, 'ری', 8, 1, NULL, NULL),
(139, 'شمیرانات', 8, 1, NULL, NULL),
(140, 'شهریار', 8, 1, NULL, NULL),
(141, 'فیروز کوه', 8, 1, NULL, NULL),
(142, 'قدس', 8, 1, NULL, NULL),
(143, 'قرچک', 8, 1, NULL, NULL),
(144, 'ملارد', 8, 1, NULL, NULL),
(145, 'ورامین', 8, 1, NULL, NULL),
(146, 'اردل', 9, 1, NULL, NULL),
(147, 'بروجن', 9, 1, NULL, NULL),
(148, 'بن', 9, 1, NULL, NULL),
(149, 'سامان', 9, 1, NULL, NULL),
(150, 'شهر کرد', 9, 1, NULL, NULL),
(151, 'فارسان', 9, 1, NULL, NULL),
(152, 'کوهرنگ', 9, 1, NULL, NULL),
(153, 'کیار', 9, 1, NULL, NULL),
(154, 'لردگان', 9, 1, NULL, NULL),
(155, 'بشرویه', 10, 1, NULL, NULL),
(156, 'بیرجند', 10, 1, NULL, NULL),
(157, 'خوسف', 10, 1, NULL, NULL),
(158, 'درمیان', 10, 1, NULL, NULL),
(159, 'زیرکوه', 10, 1, NULL, NULL),
(160, 'سرایان', 10, 1, NULL, NULL),
(161, 'سربیشه', 10, 1, NULL, NULL),
(162, 'طبس', 10, 1, NULL, NULL),
(163, 'فردوس', 10, 1, NULL, NULL),
(164, 'قائنات', 10, 1, NULL, NULL),
(165, 'نهبندان', 10, 1, NULL, NULL),
(166, 'باخرز', 11, 1, NULL, NULL),
(167, 'بجستان', 11, 1, NULL, NULL),
(168, 'بردسکن', 11, 1, NULL, NULL),
(169, 'بینالود', 11, 1, NULL, NULL),
(170, 'تایباد', 11, 1, NULL, NULL),
(171, 'تربت جام', 11, 1, NULL, NULL),
(172, 'تربت حیدریه', 11, 1, NULL, NULL),
(173, 'جغتای', 11, 1, NULL, NULL),
(174, 'جوین', 11, 1, NULL, NULL),
(175, 'چناران', 11, 1, NULL, NULL),
(176, 'خلیل آباد', 11, 1, NULL, NULL),
(177, 'خواف', 11, 1, NULL, NULL),
(178, 'خوشاب', 11, 1, NULL, NULL),
(179, 'داورزن', 11, 1, NULL, NULL),
(180, 'درگز', 11, 1, NULL, NULL),
(181, 'رشتخوار', 11, 1, NULL, NULL),
(182, 'زاوه', 11, 1, NULL, NULL),
(183, 'سبزوار', 11, 1, NULL, NULL),
(184, 'سرخس', 11, 1, NULL, NULL),
(185, 'فریمان', 11, 1, NULL, NULL),
(186, 'فیروزه', 11, 1, NULL, NULL),
(187, 'قوچان', 11, 1, NULL, NULL),
(188, 'کاشمر', 11, 1, NULL, NULL),
(189, 'کلات', 11, 1, NULL, NULL),
(190, 'گناباد', 11, 1, NULL, NULL),
(191, 'مشهد', 11, 1, NULL, NULL),
(192, 'مه ولات', 11, 1, NULL, NULL),
(193, 'نیشابور', 11, 1, NULL, NULL),
(194, 'اسفراین', 12, 1, NULL, NULL),
(195, 'بجنورد', 12, 1, NULL, NULL),
(196, 'جاجرم', 12, 1, NULL, NULL),
(197, 'راز و جرگلان', 12, 1, NULL, NULL),
(198, 'شیروان', 12, 1, NULL, NULL),
(199, 'فاروج', 12, 1, NULL, NULL),
(200, 'گرمه', 12, 1, NULL, NULL),
(201, 'مانه و سملقان', 12, 1, NULL, NULL),
(202, 'آبادان', 13, 1, NULL, NULL),
(203, 'آغاجاری', 13, 1, NULL, NULL),
(204, 'امیدیه', 13, 1, NULL, NULL),
(205, 'اندیکا', 13, 1, NULL, NULL),
(206, 'اندیمشک', 13, 1, NULL, NULL),
(207, 'اهواز', 13, 1, NULL, NULL),
(208, 'ایذه', 13, 1, NULL, NULL),
(209, 'باغ ملک', 13, 1, NULL, NULL),
(210, 'باوی', 13, 1, NULL, NULL),
(211, 'بندر ماهشهر', 13, 1, NULL, NULL),
(212, 'بهبهان', 13, 1, NULL, NULL),
(213, 'حمیدیه', 13, 1, NULL, NULL),
(214, 'خرمشهر', 13, 1, NULL, NULL),
(215, 'دزفول', 13, 1, NULL, NULL),
(216, 'دشت آزادگان', 13, 1, NULL, NULL),
(217, 'رامشیر', 13, 1, NULL, NULL),
(218, 'رامهرمز', 13, 1, NULL, NULL),
(219, 'شادگان', 13, 1, NULL, NULL),
(220, 'شوش', 13, 1, NULL, NULL),
(221, 'شوشتر', 13, 1, NULL, NULL),
(222, 'کارون', 13, 1, NULL, NULL),
(223, 'گتوند', 13, 1, NULL, NULL),
(224, 'لالی', 13, 1, NULL, NULL),
(225, 'مسجد سلیمان', 13, 1, NULL, NULL),
(226, 'هفتگل', 13, 1, NULL, NULL),
(227, 'هندیجان', 13, 1, NULL, NULL),
(228, 'هویزه', 13, 1, NULL, NULL),
(229, 'ابهر', 14, 1, NULL, NULL),
(230, 'ایجرود', 14, 1, NULL, NULL),
(231, 'خدابنده', 14, 1, NULL, NULL),
(232, 'خرمدره', 14, 1, NULL, NULL),
(233, 'زنجان', 14, 1, NULL, NULL),
(234, 'سلطانیه', 14, 1, NULL, NULL),
(235, 'طارم', 14, 1, NULL, NULL),
(236, 'ماهنشان', 14, 1, NULL, NULL),
(237, 'آرادان', 15, 1, NULL, NULL),
(238, 'دامغان', 15, 1, NULL, NULL),
(239, 'سمنان', 15, 1, NULL, NULL),
(240, 'شاهرود', 15, 1, NULL, NULL),
(241, 'گرمسار', 15, 1, NULL, NULL),
(242, 'مهدی شهر', 15, 1, NULL, NULL),
(243, 'میامی', 15, 1, NULL, NULL),
(244, 'ایرانشهر', 16, 1, NULL, NULL),
(245, 'چاه بهار', 16, 1, NULL, NULL),
(246, 'خاش', 16, 1, NULL, NULL),
(247, 'دلگان', 16, 1, NULL, NULL),
(248, 'زابل', 16, 1, NULL, NULL),
(249, 'زاهدان', 16, 1, NULL, NULL),
(250, 'زهک', 16, 1, NULL, NULL),
(251, 'سراوان', 16, 1, NULL, NULL),
(252, 'سرباز', 16, 1, NULL, NULL),
(253, 'سیب سوران', 16, 1, NULL, NULL),
(254, 'فنوج', 16, 1, NULL, NULL),
(255, 'قصرقند', 16, 1, NULL, NULL),
(256, 'کنارک', 16, 1, NULL, NULL),
(257, 'مهرستان', 16, 1, NULL, NULL),
(258, 'میرجاوه', 16, 1, NULL, NULL),
(259, 'نیک شهر', 16, 1, NULL, NULL),
(260, 'نیمروز', 16, 1, NULL, NULL),
(261, 'هامون', 16, 1, NULL, NULL),
(262, 'هیرمند', 16, 1, NULL, NULL),
(263, 'آباده', 17, 1, NULL, NULL),
(264, 'ارسنجان', 17, 1, NULL, NULL),
(265, 'استهبان', 17, 1, NULL, NULL),
(266, 'اقلید', 17, 1, NULL, NULL),
(267, 'بوانات', 17, 1, NULL, NULL),
(268, 'پاسارگاد', 17, 1, NULL, NULL),
(269, 'جهرم', 17, 1, NULL, NULL),
(270, 'خرامه', 17, 1, NULL, NULL),
(271, 'خرم بید', 17, 1, NULL, NULL),
(272, 'خنج', 17, 1, NULL, NULL),
(273, 'داراب', 17, 1, NULL, NULL),
(274, 'رستم', 17, 1, NULL, NULL),
(275, 'زرین دشت', 17, 1, NULL, NULL),
(276, 'سپیدان', 17, 1, NULL, NULL),
(277, 'سروستان', 17, 1, NULL, NULL),
(278, 'شیراز', 17, 1, NULL, NULL),
(279, 'فراشبند', 17, 1, NULL, NULL),
(280, 'فسا', 17, 1, NULL, NULL),
(281, 'فیروز آباد', 17, 1, NULL, NULL),
(282, 'قیروکارزین', 17, 1, NULL, NULL),
(283, 'کازرون', 17, 1, NULL, NULL),
(284, 'کوار', 17, 1, NULL, NULL),
(285, 'گراش', 17, 1, NULL, NULL),
(286, 'لارستان', 17, 1, NULL, NULL),
(287, 'لامرد', 17, 1, NULL, NULL),
(288, 'مرودشت', 17, 1, NULL, NULL),
(289, 'ممسنی', 17, 1, NULL, NULL),
(290, 'مهر', 17, 1, NULL, NULL),
(291, 'نی ریز', 17, 1, NULL, NULL),
(292, 'آبیک', 18, 1, NULL, NULL),
(293, 'آوج', 18, 1, NULL, NULL),
(294, 'البرز', 18, 1, NULL, NULL),
(295, 'بوئین زهرا', 18, 1, NULL, NULL),
(296, 'تاکستان', 18, 1, NULL, NULL),
(297, 'قزوین', 18, 1, NULL, NULL),
(298, 'قم', 19, 1, NULL, NULL),
(299, 'بانه', 20, 1, NULL, NULL),
(300, 'بیجار', 20, 1, NULL, NULL),
(301, 'دهگلان', 20, 1, NULL, NULL),
(302, 'دیواندره', 20, 1, NULL, NULL),
(303, 'سروآباد', 20, 1, NULL, NULL),
(304, 'سقز', 20, 1, NULL, NULL),
(305, 'سنندج', 20, 1, NULL, NULL),
(306, 'قروه', 20, 1, NULL, NULL),
(307, 'کامیاران', 20, 1, NULL, NULL),
(308, 'مریوان', 20, 1, NULL, NULL),
(309, 'ارزوئیه', 21, 1, NULL, NULL),
(310, 'انار', 21, 1, NULL, NULL),
(311, 'بافت', 21, 1, NULL, NULL),
(312, 'بردسیر', 21, 1, NULL, NULL),
(313, 'بم', 21, 1, NULL, NULL),
(314, 'جیرفت', 21, 1, NULL, NULL),
(315, 'رابر', 21, 1, NULL, NULL),
(316, 'راور', 21, 1, NULL, NULL),
(317, 'رفسنجان', 21, 1, NULL, NULL),
(318, 'رودبار جنوب', 21, 1, NULL, NULL),
(319, 'ریگان', 21, 1, NULL, NULL),
(320, 'زرند', 21, 1, NULL, NULL),
(321, 'سیرجان', 21, 1, NULL, NULL),
(322, 'شهر بابک', 21, 1, NULL, NULL),
(323, 'عنبر آباد', 21, 1, NULL, NULL),
(324, 'فاریاب', 21, 1, NULL, NULL),
(325, 'فهرج', 21, 1, NULL, NULL),
(326, 'قلعه گنج', 21, 1, NULL, NULL),
(327, 'کرمان', 21, 1, NULL, NULL),
(328, 'کوهبنان', 21, 1, NULL, NULL),
(329, 'کهنوج', 21, 1, NULL, NULL),
(330, 'منوجان', 21, 1, NULL, NULL),
(331, 'نرماشیر', 21, 1, NULL, NULL),
(332, 'اسلام آباد غرب', 22, 1, NULL, NULL),
(333, 'پاوه', 22, 1, NULL, NULL),
(334, 'ثلاث باباجانی', 22, 1, NULL, NULL),
(335, 'جوانرود', 22, 1, NULL, NULL),
(336, 'دالاهو', 22, 1, NULL, NULL),
(337, 'روانسر', 22, 1, NULL, NULL),
(338, 'سر پل ذهاب', 22, 1, NULL, NULL),
(339, 'سنقر', 22, 1, NULL, NULL),
(340, 'صحنه', 22, 1, NULL, NULL),
(341, 'قصر شیرین', 22, 1, NULL, NULL),
(342, 'کرمانشاه', 22, 1, NULL, NULL),
(343, 'کنگاور', 22, 1, NULL, NULL),
(344, 'گیلانغرب', 22, 1, NULL, NULL),
(345, 'هرسین', 22, 1, NULL, NULL),
(346, 'باشت', 23, 1, NULL, NULL),
(347, 'بویر احمد', 23, 1, NULL, NULL),
(348, 'بهمئی', 23, 1, NULL, NULL),
(349, 'چرام', 23, 1, NULL, NULL),
(350, 'دنا', 23, 1, NULL, NULL),
(351, 'کهگیلویه', 23, 1, NULL, NULL),
(352, 'گچساران', 23, 1, NULL, NULL),
(353, 'لنده', 23, 1, NULL, NULL),
(354, 'آزاد شهر', 24, 1, NULL, NULL),
(355, 'آق قلا', 24, 1, NULL, NULL),
(356, 'بندر گز', 24, 1, NULL, NULL),
(357, 'ترکمن', 24, 1, NULL, NULL),
(358, 'رامیان', 24, 1, NULL, NULL),
(359, 'علی آباد', 24, 1, NULL, NULL),
(360, 'کردکوی', 24, 1, NULL, NULL),
(361, 'کلاله', 24, 1, NULL, NULL),
(362, 'گالیکش', 24, 1, NULL, NULL),
(363, 'گرگان', 24, 1, NULL, NULL),
(364, 'گمیشان', 24, 1, NULL, NULL),
(365, 'گنبد کاووس', 24, 1, NULL, NULL),
(366, 'مراوه تپه', 24, 1, NULL, NULL),
(367, 'مینودشت', 24, 1, NULL, NULL),
(368, 'آستارا', 25, 1, NULL, NULL),
(369, 'آستانه اشرفیه', 25, 1, NULL, NULL),
(370, 'املش', 25, 1, NULL, NULL),
(371, 'بندر انزلی', 25, 1, NULL, NULL),
(372, 'رشت', 25, 1, NULL, NULL),
(373, 'رضوانشهر', 25, 1, NULL, NULL),
(374, 'رودبار', 25, 1, NULL, NULL),
(375, 'رودسر', 25, 1, NULL, NULL),
(376, 'سیاهکل', 25, 1, NULL, NULL),
(377, 'شفت', 25, 1, NULL, NULL),
(378, 'صومعه سرا', 25, 1, NULL, NULL),
(379, 'تالش', 25, 1, NULL, NULL),
(380, 'فومن', 25, 1, NULL, NULL),
(381, 'لاهیجان', 25, 1, NULL, NULL),
(382, 'لنگرود', 25, 1, NULL, NULL),
(383, 'ماسال', 25, 1, NULL, NULL),
(384, 'ازنا', 26, 1, NULL, NULL),
(385, 'الیگودرز', 26, 1, NULL, NULL),
(386, 'بروجرد', 26, 1, NULL, NULL),
(387, 'پلدختر', 26, 1, NULL, NULL),
(388, 'خرم آباد', 26, 1, NULL, NULL),
(389, 'دلفان', 26, 1, NULL, NULL),
(390, 'دورود', 26, 1, NULL, NULL),
(391, 'دوره', 26, 1, NULL, NULL),
(392, 'رومشکان', 26, 1, NULL, NULL),
(393, 'سلسله', 26, 1, NULL, NULL),
(394, 'کوهدشت', 26, 1, NULL, NULL),
(395, 'آمل', 27, 1, NULL, NULL),
(396, 'بابل', 27, 1, NULL, NULL),
(397, 'بابلسر', 27, 1, NULL, NULL),
(398, 'بهشهر', 27, 1, NULL, NULL),
(399, 'تنکابن', 27, 1, NULL, NULL),
(400, 'جویبار', 27, 1, NULL, NULL),
(401, 'چالوس', 27, 1, NULL, NULL),
(402, 'رامسر', 27, 1, NULL, NULL),
(403, 'ساری', 27, 1, NULL, NULL),
(404, 'سواد کوه', 27, 1, NULL, NULL),
(405, 'سوادکوه شمالی', 27, 1, NULL, NULL),
(406, 'سیمرغ', 27, 1, NULL, NULL),
(407, 'عباس آباد', 27, 1, NULL, NULL),
(408, 'فریدونکنار', 27, 1, NULL, NULL),
(409, 'قائم شهر', 27, 1, NULL, NULL),
(410, 'کلاردشت', 27, 1, NULL, NULL),
(411, 'گلوگاه', 27, 1, NULL, NULL),
(412, 'محمود آباد', 27, 1, NULL, NULL),
(413, 'میاندورود', 27, 1, NULL, NULL),
(414, 'نکا', 27, 1, NULL, NULL),
(415, 'نور', 27, 1, NULL, NULL),
(416, 'نوشهر', 27, 1, NULL, NULL),
(417, 'آشتیان', 28, 1, NULL, NULL),
(418, 'اراک', 28, 1, NULL, NULL),
(419, 'تفرش', 28, 1, NULL, NULL),
(420, 'خمین', 28, 1, NULL, NULL),
(421, 'خنداب', 28, 1, NULL, NULL),
(422, 'دلیجان', 28, 1, NULL, NULL),
(423, 'زرندیه', 28, 1, NULL, NULL),
(424, 'ساوه', 28, 1, NULL, NULL),
(425, 'شازند', 28, 1, NULL, NULL),
(426, 'فراهان', 28, 1, NULL, NULL),
(427, 'کمیجان', 28, 1, NULL, NULL),
(428, 'محلات', 28, 1, NULL, NULL),
(429, 'ابوموسی', 29, 1, NULL, NULL),
(430, 'بستک', 29, 1, NULL, NULL),
(431, 'بشاگرد', 29, 1, NULL, NULL),
(432, 'بندرعباس', 29, 1, NULL, NULL),
(433, 'بندرلنگه', 29, 1, NULL, NULL),
(434, 'پارسیان', 29, 1, NULL, NULL),
(435, 'جاسک', 29, 1, NULL, NULL),
(436, 'حاجی آباد', 29, 1, NULL, NULL),
(437, 'خمیر', 29, 1, NULL, NULL),
(438, 'رودان', 29, 1, NULL, NULL),
(439, 'سیریک', 29, 1, NULL, NULL),
(440, 'قشم', 29, 1, NULL, NULL),
(441, 'میناب', 29, 1, NULL, NULL),
(442, 'اسد آباد', 30, 1, NULL, NULL),
(443, 'بهار', 30, 1, NULL, NULL),
(444, 'تویسرکان', 30, 1, NULL, NULL),
(445, 'رزن', 30, 1, NULL, NULL),
(446, 'فامنین', 30, 1, NULL, NULL),
(447, 'کبودرآهنگ', 30, 1, NULL, NULL),
(448, 'ملایر', 30, 1, NULL, NULL),
(449, 'نهاوند', 30, 1, NULL, NULL),
(450, 'همدان', 30, 1, NULL, NULL),
(451, 'ابرکوه', 31, 1, NULL, NULL),
(452, 'اردکان', 31, 1, NULL, NULL),
(453, 'بافق', 31, 1, NULL, NULL),
(454, 'بهاباد', 31, 1, NULL, NULL),
(455, 'تفت', 31, 1, NULL, NULL),
(456, 'خاتم', 31, 1, NULL, NULL),
(457, 'صدوق', 31, 1, NULL, NULL),
(458, 'مهریز', 31, 1, NULL, NULL),
(459, 'میبد', 31, 1, NULL, NULL),
(460, 'یزد', 31, 1, NULL, NULL),
(461, 'زیرآب', 27, 1, NULL, NULL),
(462, 'نورآباد', 26, 1, NULL, NULL),
(463, 'الشتر', 26, 1, NULL, NULL),
(464, 'امیرکلا', 27, 1, NULL, NULL),
(465, 'الوند', 18, 1, NULL, NULL),
(466, 'رستم آباد', 25, 1, NULL, NULL),
(467, 'منجیل', 25, 1, NULL, NULL),
(468, 'طوالش', 25, 1, NULL, NULL),
(469, 'برازجان', 7, 1, NULL, NULL),
(470, 'خورموج', 7, 1, NULL, NULL),
(471, 'اهرم', 7, 1, NULL, NULL),
(472, 'ماهشهر', 13, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_tests`
--

CREATE TABLE IF NOT EXISTS `mhr_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `na` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `k` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `bun` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `cr` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `alt` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `ast` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `wbc` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `plt` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `hb` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `bs` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `out` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` int(11) DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res5` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res6` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Patient tests' AUTO_INCREMENT=26 ;

--
-- Dumping data for table `mhr_tests`
--

INSERT INTO `mhr_tests` (`id`, `pId`, `status`, `na`, `k`, `bun`, `cr`, `alt`, `ast`, `wbc`, `plt`, `hb`, `bs`, `out`, `res1`, `res2`, `res3`, `res4`, `res5`, `res6`) VALUES
(1, 11, 1, '400', '650', '450', '700', '500', '750', '550', '800', '600', '850', '900', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 11, 1, '400', '650', '450', '700', '500', '750', '550', '800', '600', '850', '900', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 11, 1, '400', '650', '450', '700', '500', '750', '550', '800', '600', '850', '900', NULL, NULL, NULL, NULL, NULL, NULL),
(4, 11, 1, '400', '650', '450', '700', '500', '750', '550', '800', '600', '850', '900', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 8, 1, '40', '90', '50', '100', '60', '110', '70', '120', '80', '130', '140', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 8, 1, '40', '90', '50', '100', '60', '110', '70', '120', '80', '130', '140', NULL, NULL, NULL, NULL, NULL, NULL),
(7, 8, 1, '40', '90', '50', '100', '60', '110', '70', '120', '80', '130', '140', NULL, NULL, NULL, NULL, NULL, NULL),
(8, 8, 1, '40', '90', '50', '100', '60', '110', '70', '120', '80', '130', '140', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 6, 1, '500', '1000', '600', '1100', '700', '1200', '800', '1300', '900', '1400', '1500', NULL, NULL, NULL, NULL, NULL, NULL),
(10, 6, 1, '500', '1000', '600', '1100', '700', '1200', '800', '1300', '900', '1400', '1500', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '800', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '800', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '800', NULL, NULL, NULL, NULL, NULL, NULL),
(14, 16, 1, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL),
(15, 16, 1, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL),
(16, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '800', NULL, NULL, NULL, NULL, NULL, NULL),
(17, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '800', NULL, NULL, NULL, NULL, NULL, NULL),
(18, 17, 1, '700', '300', '800', '400', '900', '500', '100', '600', '200', '700', '850', NULL, NULL, NULL, NULL, NULL, NULL),
(19, 21, 1, '8', '9', '10', '11', '12', '13', '15', '16', '14', '17', '4', NULL, NULL, NULL, NULL, NULL, NULL),
(20, 23, 1, '8', '9', '10', '11', '12', '13', '15', '16', '14', '17', '4', NULL, NULL, NULL, NULL, NULL, NULL),
(21, 25, 1, '8', '9', '10', '11', '12', '13', '15', '16', '14', '17', '4', NULL, NULL, NULL, NULL, NULL, NULL),
(22, 26, 1, '800', '900', '1000', '1100', '1200', '1300', '1500', '1600', '1400', '1700', '400', NULL, NULL, NULL, NULL, NULL, NULL),
(23, 27, 1, '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL),
(24, 28, 1, '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL),
(25, 29, 1, '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_tol`
--

CREATE TABLE IF NOT EXISTS `mhr_tol` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='type of list' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mhr_tol`
--

INSERT INTO `mhr_tol` (`id`, `name`, `status`, `res1`, `res2`) VALUES
(1, 'بیماران GCS3 مرگ مغزی شده', 1, NULL, NULL),
(2, 'بیماران GCS3 مرگ مغزی نشده', 1, NULL, NULL),
(3, 'بیماران GCS4,5', 1, NULL, NULL),
(4, 'بیماران نامناسب', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_tol_options`
--

CREATE TABLE IF NOT EXISTS `mhr_tol_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `parentID` int(11) NOT NULL,
  `color` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res2` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Type of list options' AUTO_INCREMENT=24 ;

--
-- Dumping data for table `mhr_tol_options`
--

INSERT INTO `mhr_tol_options` (`id`, `name`, `parentID`, `color`, `status`, `res1`, `res2`, `res3`) VALUES
(1, 'بیمار جدید', 0, '#ffffff', 1, 'black', NULL, NULL),
(2, 'درحال پیگیری', 0, '#00FFFF', 1, 'black', NULL, NULL),
(3, 'مرگ قلبی', 0, '#000000', 1, 'white', NULL, NULL),
(4, 'بهبود یافته', 0, '#8a00ff', 1, 'white', NULL, NULL),
(5, 'منتقل شده', 0, '#904801', 1, 'white', NULL, NULL),
(6, 'اهدا شده', 0, '#02D439', 1, 'white', NULL, NULL),
(7, 'درحال پیگیری', 0, '#F0FF00', 1, 'black', NULL, NULL),
(8, 'غیر قابل اهدا', 0, '#FF0000', 1, 'white', NULL, NULL),
(9, 'مرگ قلبی بعد از رضایت', 3, '#FF7F00', 1, 'white', NULL, NULL),
(10, 'مرگ قلبی قبل از رسیدن کوردیناتور', 3, '#808080', 1, 'white', NULL, NULL),
(11, 'مرگ قلبی قبل از شروع رضایت گیری', 3, '#808080', 1, 'white', NULL, NULL),
(12, 'مرگ قلبی به علت عدم رضایت', 3, '#000000', 1, 'white', NULL, NULL),
(13, 'مرگ قلبی در حین انتقال', 3, '#FF7F00', 1, 'white', NULL, NULL),
(14, 'مرگ قلبی در ICU واحد فراهم آوری', 3, '#FF7F00', 1, 'white', NULL, NULL),
(15, 'مرگ قلبی در اتاق عمل اهدای عضو', 3, '#FF7F00', 1, 'white', NULL, NULL),
(16, 'اتباع بیگانه بدون اقامت قانونی', 8, '#FF0000', 1, 'white', NULL, NULL),
(17, 'بدخیمی غیر قابل استفاده', 8, '#FF0000', 1, 'white', NULL, NULL),
(18, 'عفونت غیرقابل کنترل', 8, '#FF0000', 1, 'white', NULL, NULL),
(19, 'HCV', 8, '#FF0000', 1, 'white', NULL, NULL),
(20, 'HIV', 8, '#FF0000', 1, 'white', NULL, NULL),
(21, 'سن بالای 70 سال', 8, '#FF0000', 1, 'white', NULL, NULL),
(22, 'سایر موارد', 8, '#FF0000', 1, 'white', NULL, NULL),
(23, 'مرگ قلبی قبل از انتقال', 3, '#FF7F00', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhr_tol_to_options`
--

CREATE TABLE IF NOT EXISTS `mhr_tol_to_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tolID` int(11) NOT NULL,
  `tolOptionsID` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `res1` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='Relationship Chart type list Options table' AUTO_INCREMENT=44 ;

--
-- Dumping data for table `mhr_tol_to_options`
--

INSERT INTO `mhr_tol_to_options` (`id`, `tolID`, `tolOptionsID`, `status`, `res1`) VALUES
(43, 4, 8, 1, '2'),
(42, 3, 8, 1, NULL),
(41, 3, 5, 1, NULL),
(40, 3, 4, 1, NULL),
(39, 3, 3, 1, NULL),
(38, 3, 2, 1, '1'),
(37, 3, 1, 1, '2'),
(36, 2, 8, 1, NULL),
(35, 2, 5, 1, NULL),
(34, 2, 4, 1, NULL),
(33, 2, 3, 1, NULL),
(32, 2, 2, 1, '1'),
(31, 2, 1, 1, '2'),
(30, 1, 9, 1, NULL),
(29, 1, 8, 1, NULL),
(28, 1, 6, 1, NULL),
(27, 1, 5, 1, NULL),
(26, 1, 3, 1, NULL),
(25, 1, 7, 1, '1'),
(24, 1, 1, 1, '2');

-- --------------------------------------------------------

--
-- Table structure for table `mhr_user_log`
--

CREATE TABLE IF NOT EXISTS `mhr_user_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uId` varchar(256) COLLATE utf8_persian_ci NOT NULL,
  `time` bigint(20) NOT NULL,
  `ip` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `role` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  `res1` int(11) DEFAULT NULL,
  `res2` int(11) DEFAULT NULL,
  `res3` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `res4` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uId`,`role`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='user login info log' AUTO_INCREMENT=179 ;

--
-- Dumping data for table `mhr_user_log`
--

INSERT INTO `mhr_user_log` (`id`, `uId`, `time`, `ip`, `role`, `status`, `res1`, `res2`, `res3`, `res4`) VALUES
(171, '1', 1422856750, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(173, '1', 1422857019, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(178, 'mr.mhrezaei@gmail.com', 1431635123, '::1', 'ADMIN', 1, NULL, NULL, NULL, NULL),
(41, '13', 1419972745, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(168, '1', 1422856458, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(167, '1', 1422855918, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(157, '1', 1422854290, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(147, '3', 1422450598, '::1', 'OPU', 1, NULL, NULL, NULL, NULL),
(170, '1', 1422856725, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(169, '1', 1422856690, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(163, '1', 1422855611, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(164, '1', 1422855664, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(165, '1', 1422855734, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(166, '1', 1422855789, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(160, '1', 1422855253, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(161, '1', 1422855287, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(162, '1', 1422855510, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(135, '3', 1421912777, '::1', 'OPU', 1, NULL, NULL, NULL, NULL),
(150, '3', 1422454737, '127.0.0.1', 'OPU', 1, NULL, NULL, NULL, NULL),
(151, '1', 1422461032, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(159, '1', 1422854899, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(149, '3', 1422454719, '127.0.0.1', 'OPU', 1, NULL, NULL, NULL, NULL),
(158, '1', 1422854689, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(148, '1', 1422454421, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(154, '1', 1422694026, '::1', 'INSPECTOR', 1, NULL, NULL, NULL, NULL),
(177, 'mr.mhrezaei@gmail.com', 1431632695, '::1', 'ADMIN', 1, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
