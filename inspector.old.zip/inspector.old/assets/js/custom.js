// base url find for use in ajax
function base_url(ext)
{
    var url     = window.location.href,
        base    = url.substring(0, url.indexOf('/', 14)),
        //ret_url = base + "/inspector/";
        ret_url = base + "/";
 
    if(ext !== undefined && ext !== '') {
        ret_url += ext;
    }
 
    return ret_url;
}

// national code verify
function nationalCodeVerify(code)
{
  
  if(code.length == 10 && !isNaN(code))
    {
        var code = code.split("");
        var err ;
        for(var i = 0; i < code.length; i++)
        {
            if(code[0] > code[i] || code[0] < code[i])
            {
                err = 1;
                break;
            }
            else
            {
                err = 2;
            }
        }
        
        if(err == 1)
        {
            var valid = 0;
            var jumper = 10;
            for(var i = 0; i <= 8; i++)
            {
                valid += code[i] * jumper;
                --jumper;
            }
            valid = valid % 11;
            if(valid >= 0 && valid < 2)
            {
                if(valid == code['9'])
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                valid = 11 - valid;
                if(valid == code['9'])
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

// load state from data base and insert in select input
function insertState(el, sel)
{
    var j = 1;
    if(j > 0)
    {
        $.ajax({
        type: "POST",
        url: base_url() + "ajax/ajax_conf/load_states",
        cache: false,
        data: {stateID: NaN, isSelected: sel}
        }).done(function(Data){
            $('#' + el).html(Data);
        });
        j--;
    }
}

// load city from database with state id and insert in select input
function insertcity(el, sta, sel)
{
    if(sta > 0)
    {
        var st = sta;
    }
    else
    {
        var st = $('#' + sta).val();
    }
    if(st > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            type: "POST",
            url: base_url() + "ajax/ajax_conf/load_states",
            cache: false,
            data: {stateID: st, isSelected: sel}
            }).done(function(Data){
                $('#' + el).html(Data);
                $('#' + el).removeAttr('disabled', 'disabled');
            });
            j--;
        }
    }
    else
    {
        $('#' + el).html('<option value="0">انتخاب کنید...</option>');
        $('#' + el).attr('disabled', 'disabled');
    }
}

// load opu from database and insert in select input
function insertOpu(el, sel)
{
    var j = 1;
    if(j > 0)
    {
        $.ajax({
        type: "POST",
        url: base_url() + "ajax/ajax_conf/load_opu",
        cache: false,
        data: {isSelected: sel}
        }).done(function(Data){
            $('#' + el).html(Data);
            $('#' + el).removeAttr('disabled', 'disabled');
        });
        j--;
    }
}

// load hospitals from database with opu id
function insertHospital(el, sta, sel, searchBy)
{
    if(sta > 0)
    {
        var st = sta;
    }
    else
    {
        var st = $('#' + sta).val();
    }
    if(st > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            type: "POST",
            url: base_url() + "ajax/ajax_conf/load_hospital",
            cache: false,
            data: {stateID: st, isSelected: sel, where: searchBy}
            }).done(function(Data){
                $('#' + el).html(Data);
                $('#' + el).removeAttr('disabled', 'disabled');
            });
            j--;
        }
    }
    else
    {
        $('#' + el).html('<option value="0">انتخاب کنید...</option>');
        $('#' + el).attr('disabled', 'disabled');
    }
}

// load inspectors from database with opu id
function insertInspectors(el, sta, sel)
{
    if(sta > 0)
    {
        var st = sta;
    }
    else
    {
        var st = $('#' + sta).val();
    }
    if(st > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            type: "POST",
            url: base_url() + "ajax/ajax_conf/load_inspectors",
            cache: false,
            data: {opuID: st, isSelected: sel}
            }).done(function(Data){
                $('#' + el).html(Data);
                $('#' + el).removeAttr('disabled', 'disabled');
            });
            j--;
        }
    }
    else
    {
        $('#' + el).html('<option value="0">انتخاب کنید...</option>');
        $('#' + el).attr('disabled', 'disabled');
    }
}

// load doc from database and insert into select
function insertDoc(el, sel)
{
    var j = 1;
    if(j > 0)
    {
        $.ajax({
        type: "POST",
        url: base_url() + "ajax/ajax_conf/load_doc",
        cache: false,
        data: {stateID: NaN, isSelected: sel}
        }).done(function(Data){
            $('#' + el).html(Data);
            $('#' + el).removeAttr('disabled', 'disabled');
        });
        j--;
    }
}

// load doc option from database with tol id
function insertDocOption(el, sta, sel, type)
{
    if(sta > 0 || sta == '-1')
    {
        var st = sta;
    }
    else
    {
        var st = $('#' + sta).val();
    }
    if(st > 0 || sta == '-1')
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            type: "POST",
            url: base_url() + "ajax/ajax_conf/load_tol_option",
            cache: false,
            data: {stateID: st, isSelected: sel, searchType: type}
            }).done(function(Data){
                $('#' + el).html(Data);
                $('#' + el).removeAttr('disabled', 'disabled');
            });
            j--;
        }
    }
    else
    {
        $('#' + el).html('<option value="0">انتخاب کنید...</option>');
        $('#' + el).attr('disabled', 'disabled');
    }
}

// add a new opu to database
function registerNewOPU()
{
    var opu = $('#inputOpuName').val();
    var head = $('#inputHeadOffice').val();
    var mobile = $('#inputMobile').val();
    var telephone = $('#inputTelephone').val();
    var user = $('#inputUserName').val();
    var pass = $('#inputPassword').val();
    var state = $('#cbState').val();
    var city = $('#cbCity').val();
    $('#successAlert1').hide();
    $('#dangerAlert1').hide();
    $('#dangerAlert2').hide();
    $('#dangerAlert3').hide();
    $('#dangerAlert4').hide();
    $('#addOpuModalLoading').hide();
    if(opu.length > 5 && head.length > 5 && mobile.length == 11 && telephone.length == 11 && user.length > 2 && pass.length > 5 && state > 0 && city > 0)
    {
        $('#saveBTN').attr('disabled', 'disabled');
        $('#addOpuModalLoading').show();
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            type: "POST",
            url: base_url() + "ajax/ajax_conf/insert_opu",
            cache: false,
            data: {opuName: opu, headOffice: head, mob: mobile, tel: telephone, username: user, password: pass, stateId: state, cityId: city}
            }).done(function(Data){
                $('#saveBTN').removeAttr('disabled', 'disabled');
                $('#addOpuModalLoading').hide();
                if(Data == 1)
                {
                    $('#successAlert1').show();
                    setTimeout(function(){
                       window.location.reload(1);
                    }, 5000);
                }
                else if(Data == 2)
                {
                    $('#dangerAlert1').show();
                }
                else if(Data == 3)
                {
                    $('#dangerAlert2').show();
                }
                else if(Data == 4)
                {
                    $('#dangerAlert3').show();
                }
                else if(Data == 5)
                {
                    $('#dangerAlert4').show();
                }
            });
            j--;
        }
    }
    else
    {
        $('#dangerAlert3').show();
    }
}

// edit a opu from database
function editOPU(id)
{
    $('#editOpuForm').hide();
    $('#OpuEditModalLoading').show();
    $('#saveBTNEdit').attr('disabled', 'disabled');
    $('#successAlertEdit1').hide();
    $('#dangerAlertEdit1').hide();
    $('#dangerAlertEdit2').hide();
    $('#dangerAlertEdit3').hide();
    $('#dangerAlertEdit4').hide();
    $('#warningAlert1').hide();
    
    $('#inputEditOpuName').val('');
    $('#inputEditHeadOffice').val('');
    $('#inputEditMobile').val('');
    $('#inputEditTelephone').val('');
    $('#inputEditUserName').val('');
    $('#cbEditState').html('');
    $('#cbEditState').html('');
    if(id > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            dataType: "json",
            type: "POST",
            url: base_url() + "ajax/ajax_conf/select_one_opu",
            cache: false,
            data: {opuID: id}
            }).done(function(Data){
                // result
                insertState('cbEditState', Data.state);
                insertcity('cbEditCity', Data.state, Data.city);
                $('#inputEditOpuName').val(Data.name);
                $('#inputEditHeadOffice').val(Data.headOffice);
                $('#inputEditMobile').val(Data.mobile);
                $('#inputEditTelephone').val(Data.telephone);
                $('#inputEditUserName').val(Data.username);
                $('#cbEditCity').val(Data.city);
                $('#OpuEditModalLoading').hide();
                $('#editOpuForm').show();
                $('#saveBTNEdit').removeAttr('disabled', 'disabled');
                $('#warningAlert1').show();
            }).fail(function(){
                $('#dangerAlertEdit1').show();
                $('#OpuEditModalLoading').hide();
            });
            j--;
        }
        $('#saveBTNEdit').unbind('click').bind('click', function(){
            var opu = $('#inputEditOpuName').val();
            var head = $('#inputEditHeadOffice').val();
            var mobile = $('#inputEditMobile').val();
            var telephone = $('#inputEditTelephone').val();
            var pass = $('#inputEditPassword').val();
            var state = $('#cbEditState').val();
            var city = $('#cbEditCity').val();
            $('#warningAlert1').hide();
            if(opu.length > 5 && head.length > 5 && mobile.length == 11 && telephone.length == 11 && state > 0 && city > 0)
            {
                if(pass.length > 0 && pass.length > 5)
                {
                    pass = pass;
                }
                else
                {
                    pass = 'notAffected';
                }
                $('#saveBTNEdit').attr('disabled', 'disabled');
                $('#OpuEditModalLoading').show();
                var l = 1;
                if(l > 0)
                {
                    $.ajax({
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/edit_one_opu",
                    cache: false,
                    data: {opuName: opu, headOffice: head, mob: mobile, tel: telephone, password: pass, stateId: state, cityId: city, opuId: id}
                    }).done(function(Data){
                        $('#saveBTNEdit').removeAttr('disabled', 'disabled');
                        $('#OpuEditModalLoading').hide();
                        if(Data == 1)
                        {
                            $('#successAlertEdit1').show();
                            setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                        }
                        else if(Data == 2)
                        {
                            $('#dangerAlertEdit2').show();
                        }
                        else if(Data == 3)
                        {
                            $('#dangerAlertEdit1').show();
                        }
                        else if(Data == 4)
                        {
                            $('#dangerAlertEdit3').show();
                        }
                        else if(Data == 5)
                        {
                            $('#dangerAlertEdit4').show();
                        }
                    });
                    l--;
                }
            }
        });
    }
}

// add new hospital
function addNewHospital()
{
    insertState('cbAddState', false);
    insertOpu('cbAddOpu', false);
    insertcity('cbAddCity', -1, false);
    $('#addHospitalModalLoading').hide();
    $('#successAlert1').hide();
    $('#dangerAlert1').hide();
    $('#dangerAlert3').hide();
    $('#dangerAlert4').hide();
    $('#saveBTN').removeAttr('disabled', 'disabled');
    $('#saveBTN').unbind('click').bind('click', function(){
        var opu = $('#cbAddOpu').val();
        var name = $('#inputHopitalName').val();
        var state = $('#cbAddState').val();
        var city = $('#cbAddCity').val();
        if(name.length > 1 && opu > 0 && state > 0 && city > 0)
        {
            $('#saveBTN').attr('disabled', 'disabled');
            $('#addHospitalModalLoading').show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/add_new_hospital",
                cache: false,
                data: {hrName: name, opuId: opu, stateId: state, cityId: city}
                }).done(function(Data){
                    $('#saveBTN').removeAttr('disabled', 'disabled');
                    $('#addHospitalModalLoading').hide();
                    if(Data == 1)
                    {
                        $('#successAlert1').show();
                        setTimeout(function(){
                           window.location.reload(1);
                        }, 1000);
                    }
                    else if(Data == 2)
                    {
                        $('#dangerAlert1').show();
                    }
                    else if(Data == 3)
                    {
                        $('#dangerAlert3').show();
                    }
                    else if(Data == 4)
                    {
                        $('#dangerAlert4').show();
                    }
                });
                j--;
            }
        }
        else
        {
            $('#dangerAlert3').show();
        }
    });
}

// edit a hospital from database
function editHospital(id)
{
    $('#editHospitalForm').hide();
    $('#editHospitalModalLoading').show();
    $('#saveBTNEdit').attr('disabled', 'disabled');
    $('#successAlertEdit1').hide();
    $('#dangerAlertEdit1').hide();
    $('#dangerAlertEdit2').hide();
    $('#dangerAlertEdit4').hide();
    $('#dangerAlertEdit3').hide();
    $('#warningAlert1').hide();
    
    $('#inputHopitalNameEdit').val('');
    $('#cbAddOpuEdit').html('<option value="0">انتخاب کنید...</option>');
    $('#cbAddStateEdit').html('<option value="0">انتخاب کنید...</option>');
    $('#cbAddCityEdit').html('<option value="0">انتخاب کنید...</option>');
    if(id > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            dataType: "json",
            type: "POST",
            url: base_url() + "ajax/ajax_conf/select_one_hospital",
            cache: false,
            data: {hosID: id}
            }).done(function(Data){
                // result
                insertState('cbAddStateEdit', Data.state);
                insertcity('cbAddCityEdit', Data.state, Data.city);
                insertOpu('cbAddOpuEdit', Data.opuId);
                $('#inputHopitalNameEdit').val(Data.name);
                $('#editHospitalModalLoading').hide();
                $('#editHospitalForm').show();
                $('#saveBTNEdit').removeAttr('disabled', 'disabled');
                $('#warningAlert1').show();
            }).fail(function(){
                $('#dangerAlertEdit1').show();
                $('#editHospitalModalLoading').hide();
            });
            j--;
        }
        $('#saveBTNEdit').unbind('click').bind('click', function(){
            var name = $('#inputHopitalNameEdit').val();
            var opu = $('#cbAddOpuEdit').val();
            var state = $('#cbAddStateEdit').val();
            var city = $('#cbAddCityEdit').val();
            $('#warningAlert1').hide();
            if(name.length > 2 && opu > 0 && state > 0 && city > 0)
            {
                $('#saveBTNEdit').attr('disabled', 'disabled');
                $('#editHospitalModalLoading').show();
                var l = 1;
                if(l > 0)
                {
                    $.ajax({
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/edit_one_hospital",
                    cache: false,
                    data: {hosName: name, opuId: opu, stateId: state, cityId: city, hosId: id}
                    }).done(function(Data){
                        $('#saveBTNEdit').removeAttr('disabled', 'disabled');
                        $('#editHospitalModalLoading').hide();
                        if(Data == 1)
                        {
                            $('#successAlertEdit1').show();
                            setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                        }
                        else if(Data == 2)
                        {
                            $('#dangerAlertEdit2').show();
                        }
                        else if(Data == 3)
                        {
                            $('#dangerAlertEdit1').show();
                        }
                        else if(Data == 4)
                        {
                            $('#dangerAlertEdit3').show();
                        }
                        else if(Data == 5)
                        {
                            $('#dangerAlertEdit4').show();
                        }
                    });
                    l--;
                }
            }
            else
            {
                $('#editHospitalModalLoading').hide();
                $('#dangerAlertEdit3').show();
            }
        });
    }
}

// add new inspector
function addNewInspector()
{
    insertOpu('cbInpectorOpu', false);
    $('#addInspectorModalLoading').hide();
    $('#successAlert1').hide();
    $('#dangerAlert1').hide();
    $('#dangerAlert3').hide();
    $('#dangerAlert4').hide();
    $('#saveBTN').removeAttr('disabled', 'disabled');
    $('#saveBTN').unbind('click').bind('click', function(){
        var opu = $('#cbInpectorOpu').val();
        var name = $('#inputInspectorName').val();
        var nationalCode = $('#inputInspectorNationalCode').val();
        var mobile = $('#inputInspectorMobile').val();
        var password = $('#inputInspectorPassword').val();
        var type1 = $('#chInspectorType1').is(':checked');
        var type2 = $('#chInspectorType2').is(':checked');
        if(name.length > 5 && opu > 0 && nationalCode.length == 10 && mobile.length == 11 && password.length > 5 && (type1 || type2) && nationalCodeVerify(nationalCode))
        {
            if(type1 && type2)
            {
                inspectorType = 3;
            }
            else if(type1)
            {
                inspectorType = 1;
            }
            else if(type2)
            {
                inspectorType = 2;
            }
            $('#saveBTN').attr('disabled', 'disabled');
            $('#addHospitalModalLoading').show();
            $('#dangerAlert3').hide();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/add_new_inspector",
                cache: false,
                data: {insName: name, opuId: opu, insNationalCode: nationalCode, insMobile: mobile, insPassword: password, insType: inspectorType}
                }).done(function(Data){
                    $('#saveBTN').removeAttr('disabled', 'disabled');
                    $('#addInspectorModalLoading').hide();
                    if(Data == 1)
                    {
                        $('#successAlert1').show();
                        setTimeout(function(){
                           window.location.reload(1);
                        }, 5000);
                    }
                    else if(Data == 2)
                    {
                        $('#dangerAlert1').show();
                    }
                    else if(Data == 3)
                    {
                        $('#dangerAlert3').show();
                    }
                    else if(Data == 4)
                    {
                        $('#dangerAlert4').show();
                    }
                });
                j--;
            }
        }
        else
        {
            $('#dangerAlert3').show();
        }
    });
}

// edit a inspector from database
function editInspector(id)
{
    $('#editInspectorModalForm').hide();
    $('#editInspectorModalLoading').show();
    $('#saveBTNEdit').attr('disabled', 'disabled');
    $('#successAlertEdit1').hide();
    $('#dangerAlertEdit1').hide();
    $('#dangerAlertEdit2').hide();
    $('#dangerAlertEdit4').hide();
    $('#dangerAlertEdit3').hide();
    
    $('#inputEditInspectorName').val('');
    $('#inputEditInspectorNationalCode').val('');
    $('#inputEditInspectorMobile').val('');
    $('#inputEditInspectorPassword').val('');
    $("#chEditInspectorType1").attr("checked", false);
    $("#chEditInspectorType2").attr("checked", false);
    $('#cbEditInpectorOpu').html('<option value="0">انتخاب کنید...</option>');
    if(id > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            dataType: "json",
            type: "POST",
            url: base_url() + "ajax/ajax_conf/select_one_inspector",
            cache: false,
            data: {insID: id}
            }).done(function(Data){
                // result
                insertOpu('cbEditInpectorOpu', Data.opuId);
                $('#inputEditInspectorName').val(Data.name);
                $('#inputEditInspectorNationalCode').val(Data.nationalCode);
                $('#inputEditInspectorMobile').val(Data.mobile);
                if(Data.type == 1)
                {
                    $("#chEditInspectorType1").click();
                }
                else if(Data.type == 2)
                {
                    $("#chEditInspectorType2").click();
                }
                else if(Data.type == 3)
                {
                    $("#chEditInspectorType1").click();
                    $("#chEditInspectorType2").click();
                }
                $('#editInspectorModalLoading').hide();
                $('#editInspectorModalForm').show();
                $('#saveBTNEdit').removeAttr('disabled', 'disabled');
            }).fail(function(){
                $('#dangerAlertEdit1').show();
                $('#editInspectorModalLoading').hide();
            });
            j--;
        }
        $('#saveBTNEdit').unbind('click').bind('click', function(){
            var opu = $('#cbEditInpectorOpu').val();
            var name = $('#inputEditInspectorName').val();
            var nationalCode = $('#inputEditInspectorNationalCode').val();
            var mobile = $('#inputEditInspectorMobile').val();
            var password = $('#inputEditInspectorPassword').val();
            var type1 = $('#chEditInspectorType1').is(':checked');
            var type2 = $('#chEditInspectorType2').is(':checked');
        if(name.length > 5 && opu > 0 && nationalCode.length == 10 && mobile.length == 11 && (type1 || type2) && nationalCodeVerify(nationalCode))
        {
            if(type1 && type2)
            {
                inspectorType = 3;
            }
            else if(type1)
            {
                inspectorType = 1;
            }
            else if(type2)
            {
                inspectorType = 2;
            }
            if(password.length > 5)
            {
                password = password;
            }
            else
            {
                password = 'passwordNotAffected';
            }
            $('#saveBTNEdit').attr('disabled', 'disabled');
            $('#editInspectorModalLoading').show();
            $('#dangerAlertEdit3').hide();
            $('#dangerAlertEdit2').hide();
                var l = 1;
                if(l > 0)
                {
                    $.ajax({
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/edit_one_inspector",
                    cache: false,
                    data: {insName: name, opuId: opu, insNationalCode: nationalCode, insMobile: mobile, insPassword: password, insType: inspectorType, insID: id}
                    }).done(function(Data){
                        $('#saveBTNEdit').removeAttr('disabled', 'disabled');
                        $('#editInspectorModalLoading').hide();
                        if(Data == 1)
                        {
                            $('#successAlertEdit1').show();
                            setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                        }
                        else if(Data == 2)
                        {
                            $('#dangerAlertEdit2').show();
                        }
                        else if(Data == 3)
                        {
                            $('#dangerAlertEdit1').show();
                        }
                        else if(Data == 4)
                        {
                            $('#dangerAlertEdit3').show();
                        }
                        else if(Data == 5)
                        {
                            $('#dangerAlertEdit4').show();
                        }
                    });
                    l--;
                }
            }
            else
            {
                $('#editInspectorModalLoading').hide();
                $('#dangerAlertEdit3').show();
            }
        });
    }
}

// if select other in doc load detail
function changeDoc()
{
    var d = $('#cbDoc').val();
    if(d == 8)
    {
        $('#inputDocDetail').show();
    }
    else
    {
        $('#inputDocDetail').hide();
    }
}

// if select other in patient detail load detail
function changePatientStatus()
{
    var d = $('#cbPatientStatus').val();
    if(d == 22)
    {
        $('#inputPatientStatusDetail').show();
    }
    else
    {
        $('#inputPatientStatusDetail').hide();
    }
}

// add new patient
function addPatient()
{
    insertDoc('cbDoc', false);
    $('#cbDoc').on('change', function(){
        changeDoc();
    });
    insertOpu('cbOpu', false);
    $('#cbOpu').on('change', function(){
        insertHospital('cbHospitals', 'cbOpu', false, 'opuId');
    });
    $('#cbTol').on('change', function(){
        insertDocOption('cbPatientStatus', 'cbTol', false, false);
        if($('#cbTol').val() == 1)
        {
            $('#cbBreathing').val('N');
            $('#cbCornea').val('N');
            $('#cbFaceMove').val('N');
            $('#cbBodyMove').val('N');
            $('#cbDoll').val('N');
            $('#cbGag').val('N');
            $('#cbCough').val('N');
            $('#cbPupil').val('N');
            $('#GCS3Patients').show();
            $('#firstSedationQ').hide();
        }
        else
        {
            $('#cbBreathing').val('U');
            $('#cbCornea').val('U');
            $('#cbFaceMove').val('U');
            $('#cbBodyMove').val('U');
            $('#cbDoll').val('U');
            $('#cbGag').val('U');
            $('#cbCough').val('U');
            $('#cbPupil').val('U');
            $('#GCS3Patients').hide();
            $('#firstSedationQ').show();
        }
    });
    $('#chisUnknown').on('change', function(){
        if($('#chisUnknown').is(':checked'))
        {
            $('#inputFullName').attr('disabled', 'disabled');
            $('#inputNationalCode').attr('disabled', 'disabled');
            $('#inputAge').attr('disabled', 'disabled');
        }
        else
        {
            $('#inputFullName').removeAttr('disabled', 'disabled');
            $('#inputNationalCode').removeAttr('disabled', 'disabled');
            $('#inputAge').removeAttr('disabled', 'disabled');
        }
    });
    $('#inputFullName').on('blur', function(){
        var ptName = $('#inputFullName').val();
        $('#warningAlertName').hide();
        $.ajax({
            dataType: "json",    
            type: "POST",
                url: base_url() + "ajax/ajax_conf/found_patient_result",
                cache: false,
                data: {pName: ptName}
                }).done(function(Data){
                    if(Data.num_rows > 0)
                    {
                        var url = base_url() + Data.url + '/manage_patient?inputPatientFilter=' + ptName + '&searchTools=true';
                        $('#warningAlertName').html(Data.num_rows + ' عدد بیمار با نام وارد شده یافت شد، برای مشاهده بیماران ' + '<a target="_blank" href="' + url + '">اینجا</a>' + ' کلیک نمائید.');
                        $('#warningAlertName').show();
                    }
                    else
                    {
                        $('#warningAlertName').hide();
                    }
                });
    });
    $('#cbPatientStatus').on('change', function(){
        changePatientStatus();
    });
    
    $('#saveBTN').unbind('click').bind('click', function(){
        $('#dangerAlert').hide();
        var chisUnknown = $('#chisUnknown').is(':checked'); /////// is checked
        var inputFileNumber = $('#inputFileNumber').val();
        var inputFullName = $('#inputFullName').val();
        var inputNationalCode = $('#inputNationalCode').val();
        var inputAge = $('#inputAge').val();
        var cbBodyType = $('#cbBodyType').val();
        var cbDoc = $('#cbDoc').val();
        var inputDocDetail = $('#inputDocDetail').val();
        var inputFirstGCS = $('#inputFirstGCS').val();
        var cbOpu = $('#cbOpu').val();
        var cbPresentioan = $('#cbPresentioan').val();
        var cbHospitals = $('#cbHospitals').val();
        var cbSection = $('#cbSection').val();
        var inputTypeOfSection = $('#inputTypeOfSection').val();
        var cbBreathing = $('#cbBreathing').val();
        var inputBreathingDetail = $('#inputBreathingDetail').val();
        var cbSedation = $('#cbSedation').is(':checked'); /////// is checked
        var cbBodyMove = $('#cbBodyMove').val();
        var inputBodyMovementDetail = $('#inputBodyMovementDetail').val();
        var cbFaceMove = $('#cbFaceMove').val();
        var inputFaceMovementDetail = $('#inputFaceMovementDetail').val();
        var cbGag = $('#cbGag').val();
        var cbCough = $('#cbCough').val();
        var cbCornea = $('#cbCornea').val();
        var cbPupil = $('#cbPupil').val();
        var cbTol = $('#cbTol').val();
        var cbMin = $('#cbMin').val();
        var cbHour = $('#cbHour').val();
        var cbPatientStatus = $('#cbPatientStatus').val();
        var inputT = $('#inputT').val();
        var inputPR = $('#inputPR').val();
        var inputFIO2 = $('#inputFIO2').val();
        var inputOut = $('#inputOut').val();
        var inputBP = $('#inputBP').val();
        var inputRR = $('#inputRR').val();
        var inputO2SAT = $('#inputO2SAT').val();
        var cbSedation2 = $('#cbSedation2').val();
        var inputNa = $('#inputNa').val();
        var inputK = $('#inputK').val();
        var inputBUN = $('#inputBUN').val();
        var inputCr = $('#inputCr').val();
        var inputALT = $('#inputALT').val();
        var inputAST = $('#inputAST').val();
        var inputHb = $('#inputHb').val();
        var inputWBC = $('#inputWBC').val();
        var inputPLT = $('#inputPLT').val();
        var inputBs = $('#inputBs').val();
        if($('#rdAddDate1').is(':checked'))
        {
            var rdDate = 'toDay';
        }
        else if($('#rdAddDate2').is(':checked'))
        {
            var rdDate = 'lastDay';
        }
        else
        {
            var rdDate = false;
        }
        if(inputFileNumber.length > 0 && cbDoc > 0 && inputFirstGCS > 0 && cbOpu > 0 && cbPresentioan > 0 && cbHospitals > 0 && cbSection > 0 && cbTol > 0 && cbPatientStatus > 0 && cbMin != 'min' && cbHour != 'hour')
        {
            if($('#cbTol').val() == 999)
            {
                if(inputT.length > 0 && inputPR.length > 0 && inputFIO2.length > 0 && inputOut.length > 0 && inputBP.length > 0 && inputRR.length > 0 && inputO2SAT.length > 0 && inputNa.length > 0 && inputK.length > 0 && inputBUN.length > 0 && inputCr.length > 0 && inputALT.length > 0 && inputAST.length > 0 && inputHb.length > 0 && inputWBC.length > 0 && inputPLT.length > 0 && inputBs.length > 0)
                {
                    if(chisUnknown)
                    {
                        var cont = 1;
                    }
                    else
                    {
                        if(inputFullName.length > 5 && inputAge > 0)
                        {
                            var cont = 1;
                        }
                        else
                        {
                            var cont = 2;
                        }
                    }
                }
                else
                {
                    var cont = 2;
                }
            }
            else
            {
                if(chisUnknown)
                {
                    var cont = 1;
                }
                else
                {
                    if(inputFullName.length > 5 && inputAge > 0)
                    {
                        var cont = 1;
                    }
                    else
                    {
                        var cont = 2;
                    }
                }
            }
            
        }
        else
        {
            var cont = 2;
        }
        if(cont == 1)
        {
            document.addPatientForm.submit();
        }
        else
        {
            $('#dangerAlert').show();
        }
        
    });
    
}

// add new patient
function addPatientOI()
{
    insertDoc('cbDoc', false);
    $('#cbDoc').on('change', function(){
        changeDoc();
    });
    $('#cbTol').on('change', function(){
        insertDocOption('cbPatientStatus', 'cbTol', false, false);
        if($('#cbTol').val() == 1)
        {
            $('#cbBreathing').val('N');
            $('#cbCornea').val('N');
            $('#cbFaceMove').val('N');
            $('#cbBodyMove').val('N');
            $('#cbDoll').val('N');
            $('#cbGag').val('N');
            $('#cbCough').val('N');
            $('#cbPupil').val('N');
            $('#GCS3Patients').show();
            $('#firstSedationQ').hide();
        }
        else
        {
            $('#cbBreathing').val('U');
            $('#cbCornea').val('U');
            $('#cbFaceMove').val('U');
            $('#cbBodyMove').val('U');
            $('#cbDoll').val('U');
            $('#cbGag').val('U');
            $('#cbCough').val('U');
            $('#cbPupil').val('U');
            $('#GCS3Patients').hide();
            $('#firstSedationQ').show();
        }
    });
    $('#chisUnknown').on('change', function(){
        if($('#chisUnknown').is(':checked'))
        {
            $('#inputFullName').attr('disabled', 'disabled');
            $('#inputNationalCode').attr('disabled', 'disabled');
            $('#inputAge').attr('disabled', 'disabled');
        }
        else
        {
            $('#inputFullName').removeAttr('disabled', 'disabled');
            $('#inputNationalCode').removeAttr('disabled', 'disabled');
            $('#inputAge').removeAttr('disabled', 'disabled');
        }
    });
    $('#inputFullName').on('blur', function(){
        var ptName = $('#inputFullName').val();
        $('#warningAlertName').hide();
        $.ajax({
            dataType: "json",    
            type: "POST",
                url: base_url() + "ajax/ajax_conf/found_patient_result",
                cache: false,
                data: {pName: ptName}
                }).done(function(Data){
                    if(Data.num_rows > 0)
                    {
                        var url = base_url() + Data.url + '/manage_patient?inputPatientFilter=' + ptName + '&searchTools=true';
                        $('#warningAlertName').html(Data.num_rows + ' عدد بیمار با نام وارد شده یافت شد، برای مشاهده بیماران ' + '<a target="_blank" href="' + url + '">اینجا</a>' + ' کلیک نمائید.');
                        $('#warningAlertName').show();
                    }
                    else
                    {
                        $('#warningAlertName').hide();
                    }
                });
    });
    $('#cbPatientStatus').on('change', function(){
        changePatientStatus();
    });
    
    $('#saveBTN').unbind('click').bind('click', function(){
        $('#dangerAlert').hide();
        var chisUnknown = $('#chisUnknown').is(':checked'); /////// is checked
        var inputFileNumber = $('#inputFileNumber').val();
        var inputFullName = $('#inputFullName').val();
        var inputNationalCode = $('#inputNationalCode').val();
        var inputAge = $('#inputAge').val();
        var cbBodyType = $('#cbBodyType').val();
        var cbDoc = $('#cbDoc').val();
        var inputDocDetail = $('#inputDocDetail').val();
        var inputFirstGCS = $('#inputFirstGCS').val();
        var cbPresentioan = $('#cbPresentioan').val();
        var cbHospitals = $('#cbHospitals').val();
        var cbSection = $('#cbSection').val();
        var inputTypeOfSection = $('#inputTypeOfSection').val();
        var cbBreathing = $('#cbBreathing').val();
        var inputBreathingDetail = $('#inputBreathingDetail').val();
        var cbSedation = $('#cbSedation').is(':checked'); /////// is checked
        var cbBodyMove = $('#cbBodyMove').val();
        var inputBodyMovementDetail = $('#inputBodyMovementDetail').val();
        var cbFaceMove = $('#cbFaceMove').val();
        var inputFaceMovementDetail = $('#inputFaceMovementDetail').val();
        var cbGag = $('#cbGag').val();
        var cbCough = $('#cbCough').val();
        var cbCornea = $('#cbCornea').val();
        var cbPupil = $('#cbPupil').val();
        var cbTol = $('#cbTol').val();
        var cbMin = $('#cbMin').val();
        var cbHour = $('#cbHour').val();
        var cbPatientStatus = $('#cbPatientStatus').val();
        var inputT = $('#inputT').val();
        var inputPR = $('#inputPR').val();
        var inputFIO2 = $('#inputFIO2').val();
        var inputOut = $('#inputOut').val();
        var inputBP = $('#inputBP').val();
        var inputRR = $('#inputRR').val();
        var inputO2SAT = $('#inputO2SAT').val();
        var cbSedation2 = $('#cbSedation2').val();
        var inputNa = $('#inputNa').val();
        var inputK = $('#inputK').val();
        var inputBUN = $('#inputBUN').val();
        var inputCr = $('#inputCr').val();
        var inputALT = $('#inputALT').val();
        var inputAST = $('#inputAST').val();
        var inputHb = $('#inputHb').val();
        var inputWBC = $('#inputWBC').val();
        var inputPLT = $('#inputPLT').val();
        var inputBs = $('#inputBs').val();
        if($('#rdAddDate1').is(':checked'))
        {
            var rdDate = 'toDay';
        }
        else if($('#rdAddDate2').is(':checked'))
        {
            var rdDate = 'lastDay';
        }
        else
        {
            var rdDate = false;
        }
        if(inputFileNumber.length > 0 && cbDoc > 0 && inputFirstGCS > 0 && cbPresentioan > 0 && cbHospitals > 0 && cbSection > 0 && cbTol > 0 && cbPatientStatus > 0 && cbMin != 'min' && cbHour != 'hour')
        { 
            if($('#cbTol').val() == 999)
            {
                if(inputT.length > 0 && inputPR.length > 0 && inputFIO2.length > 0 && inputOut.length > 0 && inputBP.length > 0 && inputRR.length > 0 && inputO2SAT.length > 0 && inputNa.length > 0 && inputK.length > 0 && inputBUN.length > 0 && inputCr.length > 0 && inputALT.length > 0 && inputAST.length > 0 && inputHb.length > 0 && inputWBC.length > 0 && inputPLT.length > 0 && inputBs.length > 0)
                {
                    if(chisUnknown)
                    {
                        var cont = 1;
                    }
                    else
                    {
                        if(inputFullName.length > 5 && inputAge > 0)
                        {
                            var cont = 1;
                        }
                        else
                        {
                            var cont = 2;
                        }
                    }
                }
                else
                {
                    var cont = 2;
                }
            }
            else
            {
                if(chisUnknown)
                {
                    var cont = 1;
                }
                else
                {
                    if(inputFullName.length > 5 && inputAge > 0)
                    {
                        var cont = 1;
                    }
                    else
                    {
                        var cont = 2;
                    }
                }
            }
        }
        else
        {
            var cont = 2;
        }
        if(cont == 1)
        {
            document.addPatientForm.submit();
        }
        else
        {
            $('#dangerAlert').show();
        }
        
    });
    
}

// change user password
function changeUserPassword()
{
    var oldPassword = $('#inputLastPassword').val();
    var newPassword = $('#inputNewPassword').val();
    var newPassword2 = $('#inputNewPassword2').val();
    var danger1 = $('#danger1');
    var danger2 = $('#danger2');
    var danger3 = $('#danger3');
    danger1.hide();
    danger2.hide();
    danger3.hide();
    if(oldPassword.length > 5)
    {
        if(newPassword.length > 5)
        {
            if(newPassword == newPassword2)
            {
                document.changeUserPass.submit();
            }
            else
            {
                danger1.show();
            }
        }
        else
        {
            danger3.show();
        }
    }
    else
    {
        danger2.show();
    }
}

// active or inactive or delete inspector
function inactiveInspector(inspectorID, status)
{
    var name = $('#insName' + inspectorID).text();
    var saveBTN = $('#inactiveBTN');
    var inactiveDeleteBTN = $('#inactiveDeleteBTN');
    var saveLoading = $('#activeInspectorModalLoading');
    var divQes = $('#activeQuestion');
    var danger1 = $('#dangerAlertStatus1');
    var danger2 = $('#dangerAlertStatus2');
    var danger3 = $('#dangerAlertStatus3');
    saveBTN.removeAttr('disabled', 'disabled');
    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
    saveBTN.hide();
    inactiveDeleteBTN.hide();
    saveLoading.hide();
    danger1.hide();
    danger2.hide();
    danger3.hide();
    if(status == 'inactive')
    {
        var tx = 'آیا مایل به غیرفعال نمودن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    else if(status == 'active')
    {
        var tx = 'آیا مایل به فعال نمودن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    else if(status == 'delete')
    {
        var tx = 'آیا مایل به حذف کردن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    
    divQes.html(tx);
    divQes.show();
    
    if(status == 'delete')
    {
        saveBTN.hide();
        inactiveDeleteBTN.show();
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_inspector_status",
                cache: false,
                data: {insID: inspectorID, insStatus: status}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger1.show();
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
                j--;
            }
        });
    }
    else
    {
        saveBTN.show();
        inactiveDeleteBTN.hide();
        saveBTN.unbind('click').bind('click', function(){
            saveBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_inspector_status",
                cache: false,
                data: {insID: inspectorID, insStatus: status}
                }).done(function(Data){
                    saveBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger1.show();
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
        });
    }
}

// active or inactive or delete opu
function inactiveInspector(inspectorID, status)
{
    var name = $('#insName' + inspectorID).text();
    var saveBTN = $('#inactiveBTN');
    var inactiveDeleteBTN = $('#inactiveDeleteBTN');
    var saveLoading = $('#activeInspectorModalLoading');
    var divQes = $('#activeQuestion');
    var danger1 = $('#dangerAlertStatus1');
    var danger2 = $('#dangerAlertStatus2');
    var danger3 = $('#dangerAlertStatus3');
    saveBTN.removeAttr('disabled', 'disabled');
    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
    saveBTN.hide();
    inactiveDeleteBTN.hide();
    saveLoading.hide();
    danger1.hide();
    danger2.hide();
    danger3.hide();
    if(status == 'inactive')
    {
        var tx = 'آیا مایل به غیرفعال نمودن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    else if(status == 'active')
    {
        var tx = 'آیا مایل به فعال نمودن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    else if(status == 'delete')
    {
        var tx = 'آیا مایل به حذف کردن بازرس <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟';
    }
    
    divQes.html(tx);
    divQes.show();
    
    if(status == 'delete')
    {
        saveBTN.hide();
        inactiveDeleteBTN.show();
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_inspector_status",
                cache: false,
                data: {insID: inspectorID, insStatus: status}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger1.show();
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
                j--;
            }
        });
    }
    else
    {
        saveBTN.show();
        inactiveDeleteBTN.hide();
        saveBTN.unbind('click').bind('click', function(){
            saveBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            var l = 1;
            if(l > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_inspector_status",
                cache: false,
                data: {insID: inspectorID, insStatus: status}
                }).done(function(Data){
                    saveBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger1.show();
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
                l--;
            }
        });
    }
}

// active or inactive or delete opu
function inactiveOpu(opuID, status)
{
    var name = $('#opuName' + opuID).text();
    var saveBTN = $('#inactiveBTN');
    var inactiveDeleteBTN = $('#inactiveDeleteBTN');
    var saveLoading = $('#activeInspectorModalLoading');
    var divQes = $('#activeQuestion');
    var danger1 = $('#dangerAlertStatus1');
    var danger2 = $('#dangerAlertStatus2');
    var danger3 = $('#dangerAlertStatus3');
    saveBTN.removeAttr('disabled', 'disabled');
    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
    saveBTN.hide();
    inactiveDeleteBTN.hide();
    saveLoading.hide();
    danger1.hide();
    danger2.hide();
    danger3.hide();
    if(status == 'inactive')
    {
        var tx = 'آیا مایل به غیرفعال نمودن واحد فراهم آوری <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟ <br> توجه داشته باشید در صورت غیر فعال نمودن این واحد تمامی بازرسین ثبت شده در این واحد نیز غیر فعال می گردند.';
    }
    else if(status == 'active')
    {
        var tx = 'آیا مایل به فعال نمودن واحد فراهم آوری <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟ <br> توجه داشته باشید در صورت فعال نمودن این واحد فراهم آوری تمامی بازرسین آن نیز فعال می گردند.';
    }
    else if(status == 'delete')
    {
        var tx = 'آیا مایل به حذف کردن واحد فراهم آوری <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟ <br> توجه داشته باشید در صورت حذف کردن این واحد فراهم آوری تمامی بازرسین آن نیز حذف می کردند.';
    }
    
    divQes.html(tx);
    divQes.show();
    
    if(status == 'delete')
    {
        saveBTN.hide();
        inactiveDeleteBTN.show();
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            var j = 1;
            if( j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_opu_status",
                cache: false,
                data: {opuId: opuID, opuStatus: status}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 2)
                    {
                        danger1.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
                j--;
            }
        });
    }
    else
    {
        saveBTN.show();
        inactiveDeleteBTN.hide();
        saveBTN.unbind('click').bind('click', function(){
            saveBTN.attr('disabled', 'disabled');
            divQes.hide();
            saveLoading.show();
            var l = 1;
            if(l > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_opu_status",
                cache: false,
                data: {opuId: opuID, opuStatus: status}
                }).done(function(Data){
                    saveBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 2)
                    {
                        danger1.show();
                    }
                    else if(Data == 3)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                });
                l--;
            }
        });
    }
}

// delete state or city
function deleteStateOrCity(id)
{
    var load = $('#deleteStateModalLoading');
    var qoes = $('#deleteStateModalActiveQuestion');
    var danger1 = $('#deleteStateModalDanger1');
    var danger2 = $('#deleteStateModalDanger3');
    var btn = $('#deleteStateModalBTN');
    var name = $('#cityName' + id).text();
    var j = 1;
    load.hide();
    danger1.hide();
    danger2.hide();
    btn.removeAttr('disabled', 'disabled');
    var x = 'آیا مایل به حذف استان / شهر <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می باشید؟';
    qoes.html(x);
    
    if(id > 0 && j > 0)
    {
        btn.unbind('click').bind('click', function(){
            load.show();
            btn.attr('disabled', 'disabled');
            $.ajax({
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/delete_state_or_city",
                    cache: false,
                    data: {sID: id}
                    }).done(function(Data){
                        btn.removeAttr('disabled', 'disabled');
                        load.hide();
                        if(Data == 1)
                        {
                            danger2.show();
                            setTimeout(function(){
                                   window.location.reload(1);
                                }, 2500);
                        }
                        else if(Data == 2)
                        {
                            danger1.show();
                        }
                    });
            j--;
        });
    }
}

// change modal height in edit patient page
function changeHeightModal(id)
{
    he = $(window).height();
    heM = $('#' + id + ' .modal-content').height();
    if(heM > he)
    {
        $('#' + id + ' .modal-backdrop').height($('#' + id + ' .modal-content').height() + 100);
    }
    else
    {
        $('#' + id + ' .modal-backdrop').height(he + 50);
    }
}

// edit and modify patient
function editPatient(id)
{
    document.editPatientForms.reset();
    document.patientTransferForm.reset();
    var saveBTN = $('#saveBTN');
    var transferBTN = $('#transferBTN');
    var transferSaveBTN = $('#transferSaveBTN');
    var transferForm = $('#patientsTransfer');
    var GCS3Patients = $('#GCS3Patients');
    $('#inputFullName').removeAttr('disabled', 'disabled');
    $('#inputNationalCode').removeAttr('disabled', 'disabled');
    $('#inputAge').removeAttr('disabled', 'disabled');
    saveBTN.attr('disabled', 'disabled');
    var form = $('#editPatientFrom');
    var loading = $('#editPatientModalLoading');
    var chUn = $('#chisUnknown');
    var inputFileNumber = $('#inputFileNumber');
    var inputPT = $('#inputPT');
    var inputFullName = $('#inputFullName');
    var inputNationalCode = $('#inputNationalCode');
    var inputAge = $('#inputAge');
    var cbBodyType = $('#cbBodyType');
    var inputFirstGCS = $('#inputFirstGCS');
    var inputSecondGCS = $('#inputSecondGCS');
    var inputCoordinatorName = $('#inputCoordinatorName');
    var cbDoc = $('#cbDoc');
    var inputPatientDetail = $('#inputPatientDetail');
    var cbOpu = $('#cbOpuEdit');
    var cbHospitals = $('#cbHospitalsEdit');
    var cbSection = $('#cbSectionEdit');
    var inputTypeOfSection = $('#inputTypeOfSection');
    var cbPresentioan = $('#cbPresentioan');
    var cbBreathing = $('#cbBreathing');
    var inputBreathingDetail = $('#inputBreathingDetail');
    var cbCornea = $('#cbCornea');
    var cbPupil = $('#cbPupil');
    var cbFaceMove = $('#cbFaceMove');
    var inputFaceMovementDetail = $('#inputFaceMovementDetail');
    var cbBodyMove = $('#cbBodyMove');
    var inputBodyMovementDetail = $('#inputBodyMovementDetail');
    var cbDoll = $('#cbDoll');
    var cbGag = $('#cbGag');
    var cbCough = $('#cbCough');
    var cbSedation = $('#cbSedation');
    var cbTol = $('#cbTol');
    var cbPatientStatus = $('#cbPatientStatusEdit');
    var inputT = $('#inputT');
    var inputPR = $('#inputPR');
    var inputFIO2 = $('#inputFIO2');
    var inputBP = $('#inputBP');
    var inputRR = $('#inputRR');
    var inputO2SAT = $('#inputO2SAT');
    var cbSedation2 = $('#cbSedation2');
    var inputNa = $('#inputNa');
    var inputBUN = $('#inputBUN');
    var inputALT = $('#inputALT');
    var inputWBC = $('#inputWBC');
    var inputHb = $('#inputHb');
    var inputK = $('#inputK');
    var inputCr = $('#inputCr');
    var inputAST = $('#inputAST');
    var inputPLT = $('#inputPLT');
    var inputBs = $('#inputBs');
    var inputOut = $('#inputOut');
    var pcal1 = $('#pcal1'); // tarikh bastari
    var pcal2 = $('#pcal2'); // tarikh elame gcs3 tavasote pezeshke moalej
    var pcal3 = $('#pcal3'); // tarikhe shenasaee marge maghzi
    var pcal4 = $('#pcal4'); // tarikhe enteghal
    var pcal5 = $('#pcal5'); // tarikh ehda
    var pcal6 = $('#pcal6'); // tarkh marge ghalbi
    var cbTransferState = $('#cbTransferState');
    var cbTransferCity = $('#cbTransferCity');
    var cbTransferHospital = $('#cbTransferHospital');
    var dangerAlert = $('#dangerAlert');
    var successAlert = $('#successAlert');
    var chHeart = $('#chHeart');
    var chLiver = $('#chLiver');
    var chKidneyRight = $('#chKidneyRight');
    var chKidneyLeft = $('#chKidneyLeft');
    var chLungRight = $('#chLungRight');
    var chLungLeft = $('#chLungLeft');
    var chPancreas = $('#chPancreas');
    var chTissue = $('#chTissue');
    var chBowel = $('#chBowel');
    var appRegisterTime = $('#appRegisterTime');
    var Err = 0;
    transferBTN.show();
    saveBTN.show();
    transferForm.hide();
    transferSaveBTN.hide();
    form.hide();
    dangerAlert.hide();
    successAlert.hide();
    var exp = 1;
    if(id > 0)
    {
        var j = 1;
        if(j > 0)
        {
            $.ajax({
            dataType: "json",
            type: "POST",
            url: base_url() + "ajax/ajax_conf/load_one_patient",
            cache: false,
            data: {pID: id}
            }).done(function(Data){
                // result
                if(Data.isUnKnown == 1)
                {
                    chUn.click();
                }
                else
                {
                    inputFullName.val(Data.fullName);
                    inputNationalCode.val(Data.nationalCode);
                    inputAge.val(Data.age);
                }
                inputFileNumber.val(Data.fileNumber)
                cbBodyType.val(Data.bodyType);
                inputFirstGCS.val(Data.firstGCS);
                inputSecondGCS.val(Data.secondGCS);
                inputCoordinatorName.val(Data.coordinatorName);
                insertDoc('cbDoc', Data.doc);
                if(Data.doc == 8)
                {
                    $('#inputDocDetail').val(Data.docDetail);
                    $('#inputDocDetail').show();
                }
                else
                {
                    $('#inputDocDetail').hide();
                }
                inputPatientDetail.val(Data.patientDetail);
                insertOpu('cbOpuEdit', Data.opuId);
                insertHospital('cbHospitalsEdit', Data.opuId, Data.hospital, 'opuId');
                cbSection.val(Data.section);
                inputTypeOfSection.val(Data.typeOfSection);
                cbPresentioan.val(Data.presentation);
                cbBreathing.val(Data.breathing);
                inputBreathingDetail.val(Data.breathingDetail);
                cbCornea.val(Data.cornea);
                cbPupil.val(Data.pupil);
                cbFaceMove.val(Data.faceMovement);
                inputFaceMovementDetail.val(Data.faceMovementDetail);
                cbBodyMove.val(Data.bodyMovement);
                inputBodyMovementDetail.val(Data.bodyMovementDetail);
                cbDoll.val(Data.dollEye);
                cbGag.val(Data.gag);
                cbCough.val(Data.cough);
                inputPT.val(id);
                if(Data.sedation == 'Yes')
                {
                    cbSedation.click();
                }
                cbTol.val(Data.tol);
                insertDocOption('cbPatientStatusEdit', Data.tol, Data.patientStatus, 'ALL');
                if(Data.patientStatus == 22)
                {
                    $('#inputPatientStatusDetail').val(Data.patientStatusDetail);
                    $('#inputPatientStatusDetail').show();
                }
                else
                {
                    $('#inputPatientStatusDetail').hide();
                }
                if(Data.tol == 1)
                {
                    // patient is GCS3 brain death
                    $.ajax({
                    dataType: "json",
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/load_one_patient_extra_data",
                    cache: false,
                    data: {pID: id}
                    }).done(function(p){
                        // result
                        if(p.isCondition == 1)
                        {
                            inputT.val(p.condition.t);
                            inputPR.val(p.condition.pr);
                            inputFIO2.val(p.condition.fio2);
                            inputBP.val(p.condition.bp);
                            inputRR.val(p.condition.rr);
                            inputO2SAT.val(p.condition.o2sat);
                            inputOut.val(p.condition.out);
                            if(p.condition.sedation == 'Yes')
                            {
                                cbSedation.click();
                                cbSedation2.click();
                            }
                        }
                        if(p.isTest == 1)
                        {
                            inputNa.val(p.test.na);
                            inputBUN.val(p.test.bun);
                            inputALT.val(p.test.alt);
                            inputWBC.val(p.test.wbc);
                            inputHb.val(p.test.hb);
                            inputK.val(p.test.k);
                            inputCr.val(p.test.cr);
                            inputAST.val(p.test.ast);
                            inputPLT.val(p.test.plt);
                            inputBs.val(p.test.bs);
                        }
                        if(p.isOrgan == 1)
                        {
                            if(p.organ.heart == 1)
                            {
                                 chHeart.click();
                            }
                            if(p.organ.liver == 1)
                            {
                                chLiver.click();
                            }
                            if(p.organ.kidneyRight == 1)
                            {
                                chKidneyRight.click();
                            }
                            if(p.organ.kidneyLeft == 1)
                            {
                                chKidneyLeft.click();
                            }
                            if(p.organ.lungRight == 1)
                            {
                                chLungRight.click();
                            }
                            if(p.organ.lungLeft == 1)
                            {
                                chLungLeft.click();
                            }
                            if(p.organ.pancreas == 1)
                            {
                                chPancreas.click();
                            }
                            if(p.organ.tissue == 1)
                            {
                                chTissue.click();
                            }
                            if(p.organ.bowel == 1)
                            {
                                chBowel.click();
                            }
                        }
                    });
                    GCS3Patients.show();
                    changeHeightModal('editPatientModal');
                }
                else
                {
                    // patients not brain death
                    GCS3Patients.hide();
                    changeHeightModal('editPatientModal');
                }
                pcal1.val(Data.hospitalizationTime);
                pcal2.val(Data.gcs3ByDrTime);
                pcal3.val(Data.brainDeathTime);
                pcal5.val(Data.organDonationTime);
                pcal6.val(Data.cardiacDeathTime);
                appRegisterTime.text(Data.appRegisterTime);
                loading.hide();
                form.show();
                saveBTN.removeAttr('disabled', 'disabled');
                transferBTN.removeAttr('disabled', 'disabled');
                changeHeightModal('editPatientModal');
            }).fail(function(){
                dangerAlert.text('خطایی در دریافت اطلاعات بیمار رخ داده است، لطفاً دوباره تلاش نمائید.');
                loading.hide();
            });
            j--;
        }
        // on change type of list load form for brain death
        cbTol.on('change', function(){
            if(cbTol.val() == 1)
            {
                // patient is GCS3 brain death
                GCS3Patients.show();
                changeHeightModal('editPatientModal');
            }
            else
            {
                // patients not brain death
                GCS3Patients.hide();
                changeHeightModal('editPatientModal');
            }
        });
        
        // on patient transfer btn clicked for transfer that
        transferBTN.unbind('click').bind('click', function(){
            saveBTN.hide();
            transferBTN.hide();
            insertState('cbTransferState', false);
            form.hide();
            transferForm.show();
            transferSaveBTN.show();
            changeHeightModal('editPatientModal');
        });
        
        // on patient save transfer btn clicked
        transferSaveBTN.unbind('click').bind('click', function(){
            dangerAlert.hide();
            if(cbTransferState.val() > 0 && cbTransferCity.val() > 0 && cbTransferHospital.val() > 0 && pcal4.val().length > 6)
            {
                transferSaveBTN.attr('disabled', 'disabled');
                loading.show();
                changeHeightModal('editPatientModal');
                if(exp > 0)
                {
                    $.ajax({
                        type: "POST",
                        url: base_url() + "ajax/ajax_conf/transfer_patient",
                        cache: false,
                        data: {cbTCity: cbTransferCity.val(), cbTState: cbTransferState.val(), cbTHospital: cbTransferHospital.val(), tTime: pcal4.val(), pId: id}
                        }).done(function(Data){
                            if(Data == 1)
                            {
                                successAlert.text('بیمار مورد نظر با موفقیت منتقل شد، پس از تایید مسئول سامانه به واحد جدید اطلاع داده می شود.');
                                loading.hide();
                                successAlert.show();
                                setTimeout(function(){
                                   window.location.reload(1);
                                }, 5000);
                            }
                            else
                            {
                                dangerAlert.text('خطایی در مراحل انتقال بیمار رخ داده است، لطفاً دوباره تلاش نمائید.');
                                loading.hide();
                                dangerAlert.show();
                            }
                        });
                        exp--;
                }
            }
            else
            {
                dangerAlert.text('لطفاً تمامی موارد را به درستی تکمیل نمائید.');
                dangerAlert.show();
                changeHeightModal('editPatientModal');
            }
        });
        
        // on save btn clicked for save data
        saveBTN.unbind('click').bind('click', function(){
            saveBTN.attr('disabled', 'disabled');
            transferBTN.attr('disabled', 'disabled');
            dangerAlert.hide();
            loading.show();
            changeHeightModal('editPatientModal');
            Err = 0;
            // agar bimar gcd3 marge maghzi bashad va vazeetae an montaghel shode nabashad
            if(cbTol.val() == 1 && cbPatientStatus.val() != 5 && cbPatientStatus.val() != 0)
            {
                // check kardan vazeeta paydari va azmayeshate bimar
                if(inputT.val().length > 0 && inputPR.val().length > 0 && inputFIO2.val().length > 0 && inputBP.val().length > 0 && inputRR.val().length > 0 && inputO2SAT.val().length > 0 && inputNa.val().length > 0 && inputBUN.val().length > 0 && inputALT.val().length > 0 && inputWBC.val().length > 0 && inputHb.val().length > 0 && inputK.val().length > 0 && inputCr.val().length > 0 && inputAST.val().length > 0 && inputPLT.val().length > 0 && inputBs.val().length > 0 && inputOut.val().length > 0)
                {
                    // vazeeate paydari va azmayeshate bimar vared shod
                    if(cbPatientStatus.val() == 6) // agar bimar vazeeate ehda shode dashte bashad
                    {
                        // validate coordinator name
                        if(inputCoordinatorName.val().length > 5)
                        {
                            // check kardan organ haye ehda shode
                            if(chHeart.is(':checked') || chLiver.is(':checked') || chKidneyRight.is(':checked') || chKidneyLeft.is(':checked') || chLungRight.is(':checked') || chLungLeft.is(':checked') || chBowel.is(':checked') || chPancreas.is(':checked') || chTissue.is(':checked'))
                            {
                                // yeki az organ haye ehdaee entekhab shode ast
                                if(pcal1.val().length > 6 && pcal2.val().length > 6 && pcal3.val().length > 6 && pcal5.val().length > 6) // baresi tarikh haye ejbari
                                {
                                    // tarikhe haye marboot be bimar ehda shode sahih ast
                                    if(chUn.is(':checked'))
                                    {
                                        // bimare nashenas ghabele ehda nemibashad
                                        dangerAlert.text('بیمار ناشناس قابل اهدا نمی باشد، لطفا اطلاعات را به صورت صحیح وارد نمائید.');
                                        loading.hide();
                                        dangerAlert.show();
                                        changeHeightModal('editPatientModal');
                                        saveBTN.removeAttr('disabled', 'disabled');
                                        transferBTN.removeAttr('disabled', 'disabled');
                                        Err = 1;
                                    }
                                    else
                                    {
                                        Err = 0;
                                    }
                                }
                                else
                                {
                                    // tarikh haye marboot be bimare ehda shode sahih nemibashad
                                    dangerAlert.text('تاریخ بستری، تاریخ اعلام GCS3، تاریخ شناسایی مرگ مغزی و تاریخ اهدا را به درستی وارد نمائید.');
                                    loading.hide();
                                    dangerAlert.show();
                                    changeHeightModal('editPatientModal');
                                    saveBTN.removeAttr('disabled', 'disabled');
                                    transferBTN.removeAttr('disabled', 'disabled');
                                    Err = 1;
                                }
                                
                            }
                            else
                            {
                                // baraye bimar ehda shode hich organi entekhab nashode
                                dangerAlert.text('برای بیمار با وضعیت اهدا شده می بایست ارگان های اهدایی را نیز انتخاب نمائید.');
                                loading.hide();
                                dangerAlert.show();
                                changeHeightModal('editPatientModal');
                                saveBTN.removeAttr('disabled', 'disabled');
                                transferBTN.removeAttr('disabled', 'disabled');
                                Err = 1;
                            }
                        }
                        else
                        {
                            // baraye bimar ehda shode name coordinator vared nashode ast
                            dangerAlert.text('نام کوردیناتور نمی تواند خالی باشد.');
                            loading.hide();
                            dangerAlert.show();
                            changeHeightModal('editPatientModal');
                            saveBTN.removeAttr('disabled', 'disabled');
                            transferBTN.removeAttr('disabled', 'disabled');
                            Err = 1;
                        }
                    }
                    else if(cbPatientStatus.val() == 10 || cbPatientStatus.val() == 11 || cbPatientStatus.val() == 12 || cbPatientStatus.val() == 13 || cbPatientStatus.val() == 14 || cbPatientStatus.val() == 15 || cbPatientStatus.val() == 9)
                    {
                        // baresi bimari ke vazeete an fot shode entekhab shode va gcs3 marge maghzi ast
                        if(pcal1.val().length > 6 && pcal2.val().length > 6 && pcal3.val().length > 6 && pcal6.val().length > 6)
                        {
                            // tarikhe haye marboot be bimar fot shode sahih ast
                            Err = 0;
                            
                        }
                        else
                        {
                            // tarikh haye marboot be bimare fot shode sahih nemibashad
                            dangerAlert.text('تاریخ بستری، تاریخ اعلام GCS3، تاریخ شناسایی مرگ مغزی و تاریخ مرگ قلبی را وارد نمائید.');
                            loading.hide();
                            dangerAlert.show();
                            changeHeightModal('editPatientModal');
                            saveBTN.removeAttr('disabled', 'disabled');
                            transferBTN.removeAttr('disabled', 'disabled');
                            Err = 1;
                        }
                    }
                }
                else
                {
                    // azmayeshat va vazeeate paydari mariz be dorosti takmil nashode
                    dangerAlert.text('اطلاعات مربوط به قسمت آزمایشات و وضعیت پایداری بیمار را تکمیل نمائید.');
                    loading.hide();
                    dangerAlert.show();
                    changeHeightModal('editPatientModal');
                    saveBTN.removeAttr('disabled', 'disabled');
                    transferBTN.removeAttr('disabled', 'disabled');
                    Err = 1;
                }
            }
            else if(cbPatientStatus.val() == 5) // agar vazeeate bimar montaghel shode entekhab shod form enteghal namayesh dade mishavad
            {
                saveBTN.hide();
                transferBTN.hide();
                insertState('cbTransferState', false);
                form.hide();
                transferForm.show();
                transferSaveBTN.show();
                changeHeightModal('editPatientModal');
                loading.hide();
                exp--;
            }
            else if(cbPatientStatus.val() == 0) // agar hich vazeeate baraye bimar zakhire nashod
            {
                // vazeeate bimar entekhab nashode ast
                dangerAlert.text('لطفاً وضعیت بیمار را انتخاب نمائید.');
                loading.hide();
                dangerAlert.show();
                changeHeightModal('editPatientModal');
                saveBTN.removeAttr('disabled', 'disabled');
                transferBTN.removeAttr('disabled', 'disabled');
                Err = 1;
            }
            else
            {
                Err = 0;
            }
            
            // ersal etela'at tabaghe bandi shode be server
            if((chUn.is(':checked') || (inputFullName.val().length > 5 && inputAge.val().length > 0)) && inputFirstGCS.val().length > 0 && cbDoc.val() > 0 && cbHospitals.val() > 0 && cbSection.val() > 0 && cbPresentioan.val() > 0 && cbTol.val() > 0)
            {
                if(Err == 0)
                {
                    if(exp > 0)
                    {
                        $.ajax({
                        type: "POST",
                        url: base_url() + "ajax/ajax_conf/edit_patient_data",
                        cache: false,
                        data : $('#editPatientForms').serialize()
                        }).done(function(Data){
                            if(Data == 'OK')
                            {
                                successAlert.text('اطلاعات مورد نظر با موفقیت ثبت گردید.');
                                loading.hide();
                                saveBTN.removeAttr('disabled', 'disabled');
                                transferBTN.removeAttr('disabled', 'disabled');
                                successAlert.show();
                                changeHeightModal('editPatientModal');
                                setTimeout(function(){
                                   window.location.reload(1);
                                }, 5000);
                            }
                            else if(Data == 'Err')
                            {
                                dangerAlert.text('خطایی در ثبت اطلاعات رخ داده است.');
                                loading.hide();
                                saveBTN.removeAttr('disabled', 'disabled');
                                transferBTN.removeAttr('disabled', 'disabled');
                                dangerAlert.show();
                                changeHeightModal('editPatientModal');
                            }
                        });
                        exp--;
                    }
                }
            }
            else
            {
                // form not valid
                //alert(Err);
                dangerAlert.text('لطفاً گزینه های ستاره دار را به درستی وارد نمائید.');
                loading.hide();
                dangerAlert.show();
                changeHeightModal('editPatientModal');
                saveBTN.removeAttr('disabled', 'disabled');
                transferBTN.removeAttr('disabled', 'disabled');
            }
        });
    }
    $('#cbDoc').on('change', function(){
        changeDoc();
    });
    $('#cbTol').on('change', function(){
        insertDocOption('cbPatientStatusEdit', 'cbTol', false, 'ALL');
    });
    $('#chisUnknown').on('change', function(){
        if($('#chisUnknown').is(':checked'))
        {
            $('#inputFullName').attr('disabled', 'disabled');
            $('#inputNationalCode').attr('disabled', 'disabled');
            $('#inputAge').attr('disabled', 'disabled');
        }
        else
        {
            $('#inputFullName').removeAttr('disabled', 'disabled');
            $('#inputNationalCode').removeAttr('disabled', 'disabled');
            $('#inputAge').removeAttr('disabled', 'disabled');
        }
    });
    $('#cbPatientStatusEdit').on('change', function(){
        if($('#cbPatientStatusEdit').val() == 22)
        {
            $('#inputPatientStatusDetail').show();
        }
        else
        {
            $('#inputPatientStatusDetail').hide();
        }
    });
    cbSedation.on('change', function(){
        if(cbSedation.is(':checked'))
        {
            if(!cbSedation2.is(':checked'))
            {
                cbSedation2.click();
            }
        }
        else
        {
            if(cbSedation2.is(':checked'))
            {
                cbSedation2.click();
            }
        }
    });
    cbSedation2.on('change', function(){
        if(cbSedation2.is(':checked'))
        {
            if(!cbSedation.is(':checked'))
            {
                cbSedation.click();
            }
        }
        else
        {
            if(cbSedation.is(':checked'))
            {
                cbSedation.click();
            }
        }
    });
}

// view patient log
function viewPatientLog(id)
{
    if(id > 0)
    {
        $('#patientLogDiv').hide();
        $('#viewPatientLogModalLoading').show();
        $('#patientLogDiv').hide();
        $('#patientTestDiv').hide();
        $('#patientConditionDiv').hide();
        $('#patientOrgansDiv').hide();
        var j = 1;
        if(j > 0)
        {
            $.ajax({
                dataType: "json",
                type: "POST",
                url: base_url() + "ajax/ajax_conf/load_one_patient_log",
                cache: false,
                data: {pID: id}
                }).done(function(Data){
                    // result
                    if(Data.isData > 0)
                    {
                        if(Data.isLog > 0)
                        {
                            var tabbleLog;
                            for(var i = 0, a = 1; i < Data.countLog; i++)
                            {
                                tabbleLog += '<tr><td style="width: 50px;">' + a + '</td><td style="width: 250px;">OPU: <span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">' + Data.log[i].opu + '</span><br>استان: <span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">' +  Data.log[i].state + '</span><br>شهر: <span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">' + Data.log[i].city + '</span></td><td style="width: 150px;">نام بیمارستان: <span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">' + Data.log[i].hospital + '</span><br>بخش: <span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">';
                                if(Data.log[i].section == 1)
                                {
                                    tabbleLog += 'ICU';
                                }
                                else if(Data.log[i].section == 2)
                                {
                                    tabbleLog += 'CCU';
                                }
                                else if(Data.log[i].section == 3)
                                {
                                    tabbleLog += 'اورژانس';
                                }
                                else if(Data.log[i].section == 4)
                                {
                                    tabbleLog += 'بخش';
                                }
                                if(Data.log[i].typeOfSection && Data.log[i].typeOfSection.length > 0)
                                {
                                    tabbleLog += ' - ' + Data.log[i].typeOfSection;
                                }
                                
                                tabbleLog += '</span></td><td style="width: 150px; text-align: center"><span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">' + Data.log[i].inspector + '</span></td><td style="width: 100px; text-align: center"><span style="font-family: ' + "'webYekan'" + '; font-size: 12px;">';
                                
                                if(Data.log[i].secondGCS > 0) 
                                {
                                    tabbleLog += Data.log[i].secondGCS;
                                }
                                else
                                {
                                    tabbleLog += '-';
                                }
                                
                                tabbleLog += '</span></td><td style="width: 300px; text-align: left; font-family: Tahoma; font-size: 14px;"><table style="width: 100%; direction: ltr; font-size: 12px;"><tbody><tr><td style="width: 62%; text-align: left; border-right: 1px dashed;">Breathing: <span style="font-weight: bold;">' + Data.log[i].breathing;
                                
                                if(Data.log[i].breathingDetail.length > 0)
                                {
                                    tabbleLog += ' - ' + Data.log[i].breathingDetail;
                                }
                                
                                tabbleLog += '</span></td><td style="width: 38%; text-align: left; padding-left: 5px;">Gag: <span style="font-weight: bold;">' + Data.log[i].gag + '</span></td></tr><tr><td style="width: 62%; text-align: left; border-right: 1px dashed;">Doll\'s Eyes: <span style="font-weight: bold;">' + Data.log[i].dollEye + '</span></td><td style="width: 38%; text-align: left; padding-left: 5px;">Cough: <span style="font-weight: bold;">' + Data.log[i].cough + '</span></td></tr><tr><td style="width: 62%; text-align: left; border-right: 1px dashed;">Body Movement: <span style="font-weight: bold;">' + Data.log[i].bodyMovement;
                                
                                if(Data.log[i].bodyMovementDetail.length > 1)
                                {
                                    tabbleLog += ' - ' + Data.log[i].bodyMovementDetail;
                                }
                                
                                tabbleLog += '</span></td><td style="width: 38%; text-align: left; padding-left: 5px;">Pupil: <span style="font-weight: bold;">' + Data.log[i].pupil + '</span></td></tr><tr><td style="width: 62%; text-align: left; border-right: 1px dashed;">Face Movement: <span style="font-weight: bold;">' + Data.log[i].faceMovement;
                                
                                if(Data.log[i].faceMovementDetail.length > 1)
                                {
                                    tabbleLog += ' - ' + Data.log[i].faceMovementDetail;
                                }
                                
                                tabbleLog += '</span></td><td style="width: 38%; text-align: left; padding-left: 5px;">Cornea: <span style="font-weight: bold;">' + Data.log[i].cornea + '</span></td></tr><tr><td style="width: 62%; text-align: left; border-right: 1px dashed;">Sedation: <span style="font-weight: bold;">' + Data.log[i].sedation + '</span><td style="width: 38%; text-align: left;"></td></tr></tbody></table></td><td style="width: 100px; text-align: center;">' + Data.log[i].lastUpdateTime + '</td></tr>';
                                
                                a++;
                                
                            }
                            
                            $('#tableLogContent').html(tabbleLog);
                            $('#patientLogDiv').show();
                            changeHeightModal('viewPatientLogModal');
                        }
                        
                        if(Data.isTest > 0)
                        {
                            var tableTest;
                            for(var i = 0, a = 1; i < Data.countTest; i++)
                            {
                                tableTest += '<tr style="text-align: left;"><td style="width: 50px; text-align: center; font-family: ' + "'BNazanin'" + '; font-size: 14px;">' + a + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].na + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].k + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].bun + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].cr + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].alt + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].ast + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].wbc + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].plt + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].hb + '</td>';
                                tableTest += '<td style="width: 100px;">' + Data.test[i].bs + '</td>';
                                tableTest += '</tr>';
                                a++;
                            }
                            
                            $('#tableTestContent').html(tableTest);
                            $('#patientTestDiv').show();
                            changeHeightModal('viewPatientLogModal');
                        }
                        
                        if(Data.isCondition > 0)
                        {
                            var tableCondition;
                            for(var i = 0, a = 1; i < Data.countCondition; i++)
                            {
                                tableCondition += '<tr style="text-align: left;"><td style="width: 51px; text-align: center; font-family: ' + "'BNazanin'" + '; font-size: 14px;">' + a + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].t + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].bp + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].pr + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].rr + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].fio2 + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].o2sat + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].out + '</td>';
                                tableCondition += '<td style="width: 111px;">' + Data.condition[i].sedation + '</td>';
                                tableCondition += '</tr>';
                                a++;
                            }
                            
                            $('#tableConditionContent').html(tableCondition);
                            $('#patientConditionDiv').show();
                            changeHeightModal('viewPatientLogModal');
                        }
                        
                        if(Data.isOrgan > 0)
                        {
                            var yes = '<span class="glyphicon glyphicon-ok" style="color: green; font-size: 16px;"></span>';
                            var no = '<span class="glyphicon glyphicon-remove" style="color: red; font-size: 16px;"></span>';
                            if(Data.organ.heart == 1)
                            {
                                $('#patientOrganHeart').html(yes);
                            }
                            else
                            {
                                $('#patientOrganHeart').html(no);
                            }
                            if(Data.organ.liver == 1)
                            {
                                $('#patientOrganLiver').html(yes);
                            }
                            else
                            {
                                $('#patientOrganLiver').html(no);
                            }
                            if(Data.organ.kidneyRight == 1)
                            {
                                $('#patientOrganRight').html(yes);
                            }
                            else
                            {
                                $('#patientOrganRight').html(no);
                            
                            }
                            if(Data.organ.kidneyLeft == 1)
                            {
                                $('#patientOrganLeft').html(yes);
                            }
                            else
                            {
                                $('#patientOrganLeft').html(no);
                            }
                            if(Data.organ.lungRight == 1)
                            {
                                $('#patientOrganLungRight').html(yes);
                            }
                            else
                            {
                                $('#patientOrganLungRight').html(no);
                            }
                            if(Data.organ.lungLeft == 1)
                            {
                                $('#patientOrganLungLeft').html(yes);
                            }
                            else
                            {
                                $('#patientOrganLungLeft').html(no);
                            }
                            if(Data.organ.pancreas == 1)
                            {
                                $('#patientOrganPanc').html(yes);
                            }
                            else
                            {
                                $('#patientOrganPanc').html(no);
                            }
                            if(Data.organ.tissue == 1)
                            {
                                $('#patientOrganTiss').html(yes);
                            }
                            else
                            {
                                $('#patientOrganTiss').html(no);
                            }
                            if(Data.organ.bowel == 1)
                            {
                                $('#patientOrganBowel').html(yes);
                            }
                            else
                            {
                                $('#patientOrganBowel').html(no);
                            }
                            
                            $('#patientOrgansDiv').show();
                            changeHeightModal();
                        }
                        
                        
                        $('#viewPatientLogModalLoading').hide();
                            changeHeightModal('viewPatientLogModal');
                    }
                });
                j--;
        }
    }
}

// delete patient
function deletePatient(id)
{
    if(id > 0)
    {
        var name = $('#patientName' + id).text();
        var inactiveDeleteBTN = $('#DeleteBTN');
        var saveLoading = $('#deleteModalLoading');
        var divQes = $('#activeQuestion');
        var danger2 = $('#dangerAlertStatus2');
        var danger3 = $('#dangerAlertStatus3');
        inactiveDeleteBTN.removeAttr('disabled', 'disabled');
        saveLoading.hide();
        danger2.hide();
        danger3.hide();
                
        divQes.html('آیا مایل به حذف بیمار، <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟');
        divQes.show();
        
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            saveLoading.show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_patient_status",
                cache: false,
                data: {pID: id}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                });
                j--;
            }
        });
    }
}

// undo delete patient
function undoDeletePatient(id)
{
    if(id > 0)
    {
        var name = $('#patientName' + id).text();
        var inactiveDeleteBTN = $('#undoDeleteBTN');
        var saveLoading = $('#undoDeleteModalLoading');
        var divQes = $('#undoActiveQuestion');
        var danger2 = $('#undoDangerAlertStatus2');
        var danger3 = $('#undoDangerAlertStatus3');
        inactiveDeleteBTN.removeAttr('disabled', 'disabled');
        saveLoading.hide();
        danger2.hide();
        danger3.hide();
                
        divQes.html('آیا مایل به بازگرداندن بیمار، <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می‌باشید؟');
        divQes.show();
        
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            saveLoading.show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/change_undo_patient_status",
                cache: false,
                data: {pID: id}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger3.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                    else if(Data == 2)
                    {
                        danger2.show();
                    }
                });
                j--;
            }
        });
    }
}

// verify or unverify transfer patient
function verifyTransferPatient(id, status)
{
    if(id > 0)
    {
        var name = $('#patientName' + id).text();
        var inactiveDeleteBTN = $('#transferAPatientModalBTN');
        var saveLoading = $('#transferAPatientModalLoading');
        var divQes = $('#transferAPatientModalActiveQuestion');
        var danger1 = $('#transferAPatientModalDanger1');
        var danger2 = $('#transferAPatientModalDanger2');
        inactiveDeleteBTN.removeAttr('disabled', 'disabled');
        saveLoading.hide();
        danger1.hide();
        danger2.hide();
                
        if(status == 'verify')
        {
            var x = 'آیا انتقال بیمار <span style="font-weight: bold; color: #2B689B;">' + name + '</span> را به مرکز فراهم آوری جدید تایید می نمائید؟';
        }
        else if(status == 'unVerify')
        {
            var x = 'آیا مایل به انصراف انتقال بیمار  <span style="font-weight: bold; color: #2B689B;">' + name + '</span> هستید؟';
        }
        
        divQes.html(x);
        divQes.show();
        
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            saveLoading.show();
            var j = 1;
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/verify_patient_transfer",
                cache: false,
                data: {pID: id, pStatus: status}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger2.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 5000);
                    }
                    else if(Data == 2)
                    {
                        danger1.show();
                    }
                });
                j--;
            }
        });
    }
}

// delete hospital
function deleteHospital(id)
{
    if(id > 0)
    {
        var name = $('#hospialName' + id).text();
        var inactiveDeleteBTN = $('#deleteHospitalModalBTN');
        var saveLoading = $('#deleteHospitalModalLoading');
        var divQes = $('#deleteHospitalModalActiveQuestion');
        var danger1 = $('#deleteHospitalModalDanger1');
        var danger2 = $('#deleteHospitalModalDanger3');
        inactiveDeleteBTN.removeAttr('disabled', 'disabled');
        saveLoading.hide();
        danger1.hide();
        danger2.hide();
        var i = 1;
                
        var x = 'آیا مایل به حذف بیمارستان <span style="font-weight: bold; color: #2B689B;">' + name + '</span> می باشید؟';
        
        divQes.html(x);
        divQes.show();
        
        inactiveDeleteBTN.unbind('click').bind('click', function(){
            inactiveDeleteBTN.attr('disabled', 'disabled');
            saveLoading.show();
            if(i > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/delete_one_hospital",
                cache: false,
                data: {hID: id}
                }).done(function(Data){
                    inactiveDeleteBTN.removeAttr('disabled', 'disabled');
                    saveLoading.hide();
                    if(Data == 1)
                    {
                        danger2.show();
                        setTimeout(function(){
                               window.location.reload(1);
                            }, 2500);
                    }
                    else if(Data == 2)
                    {
                        danger1.show();
                    }
                });
                i--;
            }
        });
    }
}

// run archive patient process
function archivePatientRun()
{
    var btn = $('#saveArchiveBTN');
    var opu = $('#cbOpuArchive');
    var status = $('#cbPStatusArchive');
    var fromDate = $('#fromDateArchive');
    var toDate = $('#toDateArchive');
    var loadding = $('#archiveModalLoading');
    var danger1 = $('#dangerAlert1');
    danger1.hide();
    btn.removeAttr('disabled', 'disabled');
    
    if(opu.val() > 0 && fromDate.val().length > 6 && toDate.val().length > 6)
    {
        btn.attr('disabled', 'disabled');
        loadding.show();
    }
    else
    {
        danger1.show();
    }
}

// check the user in loged in
function checkUserLogedIn()
{
    var i = 1;
    if(i > 0)
    {
        $.ajax({
        type: "POST",
        url: base_url() + "ajax/ajax_conf/check_ajax_loged_in",
        cache: false,
        data: {_var: i}
        }).done(function(Data){
            if(Data == 'YES')
            {
                // user is loged in
            }
            else
            {
                window.location = base_url() + 'userAuthentication/user_authentication';
            }
        });
        i--;
    }
}

// show panel
function showPanel(id, status)
{
    if(status == 'p')
    {
        $('#' + id + 'Body').slideToggle();
        $('#' + id + 'Plus').hide();
        $('#' + id + 'Minus').show();
        
    }
    else if(status == 'm')
    {
        $('#' + id + 'Body').slideToggle();
        $('#' + id + 'Plus').show();
        $('#' + id + 'Minus').hide();
    }
    else if(status == 'r')
    {
        $('#' + id).hide(1000);
    }
}

// edit state
function editOneState(id)
{
    $('#modalLoading').hide();
    $('#saveBTN').removeAttr('disabled', 'disabled');
    $('#inputStateName').removeAttr('disabled', 'disabled');
    $('#successAlert').hide();
    $('#dangerAlert').hide();
    $('#dangerAlertTwo').hide();
    var city = $('#cityName' + id).text();
    $('#inputStateName').val(city);
    $('#editStatesForm').show();
    var j = 1;
    
    $('#saveBTN').unbind('click').bind('click', function(){
        $('#modalLoading').show();
        $('#saveBTN').attr('disabled', 'disabled');
        $('#inputStateName').attr('disabled', 'disabled');
        var changeCity = $('#inputStateName').val();
        if(changeCity.length > 1)
        {
            if(j > 0)
            {
                $.ajax({
                type: "POST",
                url: base_url() + "ajax/ajax_conf/edit_state",
                cache: false,
                data: {cityName: changeCity, cityId: id}
                }).done(function(Data){
                    if(Data == '1')
                    {
                        $('#modalLoading').hide();
                        $('#saveBTN').removeAttr('disabled', 'disabled');
                        $('#inputStateName').removeAttr('disabled', 'disabled');
                        $('#successAlert').show();
                        $('#cityName' + id).text(changeCity);
                    }
                    else
                    {
                        $('#modalLoading').hide();
                        $('#saveBTN').removeAttr('disabled', 'disabled');
                        $('#inputStateName').removeAttr('disabled', 'disabled');
                        $('#dangerAlert').show();
                    }
                });
                j--;
            }
        }
        else
        {
            $('#saveBTN').removeAttr('disabled', 'disabled');
            $('#inputStateName').removeAttr('disabled', 'disabled');
            $('#modalLoading').hide();
            $('#dangerAlertTwo').show();
        }
    });
    
    
    
}

// add state
function addState(id)
{
    var load = $('#addStateModalLoading');
    var form = $('#addStateModalForm');
    var city = $('#addStaticCity');
    var stateName = $('#inputNewStateName');
    var btn = $('#addSaveBTN');
    var alert1 = $('#addSuccessAlert');
    var alert2 = $('#addDangerAlert');
    var j = 1;
    load.hide();
    form.show();
    stateName.val();
    alert1.hide();
    alert2.hide();
    if(id > 0)
    {
        $('#inputStateNameStatic').val($('#cityName' + id).text());
        city.show();
    }
    else
    {
        city.hide();
    }
    btn.unbind('click').bind('click', function(){
        if(stateName.val().length > 1 && j > 0)
        {
            btn.attr('disabled', 'disabled');
            form.hide();
            load.show();
            $.ajax({
                    type: "POST",
                    url: base_url() + "ajax/ajax_conf/add_state",
                    cache: false,
                    data: {pId: id, stName: stateName.val()}
                    }).done(function(Data){
                        btn.removeAttr('disabled', 'disabled');
                        load.hide();
                        stateName.val();
                        form.show();
                        if(Data == '1')
                        {
                            alert1.show();
                            setTimeout(function(){
                                   window.location.reload(1);
                                }, 2500);
                        }
                        else
                        {
                            alert2.show();
                        }
                    });
            j--;
        }
    });
}

// redirect page
function redirect(url)
{
    window.location = base_url() + url;
}