<?php  //if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// ------------------------------------------------------------------------

/* return asset url for include css and js file and project images */
if ( ! function_exists('_url'))
{
	function asset_url()
	{
		return base_url().'assets/';
	}
}

// ------------------------------------------------------------------------

/*  persian security question code generator and validator */
if( ! function_exists('securityQuestion'))
{
    function securityQuestion($code = 'y')
    {
        $CI =& get_instance();
        if($code == 'y')
        {
            $x = rand(1, 9);
            $y = rand(1, 9);
            $operation = array('+', '*');
            $op = $operation[rand(0,1)];
            if($op == '+')
            {
                $z = sha1(md5($x + $y));
                $CI->session->set_userdata(array('qs' => $z));
                $a = "$x" . ' به علاوه ' . "$y";
            }
            elseif($op == '*')
            {
                $z = sha1(md5($x * $y));
                $CI->session->set_userdata(array('qs' => $z));
                $a = "$x" . ' ضرب در ' . "$y";
            }
            else
            {
                $z = sha1(md5($x + $y));
                $CI->session->set_userdata(array('qs' => $z));
                $a = "$x" . ' به علاوه ' . "$y";
            }
            return $a;
        }
        else
        {
            if(is_numeric($code) && strlen($code) > 0 && ($code + 0) > 0)
            {
                if($CI->session->userdata('qs'))
                {
                    if($CI->session->userdata('qs') == sha1(md5($code)))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
}


// ------------------------------------------------------------------------

/* return a random number */
function randnum($a)
{
    $first = date('ym');
    $last = '';
    for($i = 1; $i <= $a; $i++)
    {
        $last .= rand(0,9);
    }
    $num = $first . $last;
    
    return $num;
}

// ------------------------------------------------------------------------

/* retun character limmit */
function gCharLimit($String , $Length)
{
    if(strlen($String) > $Length ) {
        $String = substr(trim($String),0,$Length); 
        $String = substr($String,0,strlen($String)-strpos(strrev($String)," "));
        $String = $String.'...';
    }
    return $String ; 
}

// ------------------------------------------------------------------------

/* html coding */
function htmlCoding($input, $type = 1)
{
    if($type == '1')
    {
        $input = str_replace( "ي" , "ی" , $input ) ; 
        $input = str_replace( "ك"  , "ک" , $input ) ;
        $input = str_replace( "¬"  , "‏" , $input ) ;
        $input = trim($input);
        return htmlspecialchars($input ,ENT_QUOTES);
    }
    else
    {
        return htmlspecialchars_decode($input, ENT_QUOTES);
    }
}

// ------------------------------------------------------------------------

/* get real ip address */
function getRealUserIp()
{
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';

    return $ipaddress; 
}

// ------------------------------------------------------------------------

/* show data in array */
function showArray($data)
{
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}

// ------------------------------------------------------------------------

/* national code verify */
function nationalCode($codes)
{
    if(strlen($codes) == '10' && is_numeric($codes))
    {
        $code = str_split($codes);
        $err ;
        foreach($code as $k => $v)
        {
            if($code[0] <> $v)
            {
                  $err = 1;
                  break;
            }
            else
            {
                $err = 2;
            }
        }
        if($err == 1)
        {
            $valid = 0;
            $jumper = 10;
            for($i = 0; $i <= 8; $i++)
            {
                $valid += $code[$i] * $jumper;
                --$jumper;
            }
            $valid = $valid % 11;
            if($valid >= 0 && $valid < 2)
            {
                if($valid == $code['9'])
                {
                    //$msg = 1; // national code valid
                    return true;
                    exit;
                }
                else
                {
                    //$msg = 2; // national code invalid
                    return false;
                    exit;
                }
            }
            else
            {
                $valid = 11 - $valid;
                if($valid == $code['9'])
                {
                    //$msg = 1; // national code valid
                    return true;
                    exit;
                }
                else
                {
                    //$msg = 2; // national code invalid
                    return false;
                    exit;
                }
            }
        }
        else
        {
            //$msg = 3; // number not be equal
            return false;
            exit;
        }
    }
    else
    {
        //$msg = 4; // not numbet AND not 10 char
        return false;
        exit;
    }
    //return $msg;
}

// ------------------------------------------------------------------------

// ------------------------------------------------------------------------

// ------------------------------------------------------------------------

// ------------------------------------------------------------------------