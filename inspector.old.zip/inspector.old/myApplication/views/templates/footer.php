    </div>
    
    
    
    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title">Modal title</h4>
      </div>
      <div class="modal-body">
        <p>One fine body&hellip;</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


    <div class="clearB"></div>
    <div id="footerContent">
        <div class="footerContentTitle">کلیه حقوق این سامانه برای اداره پیوند و بیماری های خاص وزارت بهداشت، درمان و آموزش پزشکی محفوظ می باشد.</div>
        <div class="footerContentTitle" style="padding-top: 0px;">طراحی، برنامه نویسی و پشتیبانی توسط <a href="http://yasnateam.com" target="_blank">شرکت توسعه سرمایه گذاری سورنا</a></div>
    </div>
    
    <script type="text/javascript">
            $(document).ready(function(){
                var dw = $('.dataComponent').width();
                var dow = $(document).width();
                var wi = (Math.round((dow - (dw * 4)) / 8)) - 1;
                if(wi > 0)
                {
                    //$('.dataComponent').css({margin: wi});
                }
                else
                {
                    //$('.dataComponent').css({margin: 10});
                }
            });
            $(document).ready(function(){
                $(function () {
                  $('[data-toggle="tooltip"]').tooltip()
                });
                $(function () {
                  $('[rel="tooltip"]').tooltip()
                });
            });
        </script>
        
    
  </body>
</html>

