<?php
class managePatientPoor_model extends CI_Model {

    public function __construct()
    {
        
    }
    public function patient_data()
    {
        $where = array('patients.status' => 1, 'pLog.isTransfer' => 0, 'patients.tol' => 4, 'pLog.opu' => $this->session->userdata('uid'));
        $class = 'opu/manage_patient_poor/index/';
        $data = $this->managePatientQuery_model->patient_data_query($where, $class);
        return $data;
    }
}