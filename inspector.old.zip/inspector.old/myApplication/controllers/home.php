<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        if(!$this->userauthentication_model->check_user_logedin())
        {
            redirect(base_url() . 'userAuthentication/user_authentication');
            exit;
        }
    }
    
    public function index()
	{
        $data = '';
        $this->load->view('templates/header', $this->header_model->header_data());
        $this->load->view('templates/topMain', $this->header_model->login_name_info());
        $this->load->view('templates/dataComponent', $this->header_model->data_component());
        $this->load->view('templates/loginInfo', $this->header_model->login_info());
        $this->load->view('templates/homeChart', $data);
        $this->load->view('templates/footer', $this->header_model->footer_data());
	}
}