<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajax_conf extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if(!$this->userauthentication_model->check_user_logedin())
        {
            redirect(base_url());
            exit;
        }
        $this->load->model('ajax/ajax_model');
    }
    
    public function index()
    {
        // index
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
    }
    
    public function edit_state()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            if($this->input->post('cityName') && strlen($this->input->post('cityName')) > 1 && $this->input->post('cityId') && is_numeric($this->input->post('cityId')))
            {
                $this->ajax_model->edit_state_data();
                echo 1;
            }
            else
            {
                echo 2;
            }
        }
    }
    
    // load state and city
    public function load_states()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_state();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if($this->input->post('isSelected') == $data[$i]['id'])
                {
                    $op .= '<option value="' . $data[$i]['id'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                }
                else
                {
                    $op .= '<option value="' . $data[$i]['id'] . '">' . $data[$i]['name'] . '</option>';
                }
            }
        }
        
        echo $op;
    }
    
    // load opu
    public function load_opu()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_opu();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if($this->input->post('isSelected') == $data[$i]['id'])
                {
                    $op .= '<option value="' . $data[$i]['id'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                }
                else
                {
                    $op .= '<option value="' . $data[$i]['id'] . '">' . $data[$i]['name'] . '</option>';
                }
            }
        }
        
        echo $op;
    }
    
    // insert new opu
    public function insert_opu()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->insert_opu();
        }
        else
        {
            exit;
        }
    }
    
    // get one opu data 
    public function select_one_opu()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->select_one_opu();
        if($data)
        {
            echo $data;
        }
        else
        {
            echo 'Err';
        }
    }
    
    // edit one opu
    public function edit_one_opu()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->edit_one_opu();
        }
        else
        {
            exit;
        }
    }
    
    // insert new hospital
    public function add_new_hospital()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->add_new_hospital();
        }
        else
        {
            exit;
        }
    }
    
    // get one hospital data 
    public function select_one_hospital()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->select_one_hospital();
        if($data)
        {
            echo $data;
        }
        else
        {
            echo 'Err';
        }
    }
    
    // edit one hospital
    public function edit_one_hospital()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->edit_one_hospital();
        }
        else
        {
            exit;
        }
    }
    
    // insert new inspector
    public function add_new_inspector()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu())
        {
            echo $this->ajax_model->add_new_inspector();
        }
        else
        {
            exit;
        }
    }
    
    // get one inspector data 
    public function select_one_inspector()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->select_one_inspector();
        if($data)
        {
            echo $data;
        }
        else
        {
            echo 'Err';
        }
    }
    
    // edit one inspector
    public function edit_one_inspector()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu())
        {
            echo $this->ajax_model->edit_one_inspector();
        }
        else
        {
            exit;
        }
    }
    
    // load hospital
    public function load_hospital()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_hospital();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if($this->input->post('isSelected') == $data[$i]['id'])
                {
                    $op .= '<option value="' . $data[$i]['id'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                }
                else
                {
                    $op .= '<option value="' . $data[$i]['id'] . '">' . $data[$i]['name'] . '</option>';
                }
            }
        }
        
        echo $op;
    }
    
    // load inspectors
    public function load_inspectors()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_inspectors();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if($this->input->post('isSelected') == $data[$i]['id'])
                {
                    $op .= '<option value="' . $data[$i]['id'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                }
                else
                {
                    $op .= '<option value="' . $data[$i]['id'] . '">' . $data[$i]['name'] . '</option>';
                }
            }
        }
        
        echo $op;
    }
    
    // load Disorders of consciousness
    public function load_doc()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_doc();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if(is_array($data[$i]['sub']) AND count($data[$i]['sub']) > 0)
                {
                    $op .= '<optgroup label="' . $data[$i]['text'] . '">';
                    for($j = 0; $j < count($data[$i]['sub']); $j++)
                    {
                        if($this->input->post('isSelected') == $data[$i]['sub'][$j]['id'])
                        {
                            $op .= '<option value="' . $data[$i]['sub'][$j]['id'] . '"' . $selected . '>' . $data[$i]['sub'][$j]['text'] . '</option>';
                        }
                        else
                        {
                            $op .= '<option value="' . $data[$i]['sub'][$j]['id'] . '">' . $data[$i]['sub'][$j]['text'] . '</option>';
                        }
                    }
                    $op .= '</optgroup>';
                }
                else
                {
                    if($data[$i]['id'] != 8)
                    {
                        if($this->input->post('isSelected') == $data[$i]['id'])
                        {
                            $op .= '<option value="' . $data[$i]['id'] . '"' . $selected . '>' . $data[$i]['text'] . '</option>';
                        }
                        else
                        {
                            $op .= '<option value="' . $data[$i]['id'] . '">' . $data[$i]['text'] . '</option>';
                        }
                    }
                }
                if($i == (count($data) - 1))
                {
                    if($this->input->post('isSelected') == 8)
                    {
                        $op .= '<option value="8"' . $selected . '>سایر</option>';
                    }
                    else
                    {
                        $op .= '<option value="8">سایر</option>';
                    }
                }
            }
        }
        
        echo $op;
    }
    
    // load tol option
    public function load_tol_option()
    {
        if (!$this->input->is_ajax_request()) {
           show_404();
           exit;
        }
        $data = $this->ajax_model->load_tol_option();
        if($this->input->post('isSelected'))
        {
            $selected = ' selected="selected" ';
        }
        else
        {
            $selected = '';
        }
        $op = '<option value="0">انتخاب کنید...</option>';
        $is22 = 0;
        if($data AND is_array($data) AND count($data) > 0)
        {
            for($i = 0; $i < count($data); $i++)
            {
                if($data[$i]['tolOptionID'] == 3 AND $this->input->post('stateID') != 1)
                {
                    if($this->input->post('isSelected') == $data[$i]['tolOptionID'])
                    {
                        $op .= '<option value="' . $data[$i]['tolOptionID'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                    }
                    else
                    {
                        $op .= '<option value="' . $data[$i]['tolOptionID'] . '">' . $data[$i]['name'] . '</option>';
                    }
                }
                else
                {
                    if($data[$i]['sub'] AND is_array($data[$i]['sub']) AND count($data[$i]['sub']) > 0)
                    {
                        $op .= '<optgroup label="' . $data[$i]['name'] . '">';
                        for($j = 0; $j < count($data[$i]['sub']); $j++)
                        {
                            if($data[$i]['sub'][$j]['id'] == 22)
                            {
                                $is22 = 1;
                            }
                            else
                            {
                                if($this->input->post('isSelected') == $data[$i]['sub'][$j]['id'])
                                {
                                    $op .= '<option value="' . $data[$i]['sub'][$j]['id'] . '"' . $selected . '>' . $data[$i]['sub'][$j]['name'] . '</option>';
                                }
                                else
                                {
                                    $op .= '<option value="' . $data[$i]['sub'][$j]['id'] . '">' . $data[$i]['sub'][$j]['name'] . '</option>';
                                }
                            }
                        }
                        if($is22 == 1)
                        {
                            if($this->input->post('isSelected') == 22)
                            {
                                $op .= '<option value="22"' . $selected . '>سایر موارد</option>';
                            }
                            else
                            {
                                $op .= '<option value="22">سایر موارد</option>';
                            }
                            $is22 = 0;
                        }
                        $op .= '</optgroup>';
                    }
                    else
                    {
                        if($this->input->post('isSelected') == $data[$i]['tolOptionID'])
                        {
                            $op .= '<option value="' . $data[$i]['tolOptionID'] . '"' . $selected . '>' . $data[$i]['name'] . '</option>';
                        }
                        else
                        {
                            $op .= '<option value="' . $data[$i]['tolOptionID'] . '">' . $data[$i]['name'] . '</option>';
                        }
                    }
                }
            }
        }
        
        echo $op;
    }
    
    // change inspectors status
    public function change_inspector_status()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu())
        {
            echo $this->ajax_model->change_inspector_status();
        }
        else
        {
            exit;
        }
    }
    
    // change opu status
    public function change_opu_status()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->change_opu_status();
        }
        else
        {
            exit;
        }
    }
    
    // load one patient data
    public function load_one_patient()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->load_one_patient();
        }
        else
        {
            exit;
        }
    }
    
    // load one patient extra data
    public function load_one_patient_extra_data()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->load_one_patient_extra_data();
        }
        else
        {
            exit;
        }
    }
    
    // transfer patient
    public function transfer_patient()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->transfer_patient();
        }
        else
        {
            exit;
        }
    }
    
    // edit patient data
    public function edit_patient_data()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->edit_patient_data();
        }
        else
        {
            exit;
        }
    }
    
    // load one patient logs
    public function load_one_patient_log()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->load_one_patient_log();
        }
        else
        {
            exit;
        }
    }
    
    // delete patient
    public function change_patient_status()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu())
        {
            echo $this->ajax_model->change_patient_status();
        }
        else
        {
            exit;
        }
    }
    
    // undo delete patient
    public function change_undo_patient_status()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu())
        {
            echo $this->ajax_model->change_undo_patient_status();
        }
        else
        {
            exit;
        }
    }
    
    // verify or unverify patient transfer
    public function verify_patient_transfer()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->verify_patient_transfer();
        }
        else
        {
            exit;
        }
    }
    
    // delete hospital
    public function delete_one_hospital()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->delete_one_hospital();
        }
        else
        {
            exit;
        }
    }
    
    // found patient result in add patient form
    public function found_patient_result()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin() OR $this->userauthentication_model->is_opu() OR $this->userauthentication_model->is_inspector())
        {
            echo $this->ajax_model->found_patient_result();
        }
        else
        {
            exit;
        }
    }
    
    // cehck the user loged in  -- not need model
    public function check_ajax_loged_in()
    {
        if($this->userauthentication_model->check_user_logedin())
        {
            echo 'YES';
        }
        else
        {
            echo 'NO';
        }
    }
    
    // add state and city
    public function add_state()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->add_state();
        }
        else
        {
            exit;
        }
    }
    
    // delete state or city
    public function delete_state_or_city()
    {
        if(!$this->input->is_ajax_request())
        {
           show_404();
           exit;
        }
        if($this->userauthentication_model->is_admin())
        {
            echo $this->ajax_model->delete_state_or_city();
        }
        else
        {
            exit;
        }
    }
}