<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_authentication extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if($this->userauthentication_model->check_user_logedin())
        {
            if($this->uri->segment(3) == 'log_out')
            {
                $this->log_out();
                exit;
            }
            else
            {
                if($this->uri->segment(3) != 'change_password')
                {
                    redirect(base_url());
                    exit;
                }
            }
        }
    }
    
    public function index()
    {
        //////////////////////////////////////////
        if($this->input->post('question'))
        {
            if(securityQuestion($this->input->post('question')))
            {
                if($this->input->post('username'))
                {
                    if($this->userauthentication_model->login_user())
                    {
                        redirect(base_url());
                    }
                    else
                    {
                        $data['err'] = '2';
                    }
                }
                else
                {
                    $data['err'] = 2;
                }
            }
            else
            {
                $data['err'] = 3;
            }
        }
        else
        {
            $data['err'] = '';
        }
        $this->load->view('userAuthentication/login', $data);
    }
    
    public function log_out()
    {
        $this->userauthentication_model->log_out();
        redirect(base_url());
        exit;
    }
    
    // change users password
    public function change_password()
    {
        if($this->input->post('inputLastPassword'))
        {
            $data = $this->userauthentication_model->changeUserPassword();
        }
        else
        {
            $data['status'] = '';
        }
        $this->load->view('templates/header', $this->header_model->header_data());
        $this->load->view('templates/topMain', $this->header_model->login_name_info());
        $this->load->view('templates/dataComponent', $this->header_model->data_component());
        $this->load->view('publicPages/changePassword', $data);
        $this->load->view('templates/footer', $this->header_model->footer_data());
    }
}